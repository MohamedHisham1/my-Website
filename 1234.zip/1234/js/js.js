var button = document.getElementById("button"),
    body = document.getElementById("body"),
    overlay = document.getElementById("overlay");
    
    
    

button.onclick = function () {
    
    
    body.classList.add("change-header-scale")
    
    
    overlay.style.visibility = "visible"
    overlay.style.opacity = "1"
    
    window.setInterval(function () {
        
        window.location.href = "sadsa.html"
        
    }, 230)
}