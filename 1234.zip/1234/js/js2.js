var img_2  = document.getElementById("img-2"), 
    
    overflow  = document.getElementById("overflow"),
    
    arrwo_left_big  = document.getElementById("arrwo-left-big"),
    
    arrwo_right_big  = document.getElementById("arrwo-right-big"),
    
    box_counter  = document.getElementById("counter"),
    
    img  = document.getElementById("img"),
    
    styleElem = document.head.appendChild(document.createElement("style")),
    
    all_img_ga = document.getElementById("all-img-ga"),

    code_line_left = document.getElementById("code-line-left"),
    
    p = document.getElementById("p"), 
    
    loader_img_ga = document.getElementById("loader-img-ga"), 
        
    /*Start Variables Gallery 1*/
    
    one  = document.getElementById("one"),
    
    img_ga_1 = document.getElementById("img-ga-1"),
    
    gallery_1  = document.getElementById("gallery-1"),
        
    img_tow = document.getElementById("img-tow"),
    
    code_line_right = document.getElementById("code-line-right"),
    
    code_line_left = document.getElementById("code-line-left"),
    
    box_code_line = document.getElementById("box-code-line"),
    
    box_hidden = document.getElementById("box-hidden"),
    /*End Variables Gallery 1*/
    
    //---------------------------------------------------------------------------------------------
    
    /*Start Variables Gallery 2*/
    tow  = document.getElementById("tow"), 
    
    img_ga_2 = document.getElementById("img-ga-2"),
    
    gallery_2  = document.getElementById("gallery-2"),
    
    
    img_tow_2 = document.getElementById("img-tow-2"),
    
    code_line_right_2 = document.getElementById("code-line-right-2"),
    
    code_line_left_2 = document.getElementById("code-line-left-2"),
    
    box_code_line_2 = document.getElementById("box-code-line-2"),
    
    box_hidden_2 = document.getElementById("box-hidden-2"),
    /*End Variables Gallery 2*/
    
    //---------------------------------------------------------------------------------------------
    
    /*Start Variables Gallery 3*/
        
    three  = document.getElementById("three"),
    
    img_ga_3 = document.getElementById("img-ga-3"),
    gallery_3  = document.getElementById("gallery-3"),
    
    img_tow_3 = document.getElementById("img-tow-3"),
    
    code_line_right_3 = document.getElementById("code-line-right-3"),
    
    code_line_left_3 = document.getElementById("code-line-left-3"),
    
    box_code_line_3 = document.getElementById("box-code-line-3"),
    
    box_hidden_3 = document.getElementById("box-hidden-3"),
    
    /*End Variables Gallery 3*/

    
    //---------------------------------------------------------------------------------------------

    /*Start Variables Gallery 4*/
        
    four  = document.getElementById("four"),
    
    img_ga_4 = document.getElementById("img-ga-4"),
    gallery_4  = document.getElementById("gallery-4"),
    
    img_tow_4 = document.getElementById("img-tow-4"),
    
    code_line_right_4 = document.getElementById("code-line-right-4"),
    
    code_line_left_4 = document.getElementById("code-line-left-4"),
    
    box_code_line_4 = document.getElementById("box-code-line-4"),
    
    box_hidden_4 = document.getElementById("box-hidden-4"),
    
    show_loader_ga_1 = document.getElementById("show-loader-ga-1"),
    
    show_loader_ga_2 = document.getElementById("show-loader-ga-2"),
    
    show_loader_ga_3 = document.getElementById("show-loader-ga-3"),
    
    show_loader_ga_4 = document.getElementById("show-loader-ga-4"),
    /*End Variables Gallery 4*/
    
    slider_tow = document.getElementById("slider-tow"),
    
    right_5 = document.getElementById("right-5"),
    
    /*Start Variables Navbar*/
    
    icon_search = document.getElementById("icon-search"),
    box_nav_search = document.getElementById("box-nav-search"), 
    click_show_lists = document.getElementById("click-show-lists"), 
    scroll_lists_nav = document.getElementById("scroll-lists-nav"),
    
    /*Start Variables Lists*/
    
    list_one = document.getElementById("list-one"),
    list_tow = document.getElementById("list-tow"),
    list_three = document.getElementById("list-three"),
    list_four = document.getElementById("list-four"),
        
    /*End Variables Lists*/

    /*End Variables Navbar*/
    
    
    all_element_img_ga = document.getElementById("all-element-img-ga"),
    all_element_img_ga_2 = document.getElementById("all-element-img-ga-2"),
    all_element_img_ga_3 = document.getElementById("all-element-img-ga-3"),
    all_element_img_ga_4 = document.getElementById("all-element-img-ga-4"),
    img_ga_1 = document.getElementById("img-ga-1"),
    text_ga_1 = document.getElementById("text-ga-1"),
    text_ga_2 = document.getElementById("text-ga-2"),
    text_ga_3 = document.getElementById("text-ga-3"),
    text_ga_4 = document.getElementById("text-ga-4"), 
    /*Start Array Gallery-1*/
    
    
    
    name_img_1 = 
    [
        "images/0.png",
        "images/5.png",
        "images/2.png",
        "images/3.png",
        "images/4.png",
        "images/5.png",
        "images/6.png",
        "images/7.png",
        "images/8.png",
        "images/9.png",
        "images/10.png",
        "images/11.png",
        "images/12.png",
        "images/13.png",
        "images/14.png",
        "images/15.png",
        "images/16.png",
        "images/17.png",
        "images/18.png",
        "images/19.png",
        "images/20.png",
        "images/21.png",
        "images/22.png",
        "images/23.png",
        "images/24.png",
        "images/25.png",
        "images/26.png",
        "images/27.png",
        "images/28.png",
        "images/29.png",
        "images/30.png",
        "images/31.png",
        "images/32.png",
        "images/33.png",
        "images/34.png",
        "images/35.png",
        "images/36.png",
        "images/37.png",
        "images/38.png",
        "images/39.png",
        "images/40.png",
        "images/41.png",
        "images/42.png",
        "images/43.png",
        "images/44.png",
        "images/45.png",
        "images/46.png",
        "images/47.png",
        "images/48.png",
        "images/49.png"
    ],
    text_1 =
    [
        'Watch gallery in Alexandria city-1',
        'Watch gallery in Alexandria city-2',
        'Watch gallery in Alexandria city-3',
        "Watch gallery in Alexandria city-4",
        "Watch gallery in Alexandria city-5",
        "Watch gallery in Alexandria city-6",
        "Watch gallery in Alexandria city-7",
        "Watch gallery in Alexandria city-8",
        "Watch gallery in Alexandria city-9",
        "Watch gallery in Alexandria city-10",
        "Watch gallery in Alexandria city-11",
        'Watch gallery in Alexandria city-12',
        'Watch gallery in Alexandria city-13',
        'Watch gallery in Alexandria city-14',
        "Watch gallery in Alexandria city-15",
        "Watch gallery in Alexandria city-16",
        "Watch gallery in Alexandria city-17",
        "Watch gallery in Alexandria city-18",
        "Watch gallery in Alexandria city-19",
        "Watch gallery in Alexandria city-20",
        "Watch gallery in Alexandria city-21",
        "Watch gallery in Alexandria city-22",
        'Watch gallery in Alexandria city-23',
        'Watch gallery in Alexandria city-24',
        'Watch gallery in Alexandria city-25',
        "Watch gallery in Alexandria city-26",
        "Watch gallery in Alexandria city-27",
        "Watch gallery in Alexandria city-28",
        "Watch gallery in Alexandria city-29",
        "Watch gallery in Alexandria city-30",
        "Watch gallery in Alexandria city-31",
        "Watch gallery in Alexandria city-32",
        'Watch gallery in Alexandria city-33',
        'Watch gallery in Alexandria city-34',
        'Watch gallery in Alexandria city-35',
        "Watch gallery in Alexandria city-36",
        "Watch gallery in Alexandria city-37",
        "Watch gallery in Alexandria city-38",
        "Watch gallery in Alexandria city-39",
        "Watch gallery in Alexandria city-40",
        "Watch gallery in Alexandria city-41",
        "Watch gallery in Alexandria city-42",
        "Watch gallery in Alexandria city-43",
        'Watch gallery in Alexandria city-44',
        'Watch gallery in Alexandria city-45',
        'Watch gallery in Alexandria city-46',
        "Watch gallery in Alexandria city-47",
        "Watch gallery in Alexandria city-48",
        "Watch gallery in Alexandria city-49",
        "Watch gallery in Alexandria city-50"
    ],
    input_number_1 =
    [
        '1',
        '2',
        '3',
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "10",
        '11',
        '12',
        '13',
        "14",
        "15",
        "16",
        "17",
        "18",
        "19",
        "20",
        '21',
        '22',
        '23',
        "24",
        "25",
        "26",
        "27",
        "28",
        "29",
        "30",
        "31",
        '32',
        '33',
        '34',
        "35",
        "36",
        "37",
        "38",
        "39",
        "40",
        "41",
        '42',
        '43',
        '44',
        "45",
        "46",
        "47",
        "48",
        "49",
        "50"
    ],
    name_gallery_1 = 
    [
      "Gallery 1",  
      "Gallery 2",  
      "Gallery 3",
      "Gallery 4",
      "Gallery 5",
      "Gallery 6",
      "Gallery 7",
      "Gallery 8",
      "Gallery 9",
      "Gallery 10",
      "Gallery 11",
      "Gallery 12",
      "Gallery 13",
      "Gallery 14",
      "Gallery 15",
      "Gallery 16",
      "Gallery 17",
      "Gallery 18",
      "Gallery 19",
      "Gallery 20",
      "Gallery 21",
      "Gallery 22",
      "Gallery 23",
      "Gallery 24",
      "Gallery 25",
      "Gallery 26",
      "Gallery 27",
      "Gallery 28",
      "Gallery 29",
      "Gallery 30",
      "Gallery 31",
      "Gallery 32",
      "Gallery 33",
      "Gallery 34",
      "Gallery 35",
      "Gallery 36",
      "Gallery 37",
      "Gallery 38",
      "Gallery 39",
      "Gallery 40",
      "Gallery 41",
      "Gallery 42",
      "Gallery 43",
      "Gallery 44",
      "Gallery 45",
      "Gallery 46",
      "Gallery 47",
      "Gallery 48",
      "Gallery 49",
      "Gallery 50"
    ],

    /*End Array Gallery-1*/
    
     /*Start Array Gallery-2*/
    
    name_img_2 = 
    [
        "images/0.png",
        "images/8.png",
        "images/2.png",
        "images/3.png",
        "images/4.png",
        "images/5.png",
        "images/6.png",
        "images/7.png",
        "images/8.png",
        "images/9.png",
        "images/10.png",
        "images/11.png",
        "images/12.png",
        "images/13.png",
        "images/14.png",
        "images/15.png",
        "images/16.png",
        "images/17.png",
        "images/18.png",
        "images/19.png",
        "images/20.png",
        "images/21.png",
        "images/22.png",
        "images/23.png",
        "images/24.png",
        "images/25.png",
        "images/26.png",
        "images/27.png",
        "images/28.png",
        "images/29.png",
        "images/30.png",
        "images/31.png",
        "images/32.png",
        "images/33.png",
        "images/34.png",
        "images/35.png",
        "images/36.png",
        "images/37.png",
        "images/38.png",
        "images/39.png",
        "images/40.png",
        "images/41.png",
        "images/42.png",
        "images/43.png",
        "images/44.png",
        "images/45.png",
        "images/46.png",
        "images/47.png",
        "images/48.png",
        "images/49.png"
    ],
    text_2 =
    [
        'Watch gallery in Alexandria city-1',
        'Watch gallery in Alexandria city-2',
        'Watch gallery in Alexandria city-3',
        "Watch gallery in Alexandria city-4",
        "Watch gallery in Alexandria city-5",
        "Watch gallery in Alexandria city-6",
        "Watch gallery in Alexandria city-7",
        "Watch gallery in Alexandria city-8",
        "Watch gallery in Alexandria city-9",
        "Watch gallery in Alexandria city-10",
        "Watch gallery in Alexandria city-11",
        'Watch gallery in Alexandria city-12',
        'Watch gallery in Alexandria city-13',
        'Watch gallery in Alexandria city-14',
        "Watch gallery in Alexandria city-15",
        "Watch gallery in Alexandria city-16",
        "Watch gallery in Alexandria city-17",
        "Watch gallery in Alexandria city-18",
        "Watch gallery in Alexandria city-19",
        "Watch gallery in Alexandria city-20",
        "Watch gallery in Alexandria city-21",
        "Watch gallery in Alexandria city-22",
        'Watch gallery in Alexandria city-23',
        'Watch gallery in Alexandria city-24',
        'Watch gallery in Alexandria city-25',
        "Watch gallery in Alexandria city-26",
        "Watch gallery in Alexandria city-27",
        "Watch gallery in Alexandria city-28",
        "Watch gallery in Alexandria city-29",
        "Watch gallery in Alexandria city-30",
        "Watch gallery in Alexandria city-31",
        "Watch gallery in Alexandria city-32",
        'Watch gallery in Alexandria city-33',
        'Watch gallery in Alexandria city-34',
        'Watch gallery in Alexandria city-35',
        "Watch gallery in Alexandria city-36",
        "Watch gallery in Alexandria city-37",
        "Watch gallery in Alexandria city-38",
        "Watch gallery in Alexandria city-39",
        "Watch gallery in Alexandria city-40",
        "Watch gallery in Alexandria city-41",
        "Watch gallery in Alexandria city-42",
        "Watch gallery in Alexandria city-43",
        'Watch gallery in Alexandria city-44',
        'Watch gallery in Alexandria city-45',
        'Watch gallery in Alexandria city-46',
        "Watch gallery in Alexandria city-47",
        "Watch gallery in Alexandria city-48",
        "Watch gallery in Alexandria city-49",
        "Watch gallery in Alexandria city-50"
    ],
    name_gallery_2 = 
    [
      "Gallery 1",  
      "Gallery 2",  
      "Gallery 3",
      "Gallery 4",
      "Gallery 5",
      "Gallery 6",
      "Gallery 7",
      "Gallery 8",
      "Gallery 9",
      "Gallery 10",
      "Gallery 11",
      "Gallery 12",
      "Gallery 13",
      "Gallery 14",
      "Gallery 15",
      "Gallery 16",
      "Gallery 17",
      "Gallery 18",
      "Gallery 19",
      "Gallery 20",
      "Gallery 21",
      "Gallery 22",
      "Gallery 23",
      "Gallery 24",
      "Gallery 25",
      "Gallery 26",
      "Gallery 27",
      "Gallery 28",
      "Gallery 29",
      "Gallery 30",
      "Gallery 31",
      "Gallery 32",
      "Gallery 33",
      "Gallery 34",
      "Gallery 35",
      "Gallery 36",
      "Gallery 37",
      "Gallery 38",
      "Gallery 39",
      "Gallery 40",
      "Gallery 41",
      "Gallery 42",
      "Gallery 43",
      "Gallery 44",
      "Gallery 45",
      "Gallery 46",
      "Gallery 47",
      "Gallery 48",
      "Gallery 49",
      "Gallery 50"
    ],

    /*End Array Gallery-2*/
    
    
    /*Start Array Gallery-2*/
    
    name_img_3 = 
    [
        "images/0.png",
        "images/34.png",
        "images/2.png",
        "images/3.png",
        "images/4.png",
        "images/5.png",
        "images/6.png",
        "images/7.png",
        "images/8.png",
        "images/9.png",
        "images/10.png",
        "images/11.png",
        "images/12.png",
        "images/13.png",
        "images/14.png",
        "images/15.png",
        "images/16.png",
        "images/17.png",
        "images/18.png",
        "images/19.png",
        "images/20.png",
        "images/21.png",
        "images/22.png",
        "images/23.png",
        "images/24.png",
        "images/25.png",
        "images/26.png",
        "images/27.png",
        "images/28.png",
        "images/29.png",
        "images/30.png",
        "images/31.png",
        "images/32.png",
        "images/33.png",
        "images/34.png",
        "images/35.png",
        "images/36.png",
        "images/37.png",
        "images/38.png",
        "images/39.png",
        "images/40.png",
        "images/41.png",
        "images/42.png",
        "images/43.png",
        "images/44.png",
        "images/45.png",
        "images/46.png",
        "images/47.png",
        "images/48.png",
        "images/49.png"
    ],
    text_3 =
    [
        'Watch gallery in Alexandria city-1',
        'Watch gallery in Alexandria city-2',
        'Watch gallery in Alexandria city-3',
        "Watch gallery in Alexandria city-4",
        "Watch gallery in Alexandria city-5",
        "Watch gallery in Alexandria city-6",
        "Watch gallery in Alexandria city-7",
        "Watch gallery in Alexandria city-8",
        "Watch gallery in Alexandria city-9",
        "Watch gallery in Alexandria city-10",
        "Watch gallery in Alexandria city-11",
        'Watch gallery in Alexandria city-12',
        'Watch gallery in Alexandria city-13',
        'Watch gallery in Alexandria city-14',
        "Watch gallery in Alexandria city-15",
        "Watch gallery in Alexandria city-16",
        "Watch gallery in Alexandria city-17",
        "Watch gallery in Alexandria city-18",
        "Watch gallery in Alexandria city-19",
        "Watch gallery in Alexandria city-20",
        "Watch gallery in Alexandria city-21",
        "Watch gallery in Alexandria city-22",
        'Watch gallery in Alexandria city-23',
        'Watch gallery in Alexandria city-24',
        'Watch gallery in Alexandria city-25',
        "Watch gallery in Alexandria city-26",
        "Watch gallery in Alexandria city-27",
        "Watch gallery in Alexandria city-28",
        "Watch gallery in Alexandria city-29",
        "Watch gallery in Alexandria city-30",
        "Watch gallery in Alexandria city-31",
        "Watch gallery in Alexandria city-32",
        'Watch gallery in Alexandria city-33',
        'Watch gallery in Alexandria city-34',
        'Watch gallery in Alexandria city-35',
        "Watch gallery in Alexandria city-36",
        "Watch gallery in Alexandria city-37",
        "Watch gallery in Alexandria city-38",
        "Watch gallery in Alexandria city-39",
        "Watch gallery in Alexandria city-40",
        "Watch gallery in Alexandria city-41",
        "Watch gallery in Alexandria city-42",
        "Watch gallery in Alexandria city-43",
        'Watch gallery in Alexandria city-44',
        'Watch gallery in Alexandria city-45',
        'Watch gallery in Alexandria city-46',
        "Watch gallery in Alexandria city-47",
        "Watch gallery in Alexandria city-48",
        "Watch gallery in Alexandria city-49",
        "Watch gallery in Alexandria city-50"
    ],
    name_gallery_3 = 
    [
      "Gallery 3",  
      "Gallery 3",  
      "Gallery 3",
      "Gallery 4",
      "Gallery 5",
      "Gallery 6",
      "Gallery 7",
      "Gallery 8",
      "Gallery 9",
      "Gallery 10",
      "Gallery 11",
      "Gallery 12",
      "Gallery 13",
      "Gallery 14",
      "Gallery 15",
      "Gallery 16",
      "Gallery 17",
      "Gallery 18",
      "Gallery 19",
      "Gallery 20",
      "Gallery 21",
      "Gallery 22",
      "Gallery 23",
      "Gallery 24",
      "Gallery 25",
      "Gallery 26",
      "Gallery 27",
      "Gallery 28",
      "Gallery 29",
      "Gallery 30",
      "Gallery 31",
      "Gallery 32",
      "Gallery 33",
      "Gallery 34",
      "Gallery 35",
      "Gallery 36",
      "Gallery 37",
      "Gallery 38",
      "Gallery 39",
      "Gallery 40",
      "Gallery 41",
      "Gallery 42",
      "Gallery 43",
      "Gallery 44",
      "Gallery 45",
      "Gallery 46",
      "Gallery 47",
      "Gallery 48",
      "Gallery 49",
      "Gallery 50"
    ],

    /*End Array Gallery-3*/
    
    
    /*Start Array Gallery-4*/
    
    name_img_4 = 
    [
        "images/0.png",
        "images/27.png",
        "images/2.png",
        "images/3.png",
        "images/4.png",
        "images/5.png",
        "images/6.png",
        "images/7.png",
        "images/8.png",
        "images/9.png",
        "images/10.png",
        "images/11.png",
        "images/12.png",
        "images/13.png",
        "images/14.png",
        "images/15.png",
        "images/16.png",
        "images/17.png",
        "images/18.png",
        "images/19.png",
        "images/20.png",
        "images/21.png",
        "images/22.png",
        "images/23.png",
        "images/24.png",
        "images/25.png",
        "images/26.png",
        "images/27.png",
        "images/28.png",
        "images/29.png",
        "images/30.png",
        "images/31.png",
        "images/32.png",
        "images/33.png",
        "images/34.png",
        "images/35.png",
        "images/36.png",
        "images/37.png",
        "images/38.png",
        "images/39.png",
        "images/40.png",
        "images/41.png",
        "images/42.png",
        "images/43.png",
        "images/44.png",
        "images/45.png",
        "images/46.png",
        "images/47.png",
        "images/48.png",
        "images/49.png"
    ],
   text_4 =
    [
        'Watch gallery in Alexandria city-1',
        'Watch gallery in Alexandria city-2',
        'Watch gallery in Alexandria city-3',
        "Watch gallery in Alexandria city-4",
        "Watch gallery in Alexandria city-5",
        "Watch gallery in Alexandria city-6",
        "Watch gallery in Alexandria city-7",
        "Watch gallery in Alexandria city-8",
        "Watch gallery in Alexandria city-9",
        "Watch gallery in Alexandria city-10",
        "Watch gallery in Alexandria city-11",
        'Watch gallery in Alexandria city-12',
        'Watch gallery in Alexandria city-13',
        'Watch gallery in Alexandria city-14',
        "Watch gallery in Alexandria city-15",
        "Watch gallery in Alexandria city-16",
        "Watch gallery in Alexandria city-17",
        "Watch gallery in Alexandria city-18",
        "Watch gallery in Alexandria city-19",
        "Watch gallery in Alexandria city-20",
        "Watch gallery in Alexandria city-21",
        "Watch gallery in Alexandria city-22",
        'Watch gallery in Alexandria city-23',
        'Watch gallery in Alexandria city-24',
        'Watch gallery in Alexandria city-25',
        "Watch gallery in Alexandria city-26",
        "Watch gallery in Alexandria city-27",
        "Watch gallery in Alexandria city-28",
        "Watch gallery in Alexandria city-29",
        "Watch gallery in Alexandria city-30",
        "Watch gallery in Alexandria city-31",
        "Watch gallery in Alexandria city-32",
        'Watch gallery in Alexandria city-33',
        'Watch gallery in Alexandria city-34',
        'Watch gallery in Alexandria city-35',
        "Watch gallery in Alexandria city-36",
        "Watch gallery in Alexandria city-37",
        "Watch gallery in Alexandria city-38",
        "Watch gallery in Alexandria city-39",
        "Watch gallery in Alexandria city-40",
        "Watch gallery in Alexandria city-41",
        "Watch gallery in Alexandria city-42",
        "Watch gallery in Alexandria city-43",
        'Watch gallery in Alexandria city-44',
        'Watch gallery in Alexandria city-45',
        'Watch gallery in Alexandria city-46',
        "Watch gallery in Alexandria city-47",
        "Watch gallery in Alexandria city-48",
        "Watch gallery in Alexandria city-49",
        "Watch gallery in Alexandria city-50"
    ],
    name_gallery_4 = 
    [
      "Gallery 4",  
      "Gallery 4",  
      "Gallery 4",
      "Gallery 4",
      "Gallery 5",
      "Gallery 6",
      "Gallery 7",
      "Gallery 8",
      "Gallery 9",
      "Gallery 10",
      "Gallery 11",
      "Gallery 12",
      "Gallery 13",
      "Gallery 14",
      "Gallery 15",
      "Gallery 16",
      "Gallery 17",
      "Gallery 18",
      "Gallery 19",
      "Gallery 20",
      "Gallery 21",
      "Gallery 22",
      "Gallery 23",
      "Gallery 24",
      "Gallery 25",
      "Gallery 26",
      "Gallery 27",
      "Gallery 28",
      "Gallery 29",
      "Gallery 30",
      "Gallery 31",
      "Gallery 32",
      "Gallery 33",
      "Gallery 34",
      "Gallery 35",
      "Gallery 36",
      "Gallery 37",
      "Gallery 38",
      "Gallery 39",
      "Gallery 40",
      "Gallery 41",
      "Gallery 42",
      "Gallery 43",
      "Gallery 44",
      "Gallery 45",
      "Gallery 46",
      "Gallery 47",
      "Gallery 48",
      "Gallery 49",
      "Gallery 50"
    ],
    prod = 
    [
      "none",  
      "block"
    ],

    /*End Array Gallery-4*/
    
    links_pages_prodacts = 
    [
        "page-section-prodact/gallery-section-1.html",
        "page-section-prodact/gallery-section-2.html",
        "page-section-prodact/gallery-section-3.html",
        "page-section-prodact/gallery-section-4.html",
        "page-section-prodact/gallery-section-5.html"
    ]
    
     counter = 0;
    
    
    


/*Start Function Navbar*/

icon_search.onclick = function () {
    
    box_nav_search.classList.toggle("toggle-box-nav-search");
    scroll_lists_nav.classList.remove("toggle-box-scroll-lists-nav")
    
};

click_show_lists.onclick = function () {
    
    scroll_lists_nav.classList.toggle("toggle-box-scroll-lists-nav");
    box_nav_search.classList.remove("toggle-box-nav-search");
    
    list_one .style.animation = "fade-bottom .5s ease forwards 1s";
    list_tow .style.animation = "fade-bottom-2 .6s ease forwards 1.4s";
    list_three .style.animation = "fade-bottom-3 .7s ease forwards 1.8s";
    list_four .style.animation = "fade-bottom-4 .8s ease forwards 2.2s";
    
}
/*End Function Navbar*/
    
img_2.onclick = function () {

    
    
    img.style.transform = "scale(1.5)";    
    
    
    
    overflow.style.visibility = "visible";
    overflow.style.opacity = "1";
    
    
    
    one.style.top = "75px";
    one.style.visibility = "visible";
    
    tow.style.top = "175px";
    tow.style.visibility = "visible";
    
    three.style.top = "275px";
    three.style.visibility = "visible";
    
    four.style.top = "375px";
    four.style.visibility = "visible";
    
    styleElem.innerHTML = ".tow .line-1:after {animation: circle .5s ease forwards 1s} .tow .line-2:after {animation: circle .5s ease forwards 2s} .tow .line-3:after {animation: circle .5s ease forwards 2.5s} .tow .line-4:after {animation: circle .5s ease forwards 3.5s}";    
    /*Start Animatino Gallery 1*/
    
    
    img_tow.style.animation = "asdf .7s ease forwards 1.5s";
    
    code_line_right.style.animation = "fade-in-out .1s ease forwards 2.3s infinite";
    code_line_left.style.animation = "fade-in-out .1s ease forwards 2.5s infinite";
    
    
    box_code_line.style.animation = "move-box-code 1.3s ease 2.7s forwards 1";
    
    
    
    box_hidden.style.animation = "move-move .5s ease forwards 3s";
    
    /*End Animatino Gallery 1*/
    
    
    //---------------------------------------------------------------------------------------------
    
    /*Start Animation Gallery 2*/
    
    img_tow_2.style.animation = "asdf .7s ease forwards 2.3s"; //+.8
    
    box_code_line_2.style.animation = "move-box-code 1.3s ease 3.5s forwards 1"; //+ .8
    
    code_line_right_2.style.animation = "fade-in-out .1s ease forwards 3.1s infinite"; // + .8
    code_line_left_2.style.animation = "fade-in-out .1s ease forwards 3.3s infinite"; // + .8
        
    box_hidden_2.style.animation = "move-move .5s ease forwards 3.8s"; //+.8
    /*End Animation Gallery 2*/
    
    //---------------------------------------------------------------------------------------------
    
    /*Start Animation Gallery 3*/
    img_tow_3.style.animation = "asdf .7s ease forwards 3.1s"; // .+8
    
    box_code_line_3.style.animation = "move-box-code 1.3s ease 4.3s forwards 1"; //. +8
    
    code_line_right_3.style.animation = "fade-in-out .1s ease forwards 3.9s infinite"; //.8
    code_line_left_3.style.animation = "fade-in-out .1s ease forwards 3.3s infinite"; // .8
    
    
    
    box_hidden_3.style.animation = "move-move .5s ease forwards 4.6s";  // +.8
    /*End Animation Gallery 3*/
    
    //---------------------------------------------------------------------------------------------
    
    /*Start Animation Gallery 4*/
    img_tow_4.style.animation = "asdf .7s ease forwards 3.9s";
    
    box_code_line_4.style.animation = "move-box-code 1.3s ease 5.1s forwards 1";
    
    code_line_right_4.style.animation = "fade-in-out .1s ease forwards 4.7s infinite";
    code_line_left_4.style.animation = "fade-in-out .1s ease forwards 4.1s infinite";
    
    box_hidden_4.style.animation = "move-move .5s ease forwards 5.4s";
    /*End Animation Gallery 4*/
    
    
    
    /*Start Animation Loader-img-ga*/
    
    show_loader_ga_1.style.animation = "fadi-in-loader-ga 1s ease-in-out forwards 2.3s";
    show_loader_ga_2.style.animation = "fadi-in-loader-ga 1s ease-in-out forwards 3s";
    show_loader_ga_3.style.animation = "fadi-in-loader-ga 1s ease-in-out forwards 3.7s";
    show_loader_ga_4.style.animation = "fadi-in-loader-ga 1s ease-in-out forwards 4.4s";
    
    /*End Animation Loader-img-ga*/

    
    slider_tow.style.animation = "move-img-slider 5s linear infinite";
    

    
    /*right_5.style.visibility = "visible";
    right_5.style.opacity = "1";*/
    
}

/*Start arrwo_right_big*/    
    
    /*STart Data section prodacts gallery 1*/

    var icone_section_prodacts_1 = document.getElementById("icone-section-prodacts-1"),
        page_pages_section_prodacts = document.getElementById("page-pages-section-prodacts"),
        close_page_prodacts = document.getElementById("close-page-prodacts"),
        img_section_prodacts_gallery_1_1 = document.getElementById("img-section-prodacts-gallery-1-1"),
        img_section_prodacts_gallery_1_2 = document.getElementById("img-section-prodacts-gallery-1-2"),
        img_section_prodacts_gallery_1_3 = document.getElementById("img-section-prodacts-gallery-1-3"),
        img_section_prodacts_gallery_1_4 = document.getElementById("img-section-prodacts-gallery-1-4"),
        img_section_prodacts_gallery_1_5 = document.getElementById("img-section-prodacts-gallery-1-5"),
        img_section_prodacts_gallery_1_6 = document.getElementById("img-section-prodacts-gallery-1-6"),
        img_section_prodacts_gallery_1_7 = document.getElementById("img-section-prodacts-gallery-1-7"),
        img_section_prodacts_gallery_1_8 = document.getElementById("img-section-prodacts-gallery-1-8"),
        img_section_prodacts_gallery_1_9 = document.getElementById("img-section-prodacts-gallery-1-9"),
        img_section_prodacts_gallery_1_10 = document.getElementById("img-section-prodacts-gallery-1-10"),
        img_section_prodacts_gallery_1_11 = document.getElementById("img-section-prodacts-gallery-1-11"),
        img_section_prodacts_gallery_1_12 = document.getElementById("img-section-prodacts-gallery-1-12"),
        
        /*Name*/
        name_section_prodacts_1_1 = document.getElementById("name-section-prodacts-1-1"),
        name_section_prodacts_1_2 = document.getElementById("name-section-prodacts-1-2"),
        name_section_prodacts_1_3 = document.getElementById("name-section-prodacts-1-3"),
        name_section_prodacts_1_4 = document.getElementById("name-section-prodacts-1-4"),
        name_section_prodacts_1_5 = document.getElementById("name-section-prodacts-1-5"),
        name_section_prodacts_1_6 = document.getElementById("name-section-prodacts-1-6"),
        name_section_prodacts_1_7 = document.getElementById("name-section-prodacts-1-7"),
        name_section_prodacts_1_8 = document.getElementById("name-section-prodacts-1-8"),
        name_section_prodacts_1_9 = document.getElementById("name-section-prodacts-1-9"),
        name_section_prodacts_1_10 = document.getElementById("name-section-prodacts-1-10"),
        name_section_prodacts_1_11 = document.getElementById("name-section-prodacts-1-11"),
        name_section_prodacts_1_12 = document.getElementById("name-section-prodacts-1-12"),
        
        /*intro*/
        intro_section_prodacts_1_1 = document.getElementById("intro-section-prodacts-1-1"),
        intro_section_prodacts_1_2 = document.getElementById("intro-section-prodacts-1-2"),
        intro_section_prodacts_1_3 = document.getElementById("intro-section-prodacts-1-3"),
        intro_section_prodacts_1_4 = document.getElementById("intro-section-prodacts-1-4"),
        intro_section_prodacts_1_5 = document.getElementById("intro-section-prodacts-1-5"),
        intro_section_prodacts_1_6 = document.getElementById("intro-section-prodacts-1-6"),
        intro_section_prodacts_1_7 = document.getElementById("intro-section-prodacts-1-7"),
        intro_section_prodacts_1_8 = document.getElementById("intro-section-prodacts-1-8"),
        intro_section_prodacts_1_9 = document.getElementById("intro-section-prodacts-1-9"),
        intro_section_prodacts_1_10 = document.getElementById("intro-section-prodacts-1-10"),
        intro_section_prodacts_1_11 = document.getElementById("intro-section-prodacts-1-11"),
        intro_section_prodacts_1_12 = document.getElementById("intro-section-prodacts-1-12"),
    
    
    name_img_section_prodacts_gallery_1_1 = 
    [
        
      "images/0.png",
      "images/1.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
        
    ],
    
    name_img_section_prodacts_gallery_1_2 = 
    [
        
      "images/0.png",
      "images/1.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
        
    ],
    
    name_img_section_prodacts_gallery_1_3 = 
    [
        
      "images/0.png",
      "images/1.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
        
    ],
    name_img_section_prodacts_gallery_1_4 = 
    [
        
      "images/0.png",
      "images/1.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    
     name_img_section_prodacts_gallery_1_5 = 
    [
        
      "images/0.png",
      "images/1.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_1_6 = 
    [
      "images/0.png",
      "images/1.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
        name_img_section_prodacts_gallery_1_7 = 
    [
      "images/0.png",
      "images/1.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
        name_img_section_prodacts_gallery_1_8 = 
    [
      "images/0.png",
      "images/1.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
        name_img_section_prodacts_gallery_1_9 = 
    [
      "images/0.png",
      "images/1.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
        name_img_section_prodacts_gallery_1_10 = 
    [
      "images/0.png",
      "images/1.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
        name_img_section_prodacts_gallery_1_11 = 
    [
      "images/0.png",
      "images/1.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
        name_img_section_prodacts_gallery_1_12 = 
    [
      "images/0.png",
      "images/1.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
        
    data_name_1_1 = 
    [

    "Tv",
    "Tv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],
        
        
    data_name_1_2 = 
    [

    "Tv",
    "Tv-2",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
        
    data_name_1_3 = 
    [

    "Tv",
    "Tv-3",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],   
        
    data_name_1_4 = 
    [

    "Tv",
    "Tv-4",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
    data_name_1_5 = 
    [

    "Tv",
    "Tv-5",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],   
        
    data_name_1_6 = 
    [

    "Tv",
    "Tv-6",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
    data_name_1_7 = 
    [

    "Tv",
    "Tv-7",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],
        
    data_name_1_8 = 
    [

    "Tv",
    "Tv-8",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ], 
        
    data_name_1_9 = 
    [

    "Tv",
    "Tv-9",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
    data_name_1_10 = 
    [

    "Tv",
    "Tv-10",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
    data_name_1_11 = 
    [

    "Tv",
    "Tv-11",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],    
        
    
    data_name_1_12 = 
    [

    "Tv",
    "Tv-12",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],    
        
        
    data_intro_1_1 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-22222222",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],
        
        
    data_intro_1_2 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-22222222",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],  
    data_intro_1_3 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-22222222",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],    
        
    data_intro_1_4 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-22222222",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],   
        
    data_intro_1_5 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-22222222",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],     
        
    data_intro_1_6 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-22222222",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],   
        
    data_intro_1_7 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-22222222",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ], 
        
    data_intro_1_8 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-22222222",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ], 
        
    data_intro_1_9 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-22222222",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],  
        
    data_intro_1_10 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-22222222",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],     
        
    data_intro_1_11 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-22222222",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],    
    data_intro_1_12 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-22222222",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],     
    /*End Data section prodacts gallery 1*/
    
    

    /*STart Data section prodacts gallery 2*/
    
        icone_section_prodacts_2 = document.getElementById("icone-section-prodacts-2"),
        page_pages_section_prodacts_2 = document.getElementById("page-pages-section-prodacts-2"),
        close_page_prodacts_2 = document.getElementById("close-page-prodacts-2"),
        img_section_prodacts_gallery_2_1 = document.getElementById("img-section-prodacts-gallery-2-1"),
        img_section_prodacts_gallery_2_2 = document.getElementById("img-section-prodacts-gallery-2-2"),
        img_section_prodacts_gallery_2_3 = document.getElementById("img-section-prodacts-gallery-2-3"),
        img_section_prodacts_gallery_2_4 = document.getElementById("img-section-prodacts-gallery-2-4"),
        img_section_prodacts_gallery_2_5 = document.getElementById("img-section-prodacts-gallery-2-5"),
        img_section_prodacts_gallery_2_6 = document.getElementById("img-section-prodacts-gallery-2-6"),
        img_section_prodacts_gallery_2_7 = document.getElementById("img-section-prodacts-gallery-2-7"),
        img_section_prodacts_gallery_2_8 = document.getElementById("img-section-prodacts-gallery-2-8"),
        img_section_prodacts_gallery_2_9 = document.getElementById("img-section-prodacts-gallery-2-9"),
        img_section_prodacts_gallery_2_10 = document.getElementById("img-section-prodacts-gallery-2-10"),
        img_section_prodacts_gallery_2_11 = document.getElementById("img-section-prodacts-gallery-2-11"),
        img_section_prodacts_gallery_2_12 = document.getElementById("img-section-prodacts-gallery-2-12"),
        
        
        /*Name 2*/
        name_section_prodacts_2_1 = document.getElementById("name-section-prodacts-2-1"),
        name_section_prodacts_2_2 = document.getElementById("name-section-prodacts-2-2"),
        name_section_prodacts_2_3 = document.getElementById("name-section-prodacts-2-3"),
        name_section_prodacts_2_4 = document.getElementById("name-section-prodacts-2-4"),
        name_section_prodacts_2_5 = document.getElementById("name-section-prodacts-2-5"),
        name_section_prodacts_2_6 = document.getElementById("name-section-prodacts-2-6"),
        name_section_prodacts_2_7 = document.getElementById("name-section-prodacts-2-7"),
        name_section_prodacts_2_8 = document.getElementById("name-section-prodacts-2-8"),
        name_section_prodacts_2_9 = document.getElementById("name-section-prodacts-2-9"),
        name_section_prodacts_2_10 = document.getElementById("name-section-prodacts-2-10"),
        name_section_prodacts_2_11 = document.getElementById("name-section-prodacts-2-11"),
        name_section_prodacts_2_12 = document.getElementById("name-section-prodacts-2-12"),
    
        
        /*intro 2*/
        intro_section_prodacts_2_1 = document.getElementById("intro-section-prodacts-2-1"),
        intro_section_prodacts_2_2 = document.getElementById("intro-section-prodacts-2-2"),
        intro_section_prodacts_2_3 = document.getElementById("intro-section-prodacts-2-3"),
        intro_section_prodacts_2_4 = document.getElementById("intro-section-prodacts-2-4"),
        intro_section_prodacts_2_5 = document.getElementById("intro-section-prodacts-2-5"),
        intro_section_prodacts_2_6 = document.getElementById("intro-section-prodacts-2-6"),
        intro_section_prodacts_2_7 = document.getElementById("intro-section-prodacts-2-7"),
        intro_section_prodacts_2_8 = document.getElementById("intro-section-prodacts-2-8"),
        intro_section_prodacts_2_9 = document.getElementById("intro-section-prodacts-2-9"),
        intro_section_prodacts_2_10 = document.getElementById("intro-section-prodacts-2-10"),
        intro_section_prodacts_2_11 = document.getElementById("intro-section-prodacts-2-11"),
        intro_section_prodacts_2_12 = document.getElementById("intro-section-prodacts-2-12"),
    
    name_img_section_prodacts_gallery_2_1 = 
    [
        
      "images/0.png",
      "images/35.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/2.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
        
    ],
    
    name_img_section_prodacts_gallery_2_2 = 
    [
        
      "images/0.png",
      "images/35.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
        
    ],
    
    name_img_section_prodacts_gallery_2_3 = 
    [
        
      "images/0.png",
      "images/35.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
        
    ],
    name_img_section_prodacts_gallery_2_4 = 
    [
        
      "images/0.png",
      "images/35.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    
     name_img_section_prodacts_gallery_2_5 = 
    [
        
      "images/0.png",
      "images/35.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_2_6 = 
    [
      "images/0.png",
      "images/35.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_2_7 = 
    [
      "images/0.png",
      "images/35.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_2_8 = 
    [
      "images/0.png",
      "images/35.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_2_9 = 
    [
      "images/0.png",
      "images/35.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_2_10 = 
    [
      "images/0.png",
      "images/35.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_2_11 = 
    [
      "images/0.png",
      "images/35.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_2_12 = 
    [
      "images/0.png",
      "images/35.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
        

        
    data_name_2_1 = 
    [

    "Tv",
    "Tvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],
        
        
    data_name_2_2 = 
    [

    "Tv",
    "Tvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
        
    data_name_2_3 = 
    [

    "Tv",
    "Tvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],   
        
    data_name_2_4 = 
    [

    "Tv",
    "Tvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
    data_name_2_5 = 
    [

    "Tv",
    "Tvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],   
        
    data_name_2_6 = 
    [

    "Tv",
    "Tvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
    data_name_2_7 = 
    [

    "Tv",
    "Tvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],
        
    data_name_2_8 = 
    [

    "Tv",
    "Tvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ], 
        
    data_name_2_9 = 
    [

    "Tv",
    "Tvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
    data_name_2_10 = 
    [

    "Tv",
    "Tvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
    data_name_2_11 = 
    [

    "Tv",
    "Tvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],    
        
    
    data_name_2_12 = 
    [

    "Tv",
    "Tvvvv-1",
    "Tvv-2",
    "Tvv-3",
    "Tvv-4",
    "Tvv-5",
    "Tvv-6",
    "Tvv-7",
    "Tvv-8",
    "Tvv-9",
    "Tvv-10",          
    "Tvv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],    
        
        
        
    data_intro_2_1 = 
    [
        
        
    "introduction-2-1",
    "introduction-2-3333333333",
    "introduction-2-3",
    "introduction-2-4",
    "introduction-2-5",
    "introduction-2-4",
    "introduction-2-7",
    "introduction-2-8",
    "introduction-2-9",
    "introduction-2-10",
    "introduction-2-11",
    "introduction-2-12"
    
        
    ],
        
        
    data_intro_2_2 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-3333333333",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],  
    data_intro_2_3 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-3333333333",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],    
        
    data_intro_2_4 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-3333333333",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],   
        
    data_intro_2_5 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-3333333333",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],     
        
    data_intro_2_6 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-3333333333",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],   
        
    data_intro_2_7 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-3333333333",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ], 
        
    data_intro_2_8 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-22222222",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ], 
        
    data_intro_2_9 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-3333333333",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],  
        
    data_intro_2_10 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-3333333333",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],     
        
    data_intro_2_11 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-3333333333",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],    
    data_intro_2_12 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-3333333333",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    ],     
    /*End Data section prodacts gallery 2*/

    
    
    
    /*STart Data section prodacts gallery 3*/
    
        icone_section_prodacts_3 = document.getElementById("icone-section-prodacts-3"),
        page_pages_section_prodacts_3 = document.getElementById("page-pages-section-prodacts-3"),
        close_page_prodacts_3 = document.getElementById("close-page-prodacts-3"),
        img_section_prodacts_gallery_3_1 = document.getElementById("img-section-prodacts-gallery-3-1"),
        img_section_prodacts_gallery_3_2 = document.getElementById("img-section-prodacts-gallery-3-2"),
        img_section_prodacts_gallery_3_3 = document.getElementById("img-section-prodacts-gallery-3-3"),
        img_section_prodacts_gallery_3_4 = document.getElementById("img-section-prodacts-gallery-3-4"),
        img_section_prodacts_gallery_3_5 = document.getElementById("img-section-prodacts-gallery-3-5"),
        img_section_prodacts_gallery_3_6 = document.getElementById("img-section-prodacts-gallery-3-6"),
        img_section_prodacts_gallery_3_7 = document.getElementById("img-section-prodacts-gallery-3-7"),
        img_section_prodacts_gallery_3_8 = document.getElementById("img-section-prodacts-gallery-3-8"),
        img_section_prodacts_gallery_3_9 = document.getElementById("img-section-prodacts-gallery-3-9"),
        img_section_prodacts_gallery_3_10 = document.getElementById("img-section-prodacts-gallery-3-10"),
        img_section_prodacts_gallery_3_11 = document.getElementById("img-section-prodacts-gallery-3-11"),
        img_section_prodacts_gallery_3_12 = document.getElementById("img-section-prodacts-gallery-3-12"),
        
        
        /*Name 3*/
        name_section_prodacts_3_1 = document.getElementById("name-section-prodacts-3-1"),
        name_section_prodacts_3_2 = document.getElementById("name-section-prodacts-3-2"),
        name_section_prodacts_3_3 = document.getElementById("name-section-prodacts-3-3"),
        name_section_prodacts_3_4 = document.getElementById("name-section-prodacts-3-4"),
        name_section_prodacts_3_5 = document.getElementById("name-section-prodacts-3-5"),
        name_section_prodacts_3_6 = document.getElementById("name-section-prodacts-3-6"),
        name_section_prodacts_3_7 = document.getElementById("name-section-prodacts-3-7"),
        name_section_prodacts_3_8 = document.getElementById("name-section-prodacts-3-8"),
        name_section_prodacts_3_9 = document.getElementById("name-section-prodacts-3-9"),
        name_section_prodacts_3_10 = document.getElementById("name-section-prodacts-3-10"),
        name_section_prodacts_3_11 = document.getElementById("name-section-prodacts-3-11"),
        name_section_prodacts_3_12 = document.getElementById("name-section-prodacts-3-12"),
      
        
        /*intro 3*/
        intro_section_prodacts_3_1 = document.getElementById("intro-section-prodacts-3-1"),
        intro_section_prodacts_3_2 = document.getElementById("intro-section-prodacts-3-2"),
        intro_section_prodacts_3_3 = document.getElementById("intro-section-prodacts-3-3"),
        intro_section_prodacts_3_4 = document.getElementById("intro-section-prodacts-3-4"),
        intro_section_prodacts_3_5 = document.getElementById("intro-section-prodacts-3-5"),
        intro_section_prodacts_3_6 = document.getElementById("intro-section-prodacts-3-6"),
        intro_section_prodacts_3_7 = document.getElementById("intro-section-prodacts-3-7"),
        intro_section_prodacts_3_8 = document.getElementById("intro-section-prodacts-3-8"),
        intro_section_prodacts_3_9 = document.getElementById("intro-section-prodacts-3-9"),
        intro_section_prodacts_3_10 = document.getElementById("intro-section-prodacts-3-10"),
        intro_section_prodacts_3_11 = document.getElementById("intro-section-prodacts-3-11"),
        intro_section_prodacts_3_12 = document.getElementById("intro-section-prodacts-3-12"),
    
    name_img_section_prodacts_gallery_3_1 = 
    [
        
      "images/0.png",
      "images/25.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/2.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
        
    ],
    
    name_img_section_prodacts_gallery_3_2 = 
    [
        
      "images/0.png",
      "images/25.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
        
    ],
    
    name_img_section_prodacts_gallery_3_3 = 
    [
        
      "images/0.png",
      "images/25.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
        
    ],
    name_img_section_prodacts_gallery_3_4 = 
    [
        
      "images/0.png",
      "images/25.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    
     name_img_section_prodacts_gallery_3_5 = 
    [
        
      "images/0.png",
      "images/25.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_3_6 = 
    [
      "images/0.png",
      "images/25.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_3_7 = 
    [
      "images/0.png",
      "images/25.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_3_8 = 
    [
      "images/0.png",
      "images/25.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_3_9 = 
    [
      "images/0.png",
      "images/25.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_3_10 = 
    [
      "images/0.png",
      "images/25.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_3_11 = 
    [
      "images/0.png",
      "images/25.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_3_12 = 
    [
      "images/0.png",
      "images/25.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
        
        
        
    data_name_3_1 = 
    [

    "Tv",
    "Tvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],
        
        
    data_name_3_2 = 
    [

    "Tv",
    "Tvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
        
    data_name_3_3 = 
    [

    "Tv",
    "Tvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],   
        
    data_name_3_4 = 
    [

    "Tv",
    "Tvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
    data_name_3_5 = 
    [

    "Tv",
    "Tvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],   
        
    data_name_3_6 = 
    [

    "Tv",
    "Tvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
    data_name_3_7 = 
    [

    "Tv",
    "Tvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],
        
    data_name_3_8 = 
    [

    "Tv",
    "Tvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ], 
        
    data_name_3_9 = 
    [

    "Tv",
    "Tvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
    data_name_3_10 = 
    [

    "Tv",
    "Tvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
    data_name_3_11 = 
    [

    "Tv",
    "Tvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],    
        
    
    data_name_3_12 = 
    [

    "Tv",
    "Tvvvvvvvvvvvv-1",
    "Tvv-2",
    "Tvv-3",
    "Tvv-4",
    "Tvv-5",
    "Tvv-6",
    "Tvv-7",
    "Tvv-8",
    "Tvv-9",
    "Tvv-10",          
    "Tvv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],    
        
        
        
    data_intro_3_1 = 
    [
    "introduction-2-1",
    "introduction-1-4444444444",
    "introduction-2-3",
    "introduction-2-4",
    "introduction-2-5",
    "introduction-2-4",
    "introduction-2-7",
    "introduction-2-8",
    "introduction-2-9",
    "introduction-2-10",
    "introduction-2-11",
    "introduction-2-12"
    
        
    ],
        
        
    data_intro_3_2 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-4444444444",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],  
    data_intro_3_3 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-4444444444",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],    
        
    data_intro_3_4 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-4444444444",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],   
        
    data_intro_3_5 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-4444444444",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],     
        
    data_intro_3_6 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-4444444444",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],   
        
    data_intro_3_7 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-4444444444",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ], 
        
    data_intro_3_8 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-4444444444",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ], 
        
    data_intro_3_9 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-4444444444",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],  
        
    data_intro_3_10 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-4444444444",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],     
        
    data_intro_3_11 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-4444444444",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],    
    data_intro_3_12 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-44444444444",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],         
    /*End Data section prodacts gallery 3*/


    /*STart Data section prodacts gallery 4*/
    
        icone_section_prodacts_4 = document.getElementById("icone-section-prodacts-4"),
        page_pages_section_prodacts_4 = document.getElementById("page-pages-section-prodacts-4"),
        close_page_prodacts_4 = document.getElementById("close-page-prodacts-4"),
        img_section_prodacts_gallery_4_1 = document.getElementById("img-section-prodacts-gallery-4-1"),
        img_section_prodacts_gallery_4_2 = document.getElementById("img-section-prodacts-gallery-4-2"),
        img_section_prodacts_gallery_4_3 = document.getElementById("img-section-prodacts-gallery-4-3"),
        img_section_prodacts_gallery_4_4 = document.getElementById("img-section-prodacts-gallery-4-4"),
        img_section_prodacts_gallery_4_5 = document.getElementById("img-section-prodacts-gallery-4-5"),
        img_section_prodacts_gallery_4_6 = document.getElementById("img-section-prodacts-gallery-4-6"),
        img_section_prodacts_gallery_4_7 = document.getElementById("img-section-prodacts-gallery-4-7"),
        img_section_prodacts_gallery_4_8 = document.getElementById("img-section-prodacts-gallery-4-8"),
        img_section_prodacts_gallery_4_9 = document.getElementById("img-section-prodacts-gallery-4-9"),
        img_section_prodacts_gallery_4_10 = document.getElementById("img-section-prodacts-gallery-4-10"),
        img_section_prodacts_gallery_4_11 = document.getElementById("img-section-prodacts-gallery-4-11"),
        img_section_prodacts_gallery_4_12 = document.getElementById("img-section-prodacts-gallery-4-12"),
        
        
        /*Name 4*/
        name_section_prodacts_4_1 = document.getElementById("name-section-prodacts-4-1"),
        name_section_prodacts_4_2 = document.getElementById("name-section-prodacts-4-2"),
        name_section_prodacts_4_3 = document.getElementById("name-section-prodacts-4-3"),
        name_section_prodacts_4_4 = document.getElementById("name-section-prodacts-4-4"),
        name_section_prodacts_4_5 = document.getElementById("name-section-prodacts-4-5"),
        name_section_prodacts_4_6 = document.getElementById("name-section-prodacts-4-6"),
        name_section_prodacts_4_7 = document.getElementById("name-section-prodacts-4-7"),
        name_section_prodacts_4_8 = document.getElementById("name-section-prodacts-4-8"),
        name_section_prodacts_4_9 = document.getElementById("name-section-prodacts-4-9"),
        name_section_prodacts_4_10 = document.getElementById("name-section-prodacts-4-10"),
        name_section_prodacts_4_11 = document.getElementById("name-section-prodacts-4-11"),
        name_section_prodacts_4_12 = document.getElementById("name-section-prodacts-4-12"),
    
        
        /*intro 4*/
        intro_section_prodacts_4_1 = document.getElementById("intro-section-prodacts-4-1"),
        intro_section_prodacts_4_2 = document.getElementById("intro-section-prodacts-4-2"),
        intro_section_prodacts_4_3 = document.getElementById("intro-section-prodacts-4-3"),
        intro_section_prodacts_4_4 = document.getElementById("intro-section-prodacts-4-4"),
        intro_section_prodacts_4_5 = document.getElementById("intro-section-prodacts-4-5"),
        intro_section_prodacts_4_6 = document.getElementById("intro-section-prodacts-4-6"),
        intro_section_prodacts_4_7 = document.getElementById("intro-section-prodacts-4-7"),
        intro_section_prodacts_4_8 = document.getElementById("intro-section-prodacts-4-8"),
        intro_section_prodacts_4_9 = document.getElementById("intro-section-prodacts-4-9"),
        intro_section_prodacts_4_10 = document.getElementById("intro-section-prodacts-4-10"),
        intro_section_prodacts_4_11 = document.getElementById("intro-section-prodacts-4-11"),
        intro_section_prodacts_4_12 = document.getElementById("intro-section-prodacts-4-12"),
    
    name_img_section_prodacts_gallery_4_1 = 
    [
        
      "images/0.png",
      "images/15.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/2.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
        
    ],
    
    name_img_section_prodacts_gallery_4_2 = 
    [
        
      "images/0.png",
      "images/15.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
        
    ],
    
    name_img_section_prodacts_gallery_4_3 = 
    [
        
      "images/0.png",
      "images/15.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
        
    ],
    name_img_section_prodacts_gallery_4_4 = 
    [
        
      "images/0.png",
      "images/15.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    
     name_img_section_prodacts_gallery_4_5 = 
    [
        
      "images/0.png",
      "images/15.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_4_6 = 
    [
      "images/0.png",
      "images/15.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_4_7 = 
    [
      "images/0.png",
      "images/15.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_4_8 = 
    [
      "images/0.png",
      "images/15.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_4_9 = 
    [
      "images/0.png",
      "images/15.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_4_10 = 
    [
      "images/0.png",
      "images/15.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_4_11 = 
    [
      "images/0.png",
      "images/15.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
    name_img_section_prodacts_gallery_4_12 = 
    [
      "images/0.png",
      "images/15.png",
      "images/2.png",
      "images/3.png",
      "images/4.png",
      "images/5.png",
      "images/6.png",
      "images/7.png",
      "images/8.png",
      "images/9.png",
      "images/10.png",
      "images/11.png",
      "images/12.png",
      "images/13.png",
      "images/14.png",
      "images/15.png",
      "images/16.png",
      "images/17.png",
      "images/18.png",
      "images/19.png",
      "images/20.png",
      "images/21.png",
      "images/22.png",
      "images/23.png",
      "images/24.png",
      "images/25.png",
      "images/26.png",
      "images/27.png",
      "images/28.png",
      "images/29.png",
      "images/30.png",
      "images/31.png",
      "images/32.png",
      "images/33.png",
      "images/34.png",
      "images/35.png",
      "images/36.png",
      "images/37.png",
      "images/38.png",
      "images/39.png",
      "images/40.png",
      "images/41.png",
      "images/42.png",
      "images/43.png",
      "images/44.png",
      "images/45.png",
      "images/46.png",
      "images/47.png",
      "images/48.png",
      "images/49.png"
    ],
        
        
    data_name_4_1 = 
    [

    "Tv",
    "Tvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],
        
        
    data_name_4_2 = 
    [

    "Tv",
    "Tvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
        
    data_name_4_3 = 
    [

    "Tv",
    "Tvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],   
        
    data_name_4_4 = 
    [

    "Tv",
    "Tvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
    data_name_4_5 = 
    [

    "Tv",
    "Tvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],   
        
    data_name_4_6 = 
    [

    "Tv",
    "Tvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
    data_name_4_7 = 
    [

    "Tv",
    "Tvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],
        
    data_name_4_8 = 
    [

    "Tv",
    "Tvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ], 
        
    data_name_4_9 = 
    [

    "Tv",
    "Tvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
    data_name_4_10 = 
    [

    "Tv",
    "Tvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],  
        
    data_name_4_11 = 
    [

    "Tv",
    "Tvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv-1",
    "Tv-2",
    "Tv-3",
    "Tv-4",
    "Tv-5",
    "Tv-6",
    "Tv-7",
    "Tv-8",
    "Tv-9",
    "Tv-10",          
    "Tv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],    
        
    
    data_name_4_12 = 
    [

    "Tv",
    "Tvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv-1",
    "Tvv-2",
    "Tvv-3",
    "Tvv-4",
    "Tvv-5",
    "Tvv-6",
    "Tvv-7",
    "Tvv-8",
    "Tvv-9",
    "Tvv-10",          
    "Tvv-11",          
    "Tv-12",          
    "Tv-13",          
    "Tv-14",          
    "Tv-15",          
    "Tv-16",          
    "Tv-17",          
    "Tv-18",          
    "Tv-19",          
    "Tv-20",          
    "Tv-21",          
    "Tv-22",          
    "Tv-23",          
    "Tv-24",          
    "Tv-25",          
    "Tv-26",          
    "Tv-27",          
    "Tv-28",          
    "Tv-29",          
    "Tv-30",          
    "Tv-31",          
    "Tv-32",          
    "Tv-33",          
    "Tv-34",          
    "Tv-35",          
    "Tv-36",          
    "Tv-37",          
    "Tv-38",          
    "Tv-39",          
    "Tv-40",          
    "Tv-41",          
    "Tv-42",          
    "Tv-43",          
    "Tv-44",          
    "Tv-45",          
    "Tv-46",          
    "Tv-47",          
    "Tv-48",          
    "Tv-49"        
    ],
        
        
    data_intro_4_1 = 
    [
    "introduction-2-1",
    "introduction-1-5555555555",
    "introduction-2-3",
    "introduction-2-4",
    "introduction-2-5",
    "introduction-2-4",
    "introduction-2-7",
    "introduction-2-8",
    "introduction-2-9",
    "introduction-2-10",
    "introduction-2-11",
    "introduction-2-12"
    
        
    ],
        
        
    data_intro_4_2 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-5555555555",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],  
    data_intro_4_3 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-5555555555",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],    
        
    data_intro_4_4 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-5555555555",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],   
        
    data_intro_4_5 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-5555555555",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],     
        
    data_intro_4_6 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-5555555555",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],   
        
    data_intro_4_7 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-5555555555",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ], 
        
    data_intro_4_8 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-5555555555",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ], 
        
    data_intro_4_9 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-5555555555",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],  
        
    data_intro_4_10 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-5555555555",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],     
        
    data_intro_4_11 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-5555555555",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],    
    data_intro_4_12 = 
    [
        
        
    "introduction-1-1",
    "introduction-1-5555555555",
    "introduction-1-3",
    "introduction-1-4",
    "introduction-1-5",
    "introduction-1-4",
    "introduction-1-7",
    "introduction-1-8",
    "introduction-1-9",
    "introduction-1-10",
    "introduction-1-11",
    "introduction-1-12"
    
        
    ],
    /*End Data section prodacts gallery 4*/
        
        
    name_prodacts_1_1 = document.getElementById("name-prodacts-1-1"),
        
        
    data_name_prodacts_1_1 = 
    [
    "Nokia",
    "Nokia1",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_1_2 = document.getElementById("name-prodacts-1-2"),
        
    data_name_prodacts_1_2 = 
    [
    "Nokia",
    "Nokia22",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    name_prodacts_1_3 = document.getElementById("name-prodacts-1-3"),
        
    data_name_prodacts_1_3 = 
    [
    "Nokia",
    "Nokia33",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
        
    name_prodacts_1_4 = document.getElementById("name-prodacts-1-4"),
        
    data_name_prodacts_1_4 = 
    [
    "Nokia",
    "Nokia44",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_5 = document.getElementById("name-prodacts-1-5"),
        
    data_name_prodacts_1_5 = 
    [
    "Nokia",
    "Nokia55",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    name_prodacts_1_6 = document.getElementById("name-prodacts-1-6"),
        
    data_name_prodacts_1_6 = 
    [
    "Nokia",
    "Nokia66",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    name_prodacts_1_7 = document.getElementById("name-prodacts-1-7"),
        
    data_name_prodacts_1_7 = 
    [
    "Nokia",
    "Nokia77",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_1_8 = document.getElementById("name-prodacts-1-8"),
        
    data_name_prodacts_1_8 = 
    [
    "Nokia",
    "Nokia88",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    name_prodacts_1_9 = document.getElementById("name-prodacts-1-9"),
        
    data_name_prodacts_1_9 = 
    [
    "Nokia",
    "Nokia99",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
    name_prodacts_1_10 = document.getElementById("name-prodacts-1-10"),
        
    data_name_prodacts_1_10 = 
    [
    "Nokia",
    "Nokia1010",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    name_prodacts_1_11 = document.getElementById("name-prodacts-1-11"),
        
    data_name_prodacts_1_11 = 
    [
    "Nokia",
    "Nokia1111",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    name_prodacts_1_12 = document.getElementById("name-prodacts-1-12"),
        
    data_name_prodacts_1_12 = 
    [
    "Nokia",
    "Nokia1212",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_1_13 = document.getElementById("name-prodacts-1-13"),
        
    data_name_prodacts_1_13 = 
    [
    "Nokia",
    "Nokia1313",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
        
    name_prodacts_1_14 = document.getElementById("name-prodacts-1-14"),
        
    data_name_prodacts_1_14 = 
    [
    "Nokia",
    "Nokia1414",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_1_15 = document.getElementById("name-prodacts-1-15"),
        
    data_name_prodacts_1_15 = 
    [
    "Nokia",
    "Nokia1515",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_1_16 = document.getElementById("name-prodacts-1-16"),
        
    data_name_prodacts_1_16 = 
    [
    "Nokia",
    "Nokia1616",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_1_17 = document.getElementById("name-prodacts-1-17"),
        
    data_name_prodacts_1_17 = 
    [
    "Nokia",
    "Nokia1717",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    name_prodacts_1_18 = document.getElementById("name-prodacts-1-18"),
        
    data_name_prodacts_1_18 = 
    [
    "Nokia",
    "Nokia1818",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_19 = document.getElementById("name-prodacts-1-19"),
        
    data_name_prodacts_1_19 = 
    [
    "Nokia",
    "Nokia1919",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_1_20 = document.getElementById("name-prodacts-1-20"),
        
    data_name_prodacts_1_20 = 
    [
    "Nokia",
    "Nokia2020",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_1_21 = document.getElementById("name-prodacts-1-21"),
        
    data_name_prodacts_1_21 = 
    [
    "Nokia",
    "Nokia2121",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_1_22 = document.getElementById("name-prodacts-1-22"),
        
    data_name_prodacts_1_22 = 
    [
    "Nokia",
    "Nokia2222",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_1_23 = document.getElementById("name-prodacts-1-23"),
        
    data_name_prodacts_1_23 = 
    [
    "Nokia",
    "Nokia2323",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_24 = document.getElementById("name-prodacts-1-24"),
        
    data_name_prodacts_1_24 = 
    [
    "Nokia",
    "Nokia2424",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_25 = document.getElementById("name-prodacts-1-25"),
        
    data_name_prodacts_1_25 = 
    [
    "Nokia",
    "Nokia2525",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_26 = document.getElementById("name-prodacts-1-26"),
        
    data_name_prodacts_1_26 = 
    [
    "Nokia",
    "Nokia2626",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_27 = document.getElementById("name-prodacts-1-27"),
        
    data_name_prodacts_1_27 = 
    [
    "Nokia",
    "Nokia2727",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_28 = document.getElementById("name-prodacts-1-28"),
        
    data_name_prodacts_1_28 = 
    [
    "Nokia",
    "Nokia2828",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_29 = document.getElementById("name-prodacts-1-29"),
        
    data_name_prodacts_1_29 = 
    [
    "Nokia",
    "Nokia2929",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_30 = document.getElementById("name-prodacts-1-30"),
        
    data_name_prodacts_1_30 = 
    [
    "Nokia",
    "Nokia3030",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
     
    name_prodacts_1_31 = document.getElementById("name-prodacts-1-31"),
        
    data_name_prodacts_1_31 = 
    [
    "Nokia",
    "Nokia3131",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_32 = document.getElementById("name-prodacts-1-32"),
        
    data_name_prodacts_1_32 = 
    [
    "Nokia",
    "Nokia3232",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_33 = document.getElementById("name-prodacts-1-33"),
        
    data_name_prodacts_1_33 = 
    [
    "Nokia",
    "Nokia3333",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
     name_prodacts_1_34 = document.getElementById("name-prodacts-1-34"),
        
    data_name_prodacts_1_34 = 
    [
    "Nokia",
    "Nokia3434",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_35 = document.getElementById("name-prodacts-1-35"),
        
    data_name_prodacts_1_35 = 
    [
    "Nokia",
    "Nokia3535",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_36 = document.getElementById("name-prodacts-1-36"),
        
    data_name_prodacts_1_36 = 
    [
    "Nokia",
    "Nokia3636",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_37 = document.getElementById("name-prodacts-1-37"),
        
    data_name_prodacts_1_37 = 
    [
    "Nokia",
    "Nokia3030",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_38 = document.getElementById("name-prodacts-1-38"),
        
    data_name_prodacts_1_38 = 
    [
    "Nokia",
    "Nokia3838",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_39 = document.getElementById("name-prodacts-1-39"),
        
    data_name_prodacts_1_39 = 
    [
    "Nokia",
    "Nokia3939",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
    name_prodacts_1_40 = document.getElementById("name-prodacts-1-40"),
        
    data_name_prodacts_1_40 = 
    [
    "Nokia",
    "Nokia4040",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_41 = document.getElementById("name-prodacts-1-41"),
        
    data_name_prodacts_1_41 = 
    [
    "Nokia",
    "Nokia4141",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_42 = document.getElementById("name-prodacts-1-42"),
        
    data_name_prodacts_1_42 = 
    [
    "Nokia",
    "Nokia4242",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_43 = document.getElementById("name-prodacts-1-43"),
        
    data_name_prodacts_1_43 = 
    [
    "Nokia",
    "Nokia4343",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_44 = document.getElementById("name-prodacts-1-44"),
        
    data_name_prodacts_1_44 = 
    [
    "Nokia",
    "Nokia4444",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_45 = document.getElementById("name-prodacts-1-45"),
        
    data_name_prodacts_1_45 = 
    [
    "Nokia",
    "Nokia4545",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_1_46 = document.getElementById("name-prodacts-1-46"),
        
    data_name_prodacts_1_46 = 
    [
    "Nokia",
    "Nokia4646",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_47 = document.getElementById("name-prodacts-1-47"),
        
    data_name_prodacts_1_47 = 
    [
    "Nokia",
    "Nokia4747",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_48 = document.getElementById("name-prodacts-1-48"),
        
    data_name_prodacts_1_48 = 
    [
    "Nokia",
    "Nokia4848",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_49 = document.getElementById("name-prodacts-1-49"),
        
    data_name_prodacts_1_49 = 
    [
    "Nokia",
    "Nokia4949",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_50 = document.getElementById("name-prodacts-1-50"),
        
    data_name_prodacts_1_50 = 
    [
    "Nokia",
    "Nokia5050",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_1_51 = document.getElementById("name-prodacts-1-51"),
        
    data_name_prodacts_1_51 = 
    [
    "Nokia",
    "Nokia5151",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_52 = document.getElementById("name-prodacts-1-52"),
        
    data_name_prodacts_1_52 = 
    [
    "Nokia",
    "Nokia5252",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_53 = document.getElementById("name-prodacts-1-53"),
        
    data_name_prodacts_1_53 = 
    [
    "Nokia",
    "Nokia5353",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_54 = document.getElementById("name-prodacts-1-54"),
        
    data_name_prodacts_1_54 = 
    [
    "Nokia",
    "Nokia5454",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_55 = document.getElementById("name-prodacts-1-55"),
        
    data_name_prodacts_1_55 = 
    [
    "Nokia",
    "Nokia5555",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_56 = document.getElementById("name-prodacts-1-56"),
        
    data_name_prodacts_1_56 = 
    [
    "Nokia",
    "Nokia5656",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_57 = document.getElementById("name-prodacts-1-57"),
        
    data_name_prodacts_1_57 = 
    [
    "Nokia",
    "Nokia5757",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_58 = document.getElementById("name-prodacts-1-58"),
        
    data_name_prodacts_1_58 = 
    [
    "Nokia",
    "Nokia5858",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_59 = document.getElementById("name-prodacts-1-59"),
        
    data_name_prodacts_1_59 = 
    [
    "Nokia",
    "Nokia5959",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_60 = document.getElementById("name-prodacts-1-60"),
        
    data_name_prodacts_1_60 = 
    [
    "Nokia",
    "Nokia6060",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
    name_prodacts_1_61 = document.getElementById("name-prodacts-1-61"),
        
    data_name_prodacts_1_61 = 
    [
    "Nokia",
    "Nokia6161",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_62 = document.getElementById("name-prodacts-1-62"),
        
    data_name_prodacts_1_62 = 
    [
    "Nokia",
    "Nokia6262",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
    name_prodacts_1_63 = document.getElementById("name-prodacts-1-63"),
        
    data_name_prodacts_1_63 = 
    [
    "Nokia",
    "Nokia6363",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_64 = document.getElementById("name-prodacts-1-64"),
        
    data_name_prodacts_1_64 = 
    [
    "Nokia",
    "Nokia6464",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_65 = document.getElementById("name-prodacts-1-65"),
        
    data_name_prodacts_1_65 = 
    [
    "Nokia",
    "Nokia6565",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_66 = document.getElementById("name-prodacts-1-66"),
        
    data_name_prodacts_1_66 = 
    [
    "Nokia",
    "Nokia6666",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_67 = document.getElementById("name-prodacts-1-67"),
        
    data_name_prodacts_1_67 = 
    [
    "Nokia",
    "Nokia6767",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_68 = document.getElementById("name-prodacts-1-68"),
        
    data_name_prodacts_1_68 = 
    [
    "Nokia",
    "Nokia6868",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_69 = document.getElementById("name-prodacts-1-69"),
        
    data_name_prodacts_1_69 = 
    [
    "Nokia",
    "Nokia9090",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_70 = document.getElementById("name-prodacts-1-70"),
        
    data_name_prodacts_1_70 = 
    [
    "Nokia",
    "Nokia7070",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_1_71 = document.getElementById("name-prodacts-1-71"),
        
    data_name_prodacts_1_71 = 
    [
    "Nokia",
    "Nokia7171",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],       
    name_prodacts_1_72 = document.getElementById("name-prodacts-1-72"),
        
    data_name_prodacts_1_72 = 
    [
    "Nokia",
    "Nokia7272",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_73 = document.getElementById("name-prodacts-1-73"),
        
    data_name_prodacts_1_73 = 
    [
    "Nokia",
    "Nokia7373",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_74 = document.getElementById("name-prodacts-1-74"),
        
    data_name_prodacts_1_74 = 
    [
    "Nokia",
    "Nokia7474",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_75 = document.getElementById("name-prodacts-1-75"),
        
    data_name_prodacts_1_75 = 
    [
    "Nokia",
    "Nokia7575",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_76 = document.getElementById("name-prodacts-1-76"),
        
    data_name_prodacts_1_76 = 
    [
    "Nokia",
    "Nokia7676",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_77 = document.getElementById("name-prodacts-1-77"),
        
    data_name_prodacts_1_77 = 
    [
    "Nokia",
    "Nokia7777",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
     name_prodacts_1_78 = document.getElementById("name-prodacts-1-78"),
        
    data_name_prodacts_1_78 = 
    [
    "Nokia",
    "Nokia7878",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_1_79 = document.getElementById("name-prodacts-1-79"),
        
    data_name_prodacts_1_79 = 
    [
    "Nokia",
    "Nokia7979",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_80 = document.getElementById("name-prodacts-1-80"),
        
    data_name_prodacts_1_80 = 
    [
    "Nokia",
    "Nokia8080",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_1_81 = document.getElementById("name-prodacts-1-81"),
        
    data_name_prodacts_1_81 = 
    [
    "Nokia",
    "Nokia8181",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
    name_prodacts_1_82 = document.getElementById("name-prodacts-1-82"),
        
    data_name_prodacts_1_82 = 
    [
    "Nokia",
    "Nokia8282",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_83 = document.getElementById("name-prodacts-1-83"),
        
    data_name_prodacts_1_83 = 
    [
    "Nokia",
    "Nokia8383",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_84 = document.getElementById("name-prodacts-1-84"),
        
    data_name_prodacts_1_84 = 
    [
    "Nokia",
    "Nokia8484",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_85 = document.getElementById("name-prodacts-1-85"),
        
    data_name_prodacts_1_85 = 
    [
    "Nokia",
    "Nokia8585",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_86 = document.getElementById("name-prodacts-1-86"),
        
    data_name_prodacts_1_86 = 
    [
    "Nokia",
    "Nokia8686",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_87 = document.getElementById("name-prodacts-1-87"),
        
    data_name_prodacts_1_87 = 
    [
    "Nokia",
    "Nokia8787",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_88 = document.getElementById("name-prodacts-1-88"),
        
    data_name_prodacts_1_88 = 
    [
    "Nokia",
    "Nokia8888",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_89 = document.getElementById("name-prodacts-1-89"),
        
    data_name_prodacts_1_89 = 
    [
    "Nokia",
    "Nokia8989",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_90 = document.getElementById("name-prodacts-1-90"),
        
    data_name_prodacts_1_90 = 
    [
    "Nokia",
    "Nokia9090",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_91 = document.getElementById("name-prodacts-1-91"),
        
    data_name_prodacts_1_91 = 
    [
    "Nokia",
    "Nokia9191",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_92 = document.getElementById("name-prodacts-1-92"),
        
    data_name_prodacts_1_92 = 
    [
    "Nokia",
    "Nokia9292",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_93 = document.getElementById("name-prodacts-1-93"),
        
    data_name_prodacts_1_93 = 
    [
    "Nokia",
    "Nokia9393",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_94 = document.getElementById("name-prodacts-1-94"),
        
    data_name_prodacts_1_94 = 
    [
    "Nokia",
    "Nokia9494",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_95 = document.getElementById("name-prodacts-1-95"),
        
    data_name_prodacts_1_95 = 
    [
    "Nokia",
    "Nokia9595",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_96 = document.getElementById("name-prodacts-1-96"),
        
    data_name_prodacts_1_96 = 
    [
    "Nokia",
    "Nokia9696",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_97 = document.getElementById("name-prodacts-1-97"),
        
    data_name_prodacts_1_97 = 
    [
    "Nokia",
    "Nokia9797",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_98 = document.getElementById("name-prodacts-1-98"),
        
    data_name_prodacts_1_98 = 
    [
    "Nokia",
    "Nokia9898",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
    name_prodacts_1_99 = document.getElementById("name-prodacts-1-99"),
        
    data_name_prodacts_1_99 = 
    [
    "Nokia",
    "Nokia9999",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_100 = document.getElementById("name-prodacts-1-100"),
        
    data_name_prodacts_1_100 = 
    [
    "Nokia",
    "Nokia100",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_101 = document.getElementById("name-prodacts-1-101"),
        
    data_name_prodacts_1_101 = 
    [
    "Nokia",
    "Nokia101",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_1_102 = document.getElementById("name-prodacts-1-102"),
        
    data_name_prodacts_1_102 = 
    [
    "Nokia",
    "Nokia102",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_103 = document.getElementById("name-prodacts-1-103"),
        
    data_name_prodacts_1_103 = 
    [
    "Nokia",
    "Nokia103",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_104 = document.getElementById("name-prodacts-1-104"),
        
    data_name_prodacts_1_104 = 
    [
    "Nokia",
    "Nokia104",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_1_105 = document.getElementById("name-prodacts-1-105"),
        
    data_name_prodacts_1_105 = 
    [
    "Nokia",
    "Nokia105",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_1_106 = document.getElementById("name-prodacts-1-106"),
        
    data_name_prodacts_1_106 = 
    [
    "Nokia",
    "Nokia106",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
     name_prodacts_1_107 = document.getElementById("name-prodacts-1-107"),
        
    data_name_prodacts_1_107 = 
    [
    "Nokia",
    "Nokia107",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_1_108 = document.getElementById("name-prodacts-1-108"),
        
    data_name_prodacts_1_108 = 
    [
    "Nokia",
    "Nokia108",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
     name_prodacts_1_109 = document.getElementById("name-prodacts-1-109"),
        
    data_name_prodacts_1_109 = 
    [
    "Nokia",
    "Nokia109",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_1_110 = document.getElementById("name-prodacts-1-110"),
        
    data_name_prodacts_1_110 = 
    [
    "Nokia",
    "Nokia110",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
        
    name_prodacts_1_111 = document.getElementById("name-prodacts-1-111"),
        
    data_name_prodacts_1_111 = 
    [
    "Nokia",
    "Nokia111",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_112 = document.getElementById("name-prodacts-1-112"),
        
    data_name_prodacts_1_112 = 
    [
    "Nokia",
    "Nokia112",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_113 = document.getElementById("name-prodacts-1-113"),
        
    data_name_prodacts_1_113 = 
    [
    "Nokia",
    "Nokia113",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_114 = document.getElementById("name-prodacts-1-114"),
        
    data_name_prodacts_1_114 = 
    [
    "Nokia",
    "Nokia114",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
    name_prodacts_1_115 = document.getElementById("name-prodacts-1-115"),
        
    data_name_prodacts_1_115 = 
    [
    "Nokia",
    "Nokia115",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_116 = document.getElementById("name-prodacts-1-116"),
        
    data_name_prodacts_1_116 = 
    [
    "Nokia",
    "Nokia116",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_117 = document.getElementById("name-prodacts-1-117"),
        
    data_name_prodacts_1_117 = 
    [
    "Nokia",
    "Nokia117",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_118 = document.getElementById("name-prodacts-1-118"),
        
    data_name_prodacts_1_118 = 
    [
    "Nokia",
    "Nokia118",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_119 = document.getElementById("name-prodacts-1-119"),
        
    data_name_prodacts_1_119 = 
    [
    "Nokia",
    "Nokia119",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_1_120 = document.getElementById("name-prodacts-1-120"),
        
    data_name_prodacts_1_120 = 
    [
    "Nokia",
    "Nokia120",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    //Gallery 2----------------------------------------------------------------------
        
        
    name_prodacts_2_1 = document.getElementById("name-prodacts-2-1"),
        
        
    data_name_prodacts_2_1 = 
    [
    "Nokia",
    "Nokia2.1",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_2_2 = document.getElementById("name-prodacts-2-2"),
        
    data_name_prodacts_2_2 = 
    [
    "Nokia",
    "Nokia2.2",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    name_prodacts_2_3 = document.getElementById("name-prodacts-2-3"),
        
    data_name_prodacts_2_3 = 
    [
    "Nokia",
    "Nokia2.3",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
        
    name_prodacts_2_4 = document.getElementById("name-prodacts-2-4"),
        
    data_name_prodacts_2_4 = 
    [
    "Nokia",
    "Nokia2.4",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_5 = document.getElementById("name-prodacts-2-5"),
        
    data_name_prodacts_2_5 = 
    [
    "Nokia",
    "Nokia2.5",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    name_prodacts_2_6 = document.getElementById("name-prodacts-2-6"),
        
    data_name_prodacts_2_6 = 
    [
    "Nokia",
    "Nokia2.6",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    name_prodacts_2_7 = document.getElementById("name-prodacts-2-7"),
        
    data_name_prodacts_2_7 = 
    [
    "Nokia",
    "Nokia2.7",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_2_8 = document.getElementById("name-prodacts-2-8"),
        
    data_name_prodacts_2_8 = 
    [
    "Nokia",
    "Nokia2.8",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    name_prodacts_2_9 = document.getElementById("name-prodacts-2-9"),
        
    data_name_prodacts_2_9 = 
    [
    "Nokia",
    "Nokia2.9",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
    name_prodacts_2_10 = document.getElementById("name-prodacts-2-10"),
        
    data_name_prodacts_2_10 = 
    [
    "Nokia",
    "Nokia2.10",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
    
        
        
        
        
    name_prodacts_2_11 = document.getElementById("name-prodacts-2-11"),
        
        
    data_name_prodacts_2_11 = 
    [
    "Nokia",
    "Nokia2.11",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_2_12 = document.getElementById("name-prodacts-2-12"),
        
    data_name_prodacts_2_12 = 
    [
    "Nokia",
    "Nokia2.12",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    name_prodacts_2_13 = document.getElementById("name-prodacts-2-13"),
        
    data_name_prodacts_2_13 = 
    [
    "Nokia",
    "Nokia2.13",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
        
    name_prodacts_2_14 = document.getElementById("name-prodacts-2-14"),
        
    data_name_prodacts_2_14 = 
    [
    "Nokia",
    "Nokia2.14",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_15 = document.getElementById("name-prodacts-2-15"),
        
    data_name_prodacts_2_15 = 
    [
    "Nokia",
    "Nokia2.15",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    name_prodacts_2_16 = document.getElementById("name-prodacts-2-16"),
        
    data_name_prodacts_2_16 = 
    [
    "Nokia",
    "Nokia2.16",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    name_prodacts_2_17 = document.getElementById("name-prodacts-2-17"),
        
    data_name_prodacts_2_17 = 
    [
    "Nokia",
    "Nokia2.17",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_2_18 = document.getElementById("name-prodacts-2-18"),
        
    data_name_prodacts_2_18 = 
    [
    "Nokia",
    "Nokia2.18",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    name_prodacts_2_19 = document.getElementById("name-prodacts-2-19"),
        
    data_name_prodacts_2_19 = 
    [
    "Nokia",
    "Nokia2.19",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
    name_prodacts_2_20 = document.getElementById("name-prodacts-2-20"),
        
    data_name_prodacts_2_20 = 
    [
    "Nokia",
    "Nokia2.20",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_2_21 = document.getElementById("name-prodacts-2-21"),
        
    data_name_prodacts_2_21 = 
    [
    "Nokia",
    "Nokia2.21",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_2_22 = document.getElementById("name-prodacts-2-22"),
        
    data_name_prodacts_2_22 = 
    [
    "Nokia",
    "Nokia2.22",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_2_23 = document.getElementById("name-prodacts-2-23"),
        
    data_name_prodacts_2_23 = 
    [
    "Nokia",
    "Nokia2.23",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_2_24 = document.getElementById("name-prodacts-2-24"),
        
    data_name_prodacts_2_24 = 
    [
    "Nokia",
    "Nokia2.24",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_2_25 = document.getElementById("name-prodacts-2-25"),
        
    data_name_prodacts_2_25 = 
    [
    "Nokia",
    "Nokia2.25",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_2_26 = document.getElementById("name-prodacts-2-26"),
        
    data_name_prodacts_2_26 = 
    [
    "Nokia",
    "Nokia2.26",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_2_27 = document.getElementById("name-prodacts-2-27"),
        
    data_name_prodacts_2_27 = 
    [
    "Nokia",
    "Nokia2.27",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_2_28 = document.getElementById("name-prodacts-2-28"),
        
    data_name_prodacts_2_28 = 
    [
    "Nokia",
    "Nokia2.28",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_2_29 = document.getElementById("name-prodacts-2-29"),
        
    data_name_prodacts_2_29 = 
    [
    "Nokia",
    "Nokia2.29",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_2_30 = document.getElementById("name-prodacts-2-30"),
        
    data_name_prodacts_2_30 = 
    [
    "Nokia",
    "Nokia2.30",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_31 = document.getElementById("name-prodacts-2-31"),
        
    data_name_prodacts_2_31 = 
    [
    "Nokia",
    "Nokia2.31",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
     name_prodacts_2_32 = document.getElementById("name-prodacts-2-32"),
        
    data_name_prodacts_2_32 = 
    [
    "Nokia",
    "Nokia2.32",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
     name_prodacts_2_33 = document.getElementById("name-prodacts-2-33"),
        
    data_name_prodacts_2_33 = 
    [
    "Nokia",
    "Nokia2.33",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_2_34 = document.getElementById("name-prodacts-2-34"),
        
    data_name_prodacts_2_34 = 
    [
    "Nokia",
    "Nokia2.34",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
     name_prodacts_2_35 = document.getElementById("name-prodacts-2-35"),
        
    data_name_prodacts_2_35 = 
    [
    "Nokia",
    "Nokia2.35",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
     name_prodacts_2_36 = document.getElementById("name-prodacts-2-36"),
        
    data_name_prodacts_2_36 = 
    [
    "Nokia",
    "Nokia2.36",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_2_37 = document.getElementById("name-prodacts-2-37"),
        
    data_name_prodacts_2_37 = 
    [
    "Nokia",
    "Nokia2.37",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_38 = document.getElementById("name-prodacts-2-38"),
        
    data_name_prodacts_2_38 = 
    [
    "Nokia",
    "Nokia2.38",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
     name_prodacts_2_39 = document.getElementById("name-prodacts-2-39"),
        
    data_name_prodacts_2_39 = 
    [
    "Nokia",
    "Nokia2.39",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_2_40 = document.getElementById("name-prodacts-2-40"),
        
    data_name_prodacts_2_40 = 
    [
    "Nokia",
    "Nokia2.40",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_41 = document.getElementById("name-prodacts-2-41"),
        
    data_name_prodacts_2_41 = 
    [
    "Nokia",
    "Nokia2.41",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_42 = document.getElementById("name-prodacts-2-42"),
        
    data_name_prodacts_2_42 = 
    [
    "Nokia",
    "Nokia2.42",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_43 = document.getElementById("name-prodacts-2-43"),
        
    data_name_prodacts_2_43 = 
    [
    "Nokia",
    "Nokia2.43",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_44 = document.getElementById("name-prodacts-2-44"),
        
    data_name_prodacts_2_44 = 
    [
    "Nokia",
    "Nokia2.44",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_2_45 = document.getElementById("name-prodacts-2-45"),
        
    data_name_prodacts_2_45 = 
    [
    "Nokia",
    "Nokia2.45",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_2_46 = document.getElementById("name-prodacts-2-46"),
        
    data_name_prodacts_2_46 = 
    [
    "Nokia",
    "Nokia2.46",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_47 = document.getElementById("name-prodacts-2-47"),
        
    data_name_prodacts_2_47 = 
    [
    "Nokia",
    "Nokia2.40",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_48 = document.getElementById("name-prodacts-2-48"),
        
    data_name_prodacts_2_48 = 
    [
    "Nokia",
    "Nokia2.48",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_49 = document.getElementById("name-prodacts-2-49"),
        
    data_name_prodacts_2_49 = 
    [
    "Nokia",
    "Nokia2.49",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_50 = document.getElementById("name-prodacts-2-50"),
        
    data_name_prodacts_2_50 = 
    [
    "Nokia",
    "Nokia2.50",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
    name_prodacts_2_51 = document.getElementById("name-prodacts-2-51"),
        
    data_name_prodacts_2_51 = 
    [
    "Nokia",
    "Nokia2.51",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
    name_prodacts_2_52 = document.getElementById("name-prodacts-2-52"),
        
    data_name_prodacts_2_52 = 
    [
    "Nokia",
    "Nokia2.52",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
    name_prodacts_2_53 = document.getElementById("name-prodacts-2-53"),
        
    data_name_prodacts_2_53 = 
    [
    "Nokia",
    "Nokia2.53",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
    name_prodacts_2_54 = document.getElementById("name-prodacts-2-54"),
        
    data_name_prodacts_2_54 = 
    [
    "Nokia",
    "Nokia2.54",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
    name_prodacts_2_55 = document.getElementById("name-prodacts-2-55"),
        
    data_name_prodacts_2_55 = 
    [
    "Nokia",
    "Nokia2.55",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
    name_prodacts_2_56 = document.getElementById("name-prodacts-2-56"),
        
    data_name_prodacts_2_56 = 
    [
    "Nokia",
    "Nokia2.56",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
    name_prodacts_2_57= document.getElementById("name-prodacts-2-57"),
        
    data_name_prodacts_2_57 = 
    [
    "Nokia",
    "Nokia2.57",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
     name_prodacts_2_58 = document.getElementById("name-prodacts-2-58"),
        
    data_name_prodacts_2_58 = 
    [
    "Nokia",
    "Nokia2.58",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
    name_prodacts_2_59 = document.getElementById("name-prodacts-2-59"),
        
    data_name_prodacts_2_59 = 
    [
    "Nokia",
    "Nokia2.59",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
    name_prodacts_2_60 = document.getElementById("name-prodacts-2-60"),
        
    data_name_prodacts_2_60 = 
    [
    "Nokia",
    "Nokia2.60",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_2_61 = document.getElementById("name-prodacts-2-61"),
        
    data_name_prodacts_2_61 = 
    [
    "Nokia",
    "Nokia2.61",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],                                
    name_prodacts_2_62 = document.getElementById("name-prodacts-2-62"),
        
    data_name_prodacts_2_62 = 
    [
    "Nokia",
    "Nokia2.62",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_63 = document.getElementById("name-prodacts-2-63"),
        
    data_name_prodacts_2_63 = 
    [
    "Nokia",
    "Nokia2.63",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_64 = document.getElementById("name-prodacts-2-64"),
        
    data_name_prodacts_2_64 = 
    [
    "Nokia",
    "Nokia2.64",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_65 = document.getElementById("name-prodacts-2-65"),
        
    data_name_prodacts_2_65 = 
    [
    "Nokia",
    "Nokia2.65",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_66 = document.getElementById("name-prodacts-2-66"),
        
    data_name_prodacts_2_66 = 
    [
    "Nokia",
    "Nokia2.66",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_67 = document.getElementById("name-prodacts-2-67"),
        
    data_name_prodacts_2_67 = 
    [
    "Nokia",
    "Nokia2.67",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_68 = document.getElementById("name-prodacts-2-68"),
        
    data_name_prodacts_2_68 = 
    [
    "Nokia",
    "Nokia2.68",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_69 = document.getElementById("name-prodacts-2-69"),
        
    data_name_prodacts_2_69 = 
    [
    "Nokia",
    "Nokia2.69",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_70 = document.getElementById("name-prodacts-2-70"),
        
    data_name_prodacts_2_70 = 
    [
    "Nokia",
    "Nokia2.70",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_71 = document.getElementById("name-prodacts-2-71"),
        
    data_name_prodacts_2_71 = 
    [
    "Nokia",
    "Nokia2.71",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_72 = document.getElementById("name-prodacts-2-72"),
        
    data_name_prodacts_2_72 = 
    [
    "Nokia",
    "Nokia2.72",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
    name_prodacts_2_73 = document.getElementById("name-prodacts-2-73"),
        
    data_name_prodacts_2_73 = 
    [
    "Nokia",
    "Nokia2.73",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
     name_prodacts_2_74 = document.getElementById("name-prodacts-2-74"),
        
    data_name_prodacts_2_74 = 
    [
    "Nokia",
    "Nokia2.74",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_2_75 = document.getElementById("name-prodacts-2-75"),
        
    data_name_prodacts_2_75 = 
    [
    "Nokia",
    "Nokia2.75",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_76 = document.getElementById("name-prodacts-2-76"),
        
    data_name_prodacts_2_76 = 
    [
    "Nokia",
    "Nokia2.76",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_77 = document.getElementById("name-prodacts-2-77"),
        
    data_name_prodacts_2_77 = 
    [
    "Nokia",
    "Nokia2.77",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_78 = document.getElementById("name-prodacts-2-78"),
        
    data_name_prodacts_2_78 = 
    [
    "Nokia",
    "Nokia2.78",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_79 = document.getElementById("name-prodacts-2-79"),
        
    data_name_prodacts_2_79 = 
    [
    "Nokia",
    "Nokia2.79",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_80 = document.getElementById("name-prodacts-2-80"),
        
    data_name_prodacts_2_80 = 
    [
    "Nokia",
    "Nokia2.80",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_2_81 = document.getElementById("name-prodacts-2-81"),
        
    data_name_prodacts_2_81 = 
    [
    "Nokia",
    "Nokia2.81",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_82 = document.getElementById("name-prodacts-2-82"),
        
    data_name_prodacts_2_82 = 
    [
    "Nokia",
    "Nokia2.82",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_82 = document.getElementById("name-prodacts-2-82"),
        
    data_name_prodacts_2_82 = 
    [
    "Nokia",
    "Nokia2.82",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
     name_prodacts_2_83 = document.getElementById("name-prodacts-2-83"),
        
    data_name_prodacts_2_83 = 
    [
    "Nokia",
    "Nokia2.83",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_2_84 = document.getElementById("name-prodacts-2-84"),
        
    data_name_prodacts_2_84 = 
    [
    "Nokia",
    "Nokia2.84",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_85 = document.getElementById("name-prodacts-2-85"),
        
    data_name_prodacts_2_85 = 
    [
    "Nokia",
    "Nokia2.85",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_86 = document.getElementById("name-prodacts-2-86"),
        
    data_name_prodacts_2_86 = 
    [
    "Nokia",
    "Nokia2.86",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_87 = document.getElementById("name-prodacts-2-87"),
        
    data_name_prodacts_2_87 = 
    [
    "Nokia",
    "Nokia2.87",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_88 = document.getElementById("name-prodacts-2-88"),
        
    data_name_prodacts_2_88 = 
    [
    "Nokia",
    "Nokia2.88",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_89 = document.getElementById("name-prodacts-2-89"),
        
    data_name_prodacts_2_89 = 
    [
    "Nokia",
    "Nokia2.89",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_90 = document.getElementById("name-prodacts-2-90"),
        
    data_name_prodacts_2_90 = 
    [
    "Nokia",
    "Nokia2.90",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_91 = document.getElementById("name-prodacts-2-91"),
        
    data_name_prodacts_2_91 = 
    [
    "Nokia",
    "Nokia2.91",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
    name_prodacts_2_92 = document.getElementById("name-prodacts-2-92"),
        
    data_name_prodacts_2_92 = 
    [
    "Nokia",
    "Nokia2.92",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_93 = document.getElementById("name-prodacts-2-93"),
        
    data_name_prodacts_2_93 = 
    [
    "Nokia",
    "Nokia2.93",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_94 = document.getElementById("name-prodacts-2-94"),
        
    data_name_prodacts_2_94 = 
    [
    "Nokia",
    "Nokia2.94",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_95 = document.getElementById("name-prodacts-2-95"),
        
    data_name_prodacts_2_95 = 
    [
    "Nokia",
    "Nokia2.95",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_96 = document.getElementById("name-prodacts-2-96"),
        
    data_name_prodacts_2_96 = 
    [
    "Nokia",
    "Nokia2.96",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_97 = document.getElementById("name-prodacts-2-97"),
        
    data_name_prodacts_2_97 = 
    [
    "Nokia",
    "Nokia2.97",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_98 = document.getElementById("name-prodacts-2-98"),
        
    data_name_prodacts_2_98 = 
    [
    "Nokia",
    "Nokia2.98",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
     name_prodacts_2_99 = document.getElementById("name-prodacts-2-99"),
        
    data_name_prodacts_2_99 = 
    [
    "Nokia",
    "Nokia2.99",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_2_100 = document.getElementById("name-prodacts-2-100"),
        
    data_name_prodacts_2_100 = 
    [
    "Nokia",
    "Nokia2.100",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
     name_prodacts_2_101 = document.getElementById("name-prodacts-2-101"),
        
    data_name_prodacts_2_101 = 
    [
    "Nokia",
    "Nokia2.101",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_2_102 = document.getElementById("name-prodacts-2-102"),
        
    data_name_prodacts_2_102 = 
    [
    "Nokia",
    "Nokia2.102",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_103 = document.getElementById("name-prodacts-2-103"),
        
    data_name_prodacts_2_103 = 
    [
    "Nokia",
    "Nokia2.103",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_104 = document.getElementById("name-prodacts-2-104"),
        
    data_name_prodacts_2_104 = 
    [
    "Nokia",
    "Nokia2.104",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_105 = document.getElementById("name-prodacts-2-105"),
        
    data_name_prodacts_2_105 = 
    [
    "Nokia",
    "Nokia2.105",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_106 = document.getElementById("name-prodacts-2-106"),
        
    data_name_prodacts_2_106 = 
    [
    "Nokia",
    "Nokia2.106",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_107 = document.getElementById("name-prodacts-2-107"),
        
    data_name_prodacts_2_107 = 
    [
    "Nokia",
    "Nokia2.107",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_108 = document.getElementById("name-prodacts-2-108"),
        
    data_name_prodacts_2_108 = 
    [
    "Nokia",
    "Nokia2.108",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_109 = document.getElementById("name-prodacts-2-109"),
        
    data_name_prodacts_2_109 = 
    [
    "Nokia",
    "Nokia2.109",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_110 = document.getElementById("name-prodacts-2-110"),
        
    data_name_prodacts_2_110 = 
    [
    "Nokia",
    "Nokia2.110",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_2_111 = document.getElementById("name-prodacts-2-111"),
        
    data_name_prodacts_2_111 = 
    [
    "Nokia",
    "Nokia2.111",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_112 = document.getElementById("name-prodacts-2-112"),
        
    data_name_prodacts_2_112 = 
    [
    "Nokia",
    "Nokia2.112",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_113 = document.getElementById("name-prodacts-2-113"),
        
    data_name_prodacts_2_113 = 
    [
    "Nokia",
    "Nokia2.113",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
    name_prodacts_2_114 = document.getElementById("name-prodacts-2-114"),
        
    data_name_prodacts_2_114 = 
    [
    "Nokia",
    "Nokia2.114",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_2_115 = document.getElementById("name-prodacts-2-115"),
        
    data_name_prodacts_2_115 = 
    [
    "Nokia",
    "Nokia2.115",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_116 = document.getElementById("name-prodacts-2-116"),
        
    data_name_prodacts_2_116 = 
    [
    "Nokia",
    "Nokia2.116",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_117 = document.getElementById("name-prodacts-2-117"),
        
    data_name_prodacts_2_117 = 
    [
    "Nokia",
    "Nokia2.117",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_118 = document.getElementById("name-prodacts-2-118"),
        
    data_name_prodacts_2_118 = 
    [
    "Nokia",
    "Nokia2.118",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_2_119 = document.getElementById("name-prodacts-2-119"),
        
    data_name_prodacts_2_119 = 
    [
    "Nokia",
    "Nokia2.119",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_2_120 = document.getElementById("name-prodacts-2-120"),
        
    data_name_prodacts_2_120 = 
    [
    "Nokia",
    "Nokia2.120",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
        
    // End Galeery2    -----------------------------------------------------------------
    name_prodacts_3_1 = document.getElementById("name-prodacts-3-1"),
        
    data_name_prodacts_3_1 = 
    [
    "Nokia",
    "Nokia3.1",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_3_2 = document.getElementById("name-prodacts-3-2"),
        
    data_name_prodacts_3_2 = 
    [
    "Nokia",
    "Nokia3.2",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_3 = document.getElementById("name-prodacts-3-3"),
        
    data_name_prodacts_3_3 = 
    [
    "Nokia",
    "Nokia3.3",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_4 = document.getElementById("name-prodacts-3-4"),
        
    data_name_prodacts_3_4 = 
    [
    "Nokia",
    "Nokia3.4",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_5 = document.getElementById("name-prodacts-3-5"),
        
    data_name_prodacts_3_5 = 
    [
    "Nokia",
    "Nokia3.5",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_3_6 = document.getElementById("name-prodacts-3-6"),
        
    data_name_prodacts_3_6 = 
    [
    "Nokia",
    "Nokia3.6",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_7 = document.getElementById("name-prodacts-3-7"),
        
    data_name_prodacts_3_7 = 
    [
    "Nokia",
    "Nokia3.7",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_8 = document.getElementById("name-prodacts-3-8"),
        
    data_name_prodacts_3_8 = 
    [
    "Nokia",
    "Nokia3.8",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_9 = document.getElementById("name-prodacts-3-9"),
        
    data_name_prodacts_3_9 = 
    [
    "Nokia",
    "Nokia3.9",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_10 = document.getElementById("name-prodacts-3-10"),
        
    data_name_prodacts_3_10 = 
    [
    "Nokia",
    "Nokia3.10",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_11 = document.getElementById("name-prodacts-3-11"),
        
    data_name_prodacts_3_11 = 
    [
    "Nokia",
    "Nokia3.11",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_3_12 = document.getElementById("name-prodacts-3-12"),
        
    data_name_prodacts_3_12 = 
    [
    "Nokia",
    "Nokia3.12",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_3_13 = document.getElementById("name-prodacts-3-13"),
        
    data_name_prodacts_3_13 = 
    [
    "Nokia",
    "Nokia3.13",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_14 = document.getElementById("name-prodacts-3-14"),
        
    data_name_prodacts_3_14 = 
    [
    "Nokia",
    "Nokia3.14",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_15 = document.getElementById("name-prodacts-3-15"),
        
    data_name_prodacts_3_15 = 
    [
    "Nokia",
    "Nokia3.15",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_16 = document.getElementById("name-prodacts-3-16"),
        
    data_name_prodacts_3_16 = 
    [
    "Nokia",
    "Nokia3.16",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_17 = document.getElementById("name-prodacts-3-17"),
        
    data_name_prodacts_3_17 = 
    [
    "Nokia",
    "Nokia3.17",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_18 = document.getElementById("name-prodacts-3-18"),
        
    data_name_prodacts_3_18 = 
    [
    "Nokia",
    "Nokia3.18",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_19 = document.getElementById("name-prodacts-3-19"),
        
    data_name_prodacts_3_19 = 
    [
    "Nokia",
    "Nokia3.19",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_3_20 = document.getElementById("name-prodacts-3-20"),
        
    data_name_prodacts_3_20 = 
    [
    "Nokia",
    "Nokia3.20",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_3_21 = document.getElementById("name-prodacts-3-21"),
        
    data_name_prodacts_3_21 = 
    [
    "Nokia",
    "Nokia3.21",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_22 = document.getElementById("name-prodacts-3-22"),
        
    data_name_prodacts_3_22 = 
    [
    "Nokia",
    "Nokia3.22",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_23 = document.getElementById("name-prodacts-3-23"),
        
    data_name_prodacts_3_23 = 
    [
    "Nokia",
    "Nokia3.23",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_24 = document.getElementById("name-prodacts-3-24"),
        
    data_name_prodacts_3_24 = 
    [
    "Nokia",
    "Nokia3.24",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
    name_prodacts_3_25 = document.getElementById("name-prodacts-3-25"),
        
    data_name_prodacts_3_25 = 
    [
    "Nokia",
    "Nokia3.25",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_26 = document.getElementById("name-prodacts-3-26"),
    
    data_name_prodacts_3_26 = 
    [
    "Nokia",
    "Nokia3.26",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_3_27 = document.getElementById("name-prodacts-3-27"),
        
    data_name_prodacts_3_27 = 
    [
    "Nokia",
    "Nokia3.27",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_28 = document.getElementById("name-prodacts-3-28"),
        
    data_name_prodacts_3_28 = 
    [
    "Nokia",
    "Nokia3.28",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_29 = document.getElementById("name-prodacts-3-29"),
        
    data_name_prodacts_3_29 = 
    [
    "Nokia",
    "Nokia3.29",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_30 = document.getElementById("name-prodacts-3-30"),
        
    data_name_prodacts_3_30 = 
    [
    "Nokia",
    "Nokia3.30",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_31 = document.getElementById("name-prodacts-3-31"),
        
    data_name_prodacts_3_31 = 
    [
    "Nokia",
    "Nokia3.31",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_3_32 = document.getElementById("name-prodacts-3-32"),
        
    data_name_prodacts_3_32 = 
    [
    "Nokia",
    "Nokia3.32",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_33 = document.getElementById("name-prodacts-3-33"),
        
    data_name_prodacts_3_33 = 
    [
    "Nokia",
    "Nokia3.33",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_34 = document.getElementById("name-prodacts-3-34"),
        
    data_name_prodacts_3_34 = 
    [
    "Nokia",
    "Nokia3.34",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_35 = document.getElementById("name-prodacts-3-35"),
        
    data_name_prodacts_3_35 = 
    [
    "Nokia",
    "Nokia3.35",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_36 = document.getElementById("name-prodacts-3-36"),
        
    data_name_prodacts_3_36 = 
    [
    "Nokia",
    "Nokia3.36",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_37 = document.getElementById("name-prodacts-3-37"),
        
    data_name_prodacts_3_37 = 
    [
    "Nokia",
    "Nokia3.37",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_38 = document.getElementById("name-prodacts-3-38"),
        
    data_name_prodacts_3_38 = 
    [
    "Nokia",
    "Nokia3.38",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_39 = document.getElementById("name-prodacts-3-39"),
        
    data_name_prodacts_3_39 = 
    [
    "Nokia",
    "Nokia3.39",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_40 = document.getElementById("name-prodacts-3-40"),
        
    data_name_prodacts_3_40 = 
    [
    "Nokia",
    "Nokia3.40",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
        
    name_prodacts_3_41 = document.getElementById("name-prodacts-3-41"),
        
    data_name_prodacts_3_41 = 
    [
    "Nokia",
    "Nokia3.41",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_42 = document.getElementById("name-prodacts-3-42"),
        
    data_name_prodacts_3_42 = 
    [
    "Nokia",
    "Nokia3.42",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_43 = document.getElementById("name-prodacts-3-43"),
        
    data_name_prodacts_3_43 = 
    [
    "Nokia",
    "Nokia3.43",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_44 = document.getElementById("name-prodacts-3-44"),
        
    data_name_prodacts_3_44 = 
    [
    "Nokia",
    "Nokia3.44",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_45 = document.getElementById("name-prodacts-3-45"),
        
    data_name_prodacts_3_45 = 
    [
    "Nokia",
    "Nokia3.45",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_46 = document.getElementById("name-prodacts-3-46"),
        
    data_name_prodacts_3_46 = 
    [
    "Nokia",
    "Nokia3.46",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_47 = document.getElementById("name-prodacts-3-47"),
        
    data_name_prodacts_3_47 = 
    [
    "Nokia",
    "Nokia3.47",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_48 = document.getElementById("name-prodacts-3-48"),
        
    data_name_prodacts_3_48 = 
    [
    "Nokia",
    "Nokia3.48",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_49 = document.getElementById("name-prodacts-3-49"),
        
    data_name_prodacts_3_49 = 
    [
    "Nokia",
    "Nokia3.49",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_50 = document.getElementById("name-prodacts-3-50"),
        
    data_name_prodacts_3_50 = 
    [
    "Nokia",
    "Nokia3.50",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_3_51 = document.getElementById("name-prodacts-3-51"),
        
    data_name_prodacts_3_51 = 
    [
    "Nokia",
    "Nokia3.51",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
    name_prodacts_3_52 = document.getElementById("name-prodacts-3-52"),
        
    data_name_prodacts_3_52 = 
    [
    "Nokia",
    "Nokia3.52",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_53 = document.getElementById("name-prodacts-3-53"),
        
    data_name_prodacts_3_53 = 
    [
    "Nokia",
    "Nokia3.53",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_3_54 = document.getElementById("name-prodacts-3-54"),
        
    data_name_prodacts_3_54 = 
    [
    "Nokia",
    "Nokia3.54",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_55 = document.getElementById("name-prodacts-3-55"),
        
    data_name_prodacts_3_55 = 
    [
    "Nokia",
    "Nokia3.55",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_56 = document.getElementById("name-prodacts-3-56"),
        
    data_name_prodacts_3_56 = 
    [
    "Nokia",
    "Nokia3.56",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_3_57 = document.getElementById("name-prodacts-3-57"),
        
    data_name_prodacts_3_57 = 
    [
    "Nokia",
    "Nokia3.57",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_58 = document.getElementById("name-prodacts-3-58"),
        
    data_name_prodacts_3_58 = 
    [
    "Nokia",
    "Nokia3.58",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_59 = document.getElementById("name-prodacts-3-59"),
        
    data_name_prodacts_3_59 = 
    [
    "Nokia",
    "Nokia3.59",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_60 = document.getElementById("name-prodacts-3-60"),
        
    data_name_prodacts_3_60 = 
    [
    "Nokia",
    "Nokia3.60",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_3_61 = document.getElementById("name-prodacts-3-61"),
        
    data_name_prodacts_3_61 = 
    [
    "Nokia",
    "Nokia3.61",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_62 = document.getElementById("name-prodacts-3-62"),
        
    data_name_prodacts_3_62 = 
    [
    "Nokia",
    "Nokia3.62",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_63 = document.getElementById("name-prodacts-3-63"),
        
    data_name_prodacts_3_63 = 
    [
    "Nokia",
    "Nokia3.63",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_64 = document.getElementById("name-prodacts-3-64"),
        
    data_name_prodacts_3_64 = 
    [
    "Nokia",
    "Nokia3.64",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_65 = document.getElementById("name-prodacts-3-65"),
        
    data_name_prodacts_3_65 = 
    [
    "Nokia",
    "Nokia3.65",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_66 = document.getElementById("name-prodacts-3-66"),
        
    data_name_prodacts_3_66 = 
    [
    "Nokia",
    "Nokia3.66",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_67 = document.getElementById("name-prodacts-3-67"),
        
    data_name_prodacts_3_67 = 
    [
    "Nokia",
    "Nokia3.67",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_68 = document.getElementById("name-prodacts-3-68"),
        
    data_name_prodacts_3_68 = 
    [
    "Nokia",
    "Nokia3.68",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_69 = document.getElementById("name-prodacts-3-69"),
        
    data_name_prodacts_3_69 = 
    [
    "Nokia",
    "Nokia3.69",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_70 = document.getElementById("name-prodacts-3-70"),
        
    data_name_prodacts_3_70 = 
    [
    "Nokia",
    "Nokia3.70",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_71 = document.getElementById("name-prodacts-3-71"),
        
    data_name_prodacts_3_71 = 
    [
    "Nokia",
    "Nokia3.71",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_3_72 = document.getElementById("name-prodacts-3-72"),
        
    data_name_prodacts_3_72 = 
    [
    "Nokia",
    "Nokia3.72",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_73 = document.getElementById("name-prodacts-3-73"),
        
    data_name_prodacts_3_73 = 
    [
    "Nokia",
    "Nokia3.73",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_74 = document.getElementById("name-prodacts-3-74"),
        
    data_name_prodacts_3_74 = 
    [
    "Nokia",
    "Nokia3.74",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_75 = document.getElementById("name-prodacts-3-75"),
        
    data_name_prodacts_3_75 = 
    [
    "Nokia",
    "Nokia3.75",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_76 = document.getElementById("name-prodacts-3-76"),
        
    data_name_prodacts_3_76 = 
    [
    "Nokia",
    "Nokia3.76",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_77 = document.getElementById("name-prodacts-3-77"),
        
    data_name_prodacts_3_77 = 
    [
    "Nokia",
    "Nokia3.77",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_78 = document.getElementById("name-prodacts-3-78"),
        
    data_name_prodacts_3_78 = 
    [
    "Nokia",
    "Nokia3.78",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_79 = document.getElementById("name-prodacts-3-79"),
        
    data_name_prodacts_3_79 = 
    [
    "Nokia",
    "Nokia3.79",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_80 = document.getElementById("name-prodacts-3-80"),
        
    data_name_prodacts_3_80 = 
    [
    "Nokia",
    "Nokia3.80",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_81 = document.getElementById("name-prodacts-3-81"),
        
    data_name_prodacts_3_81 = 
    [
    "Nokia",
    "Nokia3.81",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_82 = document.getElementById("name-prodacts-3-82"),
        
    data_name_prodacts_3_82 = 
    [
    "Nokia",
    "Nokia3.82",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_83 = document.getElementById("name-prodacts-3-83"),
        
    data_name_prodacts_3_83 = 
    [
    "Nokia",
    "Nokia3.83",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_84 = document.getElementById("name-prodacts-3-84"),
        
    data_name_prodacts_3_84 = 
    [
    "Nokia",
    "Nokia3.84",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_85 = document.getElementById("name-prodacts-3-85"),
        
    data_name_prodacts_3_85 = 
    [
    "Nokia",
    "Nokia3.85",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_86 = document.getElementById("name-prodacts-3-86"),
        
    data_name_prodacts_3_86 = 
    [
    "Nokia",
    "Nokia3.86",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_87 = document.getElementById("name-prodacts-3-87"),
        
    data_name_prodacts_3_87 = 
    [
    "Nokia",
    "Nokia3.87",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_88 = document.getElementById("name-prodacts-3-88"),
        
    data_name_prodacts_3_88 = 
    [
    "Nokia",
    "Nokia3.88",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_89 = document.getElementById("name-prodacts-3-89"),
        
    data_name_prodacts_3_89 = 
    [
    "Nokia",
    "Nokia3.89",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_90 = document.getElementById("name-prodacts-3-90"),
        
    data_name_prodacts_3_90 = 
    [
    "Nokia",
    "Nokia3.90",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_3_91 = document.getElementById("name-prodacts-3-91"),
        
    data_name_prodacts_3_91 = 
    [
    "Nokia",
    "Nokia3.91",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_92 = document.getElementById("name-prodacts-3-92"),
        
    data_name_prodacts_3_92 = 
    [
    "Nokia",
    "Nokia3.92",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_93 = document.getElementById("name-prodacts-3-93"),
        
    data_name_prodacts_3_93 = 
    [
    "Nokia",
    "Nokia3.93",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_94 = document.getElementById("name-prodacts-3-94"),
        
    data_name_prodacts_3_94 = 
    [
    "Nokia",
    "Nokia3.94",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_95 = document.getElementById("name-prodacts-3-95"),
        
    data_name_prodacts_3_95 = 
    [
    "Nokia",
    "Nokia3.95",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_96 = document.getElementById("name-prodacts-3-96"),
        
    data_name_prodacts_3_96 = 
    [
    "Nokia",
    "Nokia3.96",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_97 = document.getElementById("name-prodacts-3-97"),
        
    data_name_prodacts_3_97 = 
    [
    "Nokia",
    "Nokia3.97",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_98 = document.getElementById("name-prodacts-3-98"),
        
    data_name_prodacts_3_98 = 
    [
    "Nokia",
    "Nokia3.98",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_99 = document.getElementById("name-prodacts-3-99"),
        
    data_name_prodacts_3_99 = 
    [
    "Nokia",
    "Nokia3.99",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_100 = document.getElementById("name-prodacts-3-100"),
        
    data_name_prodacts_3_100 = 
    [
    "Nokia",
    "Nokia3.100",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_3_101 = document.getElementById("name-prodacts-3-101"),
        
    data_name_prodacts_3_101 = 
    [
    "Nokia",
    "Nokia3.101",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_3_102 = document.getElementById("name-prodacts-3-102"),
        
    data_name_prodacts_3_102 = 
    [
    "Nokia",
    "Nokia3.102",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_3_103 = document.getElementById("name-prodacts-3-103"),
        
    data_name_prodacts_3_103 = 
    [
    "Nokia",
    "Nokia3.103",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_3_104 = document.getElementById("name-prodacts-3-104"),
        
    data_name_prodacts_3_104 = 
    [
    "Nokia",
    "Nokia3.104",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_3_105 = document.getElementById("name-prodacts-3-105"),
        
    data_name_prodacts_3_105 = 
    [
    "Nokia",
    "Nokia3.105",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_3_106 = document.getElementById("name-prodacts-3-106"),
        
    data_name_prodacts_3_106 = 
    [
    "Nokia",
    "Nokia3.106",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_3_107 = document.getElementById("name-prodacts-3-107"),
        
    data_name_prodacts_3_107 = 
    [
    "Nokia",
    "Nokia3.107",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_3_108 = document.getElementById("name-prodacts-3-108"),
        
    data_name_prodacts_3_108 = 
    [
    "Nokia",
    "Nokia3.108",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_3_109 = document.getElementById("name-prodacts-3-109"),
        
    data_name_prodacts_3_109 = 
    [
    "Nokia",
    "Nokia3.109",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_3_110 = document.getElementById("name-prodacts-3-110"),
        
    data_name_prodacts_3_110 = 
    [
    "Nokia",
    "Nokia3.110",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_3_111 = document.getElementById("name-prodacts-3-111"),
        
    data_name_prodacts_3_111 = 
    [
    "Nokia",
    "Nokia3.111",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_112 = document.getElementById("name-prodacts-3-112"),
        
    data_name_prodacts_3_112 = 
    [
    "Nokia",
    "Nokia3.112",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_113 = document.getElementById("name-prodacts-3-113"),
        
    data_name_prodacts_3_113 = 
    [
    "Nokia",
    "Nokia3.113",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_3_114 = document.getElementById("name-prodacts-3-114"),
        
    data_name_prodacts_3_114 = 
    [
    "Nokia",
    "Nokia3.114",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_115 = document.getElementById("name-prodacts-3-115"),
        
    data_name_prodacts_3_115 = 
    [
    "Nokia",
    "Nokia3.115",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_116 = document.getElementById("name-prodacts-3-116"),
        
    data_name_prodacts_3_116 = 
    [
    "Nokia",
    "Nokia3.116",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_117 = document.getElementById("name-prodacts-3-117"),
        
    data_name_prodacts_3_117 = 
    [
    "Nokia",
    "Nokia3.117",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_118 = document.getElementById("name-prodacts-3-118"),
        
    data_name_prodacts_3_118 = 
    [
    "Nokia",
    "Nokia3.118",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_119 = document.getElementById("name-prodacts-3-119"),
        
    data_name_prodacts_3_119 = 
    [
    "Nokia",
    "Nokia3.119",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_3_120 = document.getElementById("name-prodacts-3-120"),
        
    data_name_prodacts_3_120 = 
    [
    "Nokia",
    "Nokia3.120",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    // End GAllery3--------------------------------------------------------    
    
        
        
    name_prodacts_4_1 = document.getElementById("name-prodacts-4-1"),
        
    data_name_prodacts_4_1 = 
    [
    "Nokia",
    "Nokia4.1",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_2 = document.getElementById("name-prodacts-4-2"),
        
    data_name_prodacts_4_2 = 
    [
    "Nokia",
    "Nokia4.2",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_3 = document.getElementById("name-prodacts-4-3"),
        
    data_name_prodacts_4_3 = 
    [
    "Nokia",
    "Nokia4.3",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_4 = document.getElementById("name-prodacts-4-4"),
        
    data_name_prodacts_4_4 = 
    [
    "Nokia",
    "Nokia4.4",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_5 = document.getElementById("name-prodacts-4-5"),
        
    data_name_prodacts_4_5 = 
    [
    "Nokia",
    "Nokia4.5",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_6 = document.getElementById("name-prodacts-4-6"),
        
    data_name_prodacts_4_6 = 
    [
    "Nokia",
    "Nokia4.6",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_7 = document.getElementById("name-prodacts-4-7"),
        
    data_name_prodacts_4_7 = 
    [
    "Nokia",
    "Nokia4.7",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_8 = document.getElementById("name-prodacts-4-8"),
        
    data_name_prodacts_4_8 = 
    [
    "Nokia",
    "Nokia4.8",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_9 = document.getElementById("name-prodacts-4-9"),
        
    data_name_prodacts_4_9 = 
    [
    "Nokia",
    "Nokia4.9",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_10 = document.getElementById("name-prodacts-4-10"),
        
    data_name_prodacts_4_10 = 
    [
    "Nokia",
    "Nokia4.10",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_11 = document.getElementById("name-prodacts-4-11"),
        
    data_name_prodacts_4_11 = 
    [
    "Nokia",
    "Nokia4.11",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_12 = document.getElementById("name-prodacts-4-12"),
        
    data_name_prodacts_4_12 = 
    [
    "Nokia",
    "Nokia4.12",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_4_13 = document.getElementById("name-prodacts-4-13"),
        
    data_name_prodacts_4_13 = 
    [
    "Nokia",
    "Nokia4.13",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_14 = document.getElementById("name-prodacts-4-14"),
        
    data_name_prodacts_4_14 = 
    [
    "Nokia",
    "Nokia4.14",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_15 = document.getElementById("name-prodacts-4-15"),
        
    data_name_prodacts_4_15 = 
    [
    "Nokia",
    "Nokia4.15",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_16 = document.getElementById("name-prodacts-4-16"),
        
    data_name_prodacts_4_16 = 
    [
    "Nokia",
    "Nokia4.10",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_17 = document.getElementById("name-prodacts-4-17"),
        
    data_name_prodacts_4_17 = 
    [
    "Nokia",
    "Nokia4.17",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_18 = document.getElementById("name-prodacts-4-18"),
        
    data_name_prodacts_4_18 = 
    [
    "Nokia",
    "Nokia4.18",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
    name_prodacts_4_19 = document.getElementById("name-prodacts-4-19"),
        
    data_name_prodacts_4_19 = 
    [
    "Nokia",
    "Nokia4.19",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_20 = document.getElementById("name-prodacts-4-20"),
        
    data_name_prodacts_4_20 = 
    [
    "Nokia",
    "Nokia4.20",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_21 = document.getElementById("name-prodacts-4-21"),
        
    data_name_prodacts_4_21 = 
    [
    "Nokia",
    "Nokia4.21",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_22 = document.getElementById("name-prodacts-4-22"),
        
    data_name_prodacts_4_22 = 
    [
    "Nokia",
    "Nokia4.22",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_23 = document.getElementById("name-prodacts-4-23"),
        
    data_name_prodacts_4_23 = 
    [
    "Nokia",
    "Nokia4.23",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_24 = document.getElementById("name-prodacts-4-24"),
        
    data_name_prodacts_4_24 = 
    [
    "Nokia",
    "Nokia4.24",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_25 = document.getElementById("name-prodacts-4-25"),
        
    data_name_prodacts_4_25 = 
    [
    "Nokia",
    "Nokia4.25",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_26 = document.getElementById("name-prodacts-4-26"),
        
    data_name_prodacts_4_26 = 
    [
    "Nokia",
    "Nokia4.26",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_27 = document.getElementById("name-prodacts-4-27"),
        
    data_name_prodacts_4_27 = 
    [
    "Nokia",
    "Nokia4.27",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_28 = document.getElementById("name-prodacts-4-28"),
        
    data_name_prodacts_4_28 = 
    [
    "Nokia",
    "Nokia4.28",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_29 = document.getElementById("name-prodacts-4-29"),
        
    data_name_prodacts_4_29 = 
    [
    "Nokia",
    "Nokia4.29",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_30 = document.getElementById("name-prodacts-4-30"),
        
    data_name_prodacts_4_30 = 
    [
    "Nokia",
    "Nokia4.30",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_4_31 = document.getElementById("name-prodacts-4-31"),
        
    data_name_prodacts_4_31 = 
    [
    "Nokia",
    "Nokia4.31",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_32 = document.getElementById("name-prodacts-4-32"),
        
    data_name_prodacts_4_32 = 
    [
    "Nokia",
    "Nokia4.32",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_33 = document.getElementById("name-prodacts-4-33"),
        
    data_name_prodacts_4_33 = 
    [
    "Nokia",
    "Nokia4.33",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_4_34 = document.getElementById("name-prodacts-4-34"),
        
    data_name_prodacts_4_34 = 
    [
    "Nokia",
    "Nokia4.34",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_35 = document.getElementById("name-prodacts-4-35"),
        
    data_name_prodacts_4_35 = 
    [
    "Nokia",
    "Nokia4.35",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_36 = document.getElementById("name-prodacts-4-36"),
        
    data_name_prodacts_4_36 = 
    [
    "Nokia",
    "Nokia4.36",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_37 = document.getElementById("name-prodacts-4-37"),
        
    data_name_prodacts_4_37 = 
    [
    "Nokia",
    "Nokia4.37",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_38 = document.getElementById("name-prodacts-4-38"),
        
    data_name_prodacts_4_38 = 
    [
    "Nokia",
    "Nokia4.38",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_39 = document.getElementById("name-prodacts-4-39"),
        
    data_name_prodacts_4_39 = 
    [
    "Nokia",
    "Nokia4.39",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_40 = document.getElementById("name-prodacts-4-40"),
        
    data_name_prodacts_4_40 = 
    [
    "Nokia",
    "Nokia4.40",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_41 = document.getElementById("name-prodacts-4-41"),
        
    data_name_prodacts_4_41 = 
    [
    "Nokia",
    "Nokia4.41",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_42 = document.getElementById("name-prodacts-4-42"),
        
    data_name_prodacts_4_42 = 
    [
    "Nokia",
    "Nokia4.42",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_43 = document.getElementById("name-prodacts-4-43"),
        
    data_name_prodacts_4_43 = 
    [
    "Nokia",
    "Nokia4.43",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_44 = document.getElementById("name-prodacts-4-44"),
        
    data_name_prodacts_4_44 = 
    [
    "Nokia",
    "Nokia4.44",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_4_44 = document.getElementById("name-prodacts-4-44"),
        
    data_name_prodacts_4_44 = 
    [
    "Nokia",
    "Nokia4.44",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_45 = document.getElementById("name-prodacts-4-45"),
        
    data_name_prodacts_4_45 = 
    [
    "Nokia",
    "Nokia4.45",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_46 = document.getElementById("name-prodacts-4-46"),
        
    data_name_prodacts_4_46 = 
    [
    "Nokia",
    "Nokia4.46",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_47 = document.getElementById("name-prodacts-4-47"),
        
    data_name_prodacts_4_47 = 
    [
    "Nokia",
    "Nokia4.47",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_48 = document.getElementById("name-prodacts-4-48"),
        
    data_name_prodacts_4_48 = 
    [
    "Nokia",
    "Nokia4.48",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_49 = document.getElementById("name-prodacts-4-49"),
        
    data_name_prodacts_4_49 = 
    [
    "Nokia",
    "Nokia4.49",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_50 = document.getElementById("name-prodacts-4-50"),
        
    data_name_prodacts_4_50 = 
    [
    "Nokia",
    "Nokia4.50",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_51 = document.getElementById("name-prodacts-4-51"),
        
    data_name_prodacts_4_51 = 
    [
    "Nokia",
    "Nokia4.51",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_52 = document.getElementById("name-prodacts-4-52"),
        
    data_name_prodacts_4_52 = 
    [
    "Nokia",
    "Nokia4.52",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_4_53 = document.getElementById("name-prodacts-4-53"),
        
    data_name_prodacts_4_53 = 
    [
    "Nokia",
    "Nokia4.53",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_54 = document.getElementById("name-prodacts-4-54"),
        
    data_name_prodacts_4_54 = 
    [
    "Nokia",
    "Nokia4.54",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_55 = document.getElementById("name-prodacts-4-55"),
        
    data_name_prodacts_4_55 = 
    [
    "Nokia",
    "Nokia4.55",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_56 = document.getElementById("name-prodacts-4-56"),
        
    data_name_prodacts_4_56 = 
    [
    "Nokia",
    "Nokia4.56",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_57 = document.getElementById("name-prodacts-4-57"),
        
    data_name_prodacts_4_57 = 
    [
    "Nokia",
    "Nokia4.57",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_58 = document.getElementById("name-prodacts-4-58"),
        
    data_name_prodacts_4_58 = 
    [
    "Nokia",
    "Nokia4.58",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_59 = document.getElementById("name-prodacts-4-59"),
        
    data_name_prodacts_4_59 = 
    [
    "Nokia",
    "Nokia4.59",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_60 = document.getElementById("name-prodacts-4-60"),
        
    data_name_prodacts_4_60 = 
    [
    "Nokia",
    "Nokia4.60",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
    name_prodacts_4_61 = document.getElementById("name-prodacts-4-61"),
        
    data_name_prodacts_4_61 = 
    [
    "Nokia",
    "Nokia4.61",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
    name_prodacts_4_62 = document.getElementById("name-prodacts-4-62"),
        
    data_name_prodacts_4_62 = 
    [
    "Nokia",
    "Nokia4.62",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_63 = document.getElementById("name-prodacts-4-63"),
        
    data_name_prodacts_4_63 = 
    [
    "Nokia",
    "Nokia4.63",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_64 = document.getElementById("name-prodacts-4-64"),
        
    data_name_prodacts_4_64 = 
    [
    "Nokia",
    "Nokia4.64",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_65 = document.getElementById("name-prodacts-4-65"),
        
    data_name_prodacts_4_65 = 
    [
    "Nokia",
    "Nokia4.65",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_66 = document.getElementById("name-prodacts-4-66"),
        
    data_name_prodacts_4_66 = 
    [
    "Nokia",
    "Nokia4.66",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_67 = document.getElementById("name-prodacts-4-67"),
        
    data_name_prodacts_4_67 = 
    [
    "Nokia",
    "Nokia4.67",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_68 = document.getElementById("name-prodacts-4-68"),
        
    data_name_prodacts_4_68 = 
    [
    "Nokia",
    "Nokia4.68",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_69 = document.getElementById("name-prodacts-4-69"),
        
    data_name_prodacts_4_69 = 
    [
    "Nokia",
    "Nokia4.69",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_70 = document.getElementById("name-prodacts-4-70"),
        
    data_name_prodacts_4_70 = 
    [
    "Nokia",
    "Nokia4.70",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_4_71 = document.getElementById("name-prodacts-4-71"),
        
    data_name_prodacts_4_71 = 
    [
    "Nokia",
    "Nokia4.71",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_4_72 = document.getElementById("name-prodacts-4-72"),
        
    data_name_prodacts_4_72 = 
    [
    "Nokia",
    "Nokia4.72",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_73 = document.getElementById("name-prodacts-4-73"),
        
    data_name_prodacts_4_73 = 
    [
    "Nokia",
    "Nokia4.73",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_74 = document.getElementById("name-prodacts-4-74"),
        
    data_name_prodacts_4_74 = 
    [
    "Nokia",
    "Nokia4.74",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_75 = document.getElementById("name-prodacts-4-75"),
        
    data_name_prodacts_4_75 = 
    [
    "Nokia",
    "Nokia4.75",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_76 = document.getElementById("name-prodacts-4-76"),
        
    data_name_prodacts_4_76 = 
    [
    "Nokia",
    "Nokia4.76",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_77 = document.getElementById("name-prodacts-4-77"),
        
    data_name_prodacts_4_77 = 
    [
    "Nokia",
    "Nokia4.77",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_78 = document.getElementById("name-prodacts-4-78"),
        
    data_name_prodacts_4_78 = 
    [
    "Nokia",
    "Nokia4.78",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_79 = document.getElementById("name-prodacts-4-79"),
        
    data_name_prodacts_4_79 = 
    [
    "Nokia",
    "Nokia4.79",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_80 = document.getElementById("name-prodacts-4-80"),
        
    data_name_prodacts_4_80 = 
    [
    "Nokia",
    "Nokia4.80",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_4_81 = document.getElementById("name-prodacts-4-81"),
        
    data_name_prodacts_4_81 = 
    [
    "Nokia",
    "Nokia4.81",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_82 = document.getElementById("name-prodacts-4-82"),
        
    data_name_prodacts_4_82 = 
    [
    "Nokia",
    "Nokia4.82",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_4_83 = document.getElementById("name-prodacts-4-83"),
        
    data_name_prodacts_4_83 = 
    [
    "Nokia",
    "Nokia4.83",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_84 = document.getElementById("name-prodacts-4-84"),
        
    data_name_prodacts_4_84 = 
    [
    "Nokia",
    "Nokia4.84",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_85 = document.getElementById("name-prodacts-4-85"),
        
    data_name_prodacts_4_85 = 
    [
    "Nokia",
    "Nokia4.85",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_86 = document.getElementById("name-prodacts-4-86"),
        
    data_name_prodacts_4_86 = 
    [
    "Nokia",
    "Nokia4.86",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_87 = document.getElementById("name-prodacts-4-87"),
        
    data_name_prodacts_4_87 = 
    [
    "Nokia",
    "Nokia4.87",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_88 = document.getElementById("name-prodacts-4-88"),
        
    data_name_prodacts_4_88 = 
    [
    "Nokia",
    "Nokia4.88",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],
    name_prodacts_4_89 = document.getElementById("name-prodacts-4-89"),
        
    data_name_prodacts_4_89 = 
    [
    "Nokia",
    "Nokia4.89",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_90 = document.getElementById("name-prodacts-4-90"),
        
    data_name_prodacts_4_90 = 
    [
    "Nokia",
    "Nokia4.90",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],  
    name_prodacts_4_91 = document.getElementById("name-prodacts-4-91"),
        
    data_name_prodacts_4_91 = 
    [
    "Nokia",
    "Nokia4.91",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_92 = document.getElementById("name-prodacts-4-92"),
        
    data_name_prodacts_4_92 = 
    [
    "Nokia",
    "Nokia4.92",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_93 = document.getElementById("name-prodacts-4-93"),
        
    data_name_prodacts_4_93 = 
    [
    "Nokia",
    "Nokia4.93",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_94 = document.getElementById("name-prodacts-4-94"),
        
    data_name_prodacts_4_94 = 
    [
    "Nokia",
    "Nokia4.94",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_95 = document.getElementById("name-prodacts-4-95"),
        
    data_name_prodacts_4_95 = 
    [
    "Nokia",
    "Nokia4.95",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_96 = document.getElementById("name-prodacts-4-96"),
        
    data_name_prodacts_4_96 = 
    [
    "Nokia",
    "Nokia4.96",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_97 = document.getElementById("name-prodacts-4-97"),
        
    data_name_prodacts_4_97 = 
    [
    "Nokia",
    "Nokia4.97",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_98 = document.getElementById("name-prodacts-4-98"),
        
    data_name_prodacts_4_98 = 
    [
    "Nokia",
    "Nokia4.98",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_99 = document.getElementById("name-prodacts-4-99"),
        
    data_name_prodacts_4_99 = 
    [
    "Nokia",
    "Nokia4.99",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_100 = document.getElementById("name-prodacts-4-100"),
        
    data_name_prodacts_4_100 = 
    [
    "Nokia",
    "Nokia4.100",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],     
    name_prodacts_4_101 = document.getElementById("name-prodacts-4-101"),
        
    data_name_prodacts_4_101 = 
    [
    "Nokia",
    "Nokia4.101",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_102 = document.getElementById("name-prodacts-4-102"),
        
    data_name_prodacts_4_102 = 
    [
    "Nokia",
    "Nokia4.102",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_4_103 = document.getElementById("name-prodacts-4-103"),
        
    data_name_prodacts_4_103 = 
    [
    "Nokia",
    "Nokia4.103",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_104 = document.getElementById("name-prodacts-4-104"),
        
    data_name_prodacts_4_104 = 
    [
    "Nokia",
    "Nokia4.104",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_105 = document.getElementById("name-prodacts-4-105"),
        
    data_name_prodacts_4_105 = 
    [
    "Nokia",
    "Nokia4.105",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_106 = document.getElementById("name-prodacts-4-106"),
        
    data_name_prodacts_4_106 = 
    [
    "Nokia",
    "Nokia4.106",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_107 = document.getElementById("name-prodacts-4-107"),
        
    data_name_prodacts_4_107 = 
    [
    "Nokia",
    "Nokia4.107",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_108 = document.getElementById("name-prodacts-4-108"),
        
    data_name_prodacts_4_108 = 
    [
    "Nokia",
    "Nokia4.108",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_109 = document.getElementById("name-prodacts-4-109"),
        
    data_name_prodacts_4_109 = 
    [
    "Nokia",
    "Nokia4.109",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_4_110 = document.getElementById("name-prodacts-4-110"),
        
    data_name_prodacts_4_110 = 
    [
    "Nokia",
    "Nokia4.110",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
        
    name_prodacts_4_111 = document.getElementById("name-prodacts-4-111"),
        
    data_name_prodacts_4_111 = 
    [
    "Nokia",
    "Nokia4.111",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_112 = document.getElementById("name-prodacts-4-112"),
        
    data_name_prodacts_4_112 = 
    [
    "Nokia",
    "Nokia4.112",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_4_113 = document.getElementById("name-prodacts-4-113"),
        
    data_name_prodacts_4_113 = 
    [
    "Nokia",
    "Nokia4.113",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_114 = document.getElementById("name-prodacts-4-114"),
        
    data_name_prodacts_4_114 = 
    [
    "Nokia",
    "Nokia4.114",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],   
    name_prodacts_4_115 = document.getElementById("name-prodacts-4-115"),
        
    data_name_prodacts_4_115 = 
    [
    "Nokia",
    "Nokia4.115",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_116 = document.getElementById("name-prodacts-4-116"),
        
    data_name_prodacts_4_116 = 
    [
    "Nokia",
    "Nokia4.116",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_117 = document.getElementById("name-prodacts-4-117"),
        
    data_name_prodacts_4_117 = 
    [
    "Nokia",
    "Nokia4.117",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_118 = document.getElementById("name-prodacts-4-118"),
        
    data_name_prodacts_4_118 = 
    [
    "Nokia",
    "Nokia4.118",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ], 
    name_prodacts_4_119 = document.getElementById("name-prodacts-4-119"),
        
    data_name_prodacts_4_119 = 
    [
    "Nokia",
    "Nokia4.119",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ],    
    name_prodacts_4_120 = document.getElementById("name-prodacts-4-120"),
        
    data_name_prodacts_4_120 = 
    [
    "Nokia",
    "Nokia4.120",
    "Nokia2",
    "Nokia3",
    "Nokia4",
    "Nokia5",
    "Nokia6",
    "Nokia7",
    "Nokia8",
    "Nokia9",
    "Nokia10"
    
    ];    
        
        
        
        
        
        
        
        
        
        
        
        
        
        
arrwo_right_big.onclick = function () {    

    
    all_element_img_ga.classList.add("toggle-all-element-img-ga");
    all_element_img_ga_2.classList.add("toggle-all-element-img-ga");
    all_element_img_ga_3.classList.add("toggle-all-element-img-ga");
    all_element_img_ga_4.classList.add("toggle-all-element-img-ga");
    
    setTimeout(function () {
        
        all_element_img_ga.classList.remove("toggle-all-element-img-ga");
        all_element_img_ga_2.classList.remove("toggle-all-element-img-ga");
        all_element_img_ga_3.classList.remove("toggle-all-element-img-ga");
        all_element_img_ga_4.classList.remove("toggle-all-element-img-ga");
        
    }, 1350);
    
    
    setTimeout(function () {
    if (counter == 49){

        return;

    }
        
        counter += 1;
        
        /*Start Gallery 1*/
        img_ga_1.src = name_img_1[counter];
        text_ga_1.textContent =  text_1[counter];
        gallery_1.textContent =  name_gallery_1[counter];
        /*End Gallery 1*/
        
        
        /*Start Gallery 2*/
        img_ga_2.src = name_img_2[counter];
        text_ga_2.textContent =  text_2[counter];
        gallery_2.textContent =  name_gallery_2[counter];
        /*End Gallery 2*/
        
        
        /*Start Gallery 3*/
        
        img_ga_3.src = name_img_3[counter];
        text_ga_3.textContent =  text_3[counter];
        gallery_3.textContent =  name_gallery_3[counter];
        
        /*End Gallery 3*/
        
        
        /*Start Gallery 4*/
        img_ga_4.src = name_img_4[counter];
        text_ga_4.textContent =  text_4[counter];
        gallery_4.textContent =  name_gallery_4[counter];
        /*End Gallery 4*/
        
        
        
        /*Start img_section_prodacts_gallery_1*/
        
        icone_section_prodacts_1.src = name_img_1[counter];
        
        img_section_prodacts_gallery_1_1.src = name_img_section_prodacts_gallery_1_1[counter]
        img_section_prodacts_gallery_1_2.src = name_img_section_prodacts_gallery_1_2[counter]
        img_section_prodacts_gallery_1_3.src = name_img_section_prodacts_gallery_1_3[counter]
        img_section_prodacts_gallery_1_4.src = name_img_section_prodacts_gallery_1_4[counter]
        img_section_prodacts_gallery_1_5.src = name_img_section_prodacts_gallery_1_5[counter]
        img_section_prodacts_gallery_1_6.src = name_img_section_prodacts_gallery_1_6[counter]
        img_section_prodacts_gallery_1_7.src = name_img_section_prodacts_gallery_1_7[counter]
        img_section_prodacts_gallery_1_8.src = name_img_section_prodacts_gallery_1_8[counter]
        img_section_prodacts_gallery_1_9.src = name_img_section_prodacts_gallery_1_9[counter]
        img_section_prodacts_gallery_1_10.src = name_img_section_prodacts_gallery_1_10[counter]
        img_section_prodacts_gallery_1_11.src = name_img_section_prodacts_gallery_1_11[counter]
        img_section_prodacts_gallery_1_12.src = name_img_section_prodacts_gallery_1_12[counter]
        
        /*Name 1*/ 
        name_section_prodacts_1_1.textContent = data_name_1_1[counter];
        name_section_prodacts_1_2.textContent = data_name_1_2[counter];
        name_section_prodacts_1_3.textContent = data_name_1_3[counter];
        name_section_prodacts_1_4.textContent = data_name_1_4[counter];
        name_section_prodacts_1_5.textContent = data_name_1_5[counter];
        name_section_prodacts_1_6.textContent = data_name_1_6[counter];
        name_section_prodacts_1_7.textContent = data_name_1_7[counter];
        name_section_prodacts_1_8.textContent = data_name_1_8[counter];
        name_section_prodacts_1_9.textContent = data_name_1_9[counter];
        name_section_prodacts_1_10.textContent = data_name_1_10[counter];
        name_section_prodacts_1_11.textContent = data_name_1_11[counter];
        name_section_prodacts_1_12.textContent = data_name_1_12[counter];
        
        
        
        /*intro 1*/
        intro_section_prodacts_1_1.textContent = data_intro_1_1[counter];
        intro_section_prodacts_1_2.textContent = data_intro_1_2[counter];
        intro_section_prodacts_1_3.textContent = data_intro_1_3[counter];
        intro_section_prodacts_1_4.textContent = data_intro_1_4[counter];
        intro_section_prodacts_1_5.textContent = data_intro_1_5[counter];
        intro_section_prodacts_1_6.textContent = data_intro_1_6[counter];
        intro_section_prodacts_1_7.textContent = data_intro_1_7[counter];
        intro_section_prodacts_1_8.textContent = data_intro_1_8[counter];
        intro_section_prodacts_1_9.textContent = data_intro_1_9[counter];
        intro_section_prodacts_1_10.textContent = data_intro_1_10[counter];
        intro_section_prodacts_1_11.textContent = data_intro_1_11[counter];
        intro_section_prodacts_1_12.textContent = data_intro_1_12[counter];
        
        /*End img_section_prodacts_gallery_1*/
        
        
        /*Start img_section_prodacts_gallery_2*/
        
        icone_section_prodacts_2.src = name_img_2[counter];
        img_section_prodacts_gallery_2_1.src = name_img_section_prodacts_gallery_2_1[counter]
        img_section_prodacts_gallery_2_2.src = name_img_section_prodacts_gallery_2_2[counter]
        img_section_prodacts_gallery_2_3.src = name_img_section_prodacts_gallery_2_3[counter]
        img_section_prodacts_gallery_2_4.src = name_img_section_prodacts_gallery_2_4[counter]
        img_section_prodacts_gallery_2_5.src = name_img_section_prodacts_gallery_2_5[counter]
        img_section_prodacts_gallery_2_6.src = name_img_section_prodacts_gallery_2_6[counter]
        img_section_prodacts_gallery_2_7.src = name_img_section_prodacts_gallery_2_7[counter]
        img_section_prodacts_gallery_2_8.src = name_img_section_prodacts_gallery_2_8[counter]
        img_section_prodacts_gallery_2_9.src = name_img_section_prodacts_gallery_2_9[counter]
        img_section_prodacts_gallery_2_10.src = name_img_section_prodacts_gallery_2_10[counter]
        img_section_prodacts_gallery_2_11.src = name_img_section_prodacts_gallery_2_11[counter]
        img_section_prodacts_gallery_2_12.src = name_img_section_prodacts_gallery_2_12[counter]
        
        
        /*Name 2*/ 
        name_section_prodacts_2_1.textContent = data_name_2_1[counter];
        name_section_prodacts_2_2.textContent = data_name_2_2[counter];
        name_section_prodacts_2_3.textContent = data_name_2_3[counter];
        name_section_prodacts_2_4.textContent = data_name_2_4[counter];
        name_section_prodacts_2_5.textContent = data_name_2_5[counter];
        name_section_prodacts_2_6.textContent = data_name_2_6[counter];
        name_section_prodacts_2_7.textContent = data_name_2_7[counter];
        name_section_prodacts_2_8.textContent = data_name_2_8[counter];
        name_section_prodacts_2_9.textContent = data_name_2_9[counter];
        name_section_prodacts_2_10.textContent = data_name_2_10[counter];
        name_section_prodacts_2_11.textContent = data_name_2_11[counter];
        name_section_prodacts_2_12.textContent = data_name_2_12[counter];
        
        
        /*intro 2*/
        intro_section_prodacts_2_1.textContent = data_intro_2_1[counter];
        intro_section_prodacts_2_2.textContent = data_intro_2_2[counter];
        intro_section_prodacts_2_3.textContent = data_intro_2_3[counter];
        intro_section_prodacts_2_4.textContent = data_intro_2_4[counter];
        intro_section_prodacts_2_5.textContent = data_intro_2_5[counter];
        intro_section_prodacts_2_6.textContent = data_intro_2_6[counter];
        intro_section_prodacts_2_7.textContent = data_intro_2_7[counter];
        intro_section_prodacts_2_8.textContent = data_intro_2_8[counter];
        intro_section_prodacts_2_9.textContent = data_intro_2_9[counter];
        intro_section_prodacts_2_10.textContent = data_intro_2_10[counter];
        intro_section_prodacts_2_11.textContent = data_intro_2_11[counter];
        intro_section_prodacts_2_12.textContent = data_intro_2_12[counter];
        
        /*End img_section_prodacts_gallery_2*/
        
        
        /*Start img_section_prodacts_gallery_3*/
        
        icone_section_prodacts_3.src = name_img_3[counter];
        img_section_prodacts_gallery_3_1.src = name_img_section_prodacts_gallery_3_1[counter]
        img_section_prodacts_gallery_3_2.src = name_img_section_prodacts_gallery_3_2[counter]
        img_section_prodacts_gallery_3_3.src = name_img_section_prodacts_gallery_3_3[counter]
        img_section_prodacts_gallery_3_4.src = name_img_section_prodacts_gallery_3_4[counter]
        img_section_prodacts_gallery_3_5.src = name_img_section_prodacts_gallery_3_5[counter]
        img_section_prodacts_gallery_3_6.src = name_img_section_prodacts_gallery_3_6[counter]
        img_section_prodacts_gallery_3_7.src = name_img_section_prodacts_gallery_3_7[counter]
        img_section_prodacts_gallery_3_8.src = name_img_section_prodacts_gallery_3_8[counter]
        img_section_prodacts_gallery_3_9.src = name_img_section_prodacts_gallery_3_9[counter]
        img_section_prodacts_gallery_3_10.src = name_img_section_prodacts_gallery_3_10[counter]
        img_section_prodacts_gallery_3_11.src = name_img_section_prodacts_gallery_3_11[counter]
        img_section_prodacts_gallery_3_12.src = name_img_section_prodacts_gallery_3_12[counter]
        
        
        /*Name 3*/ 
        name_section_prodacts_3_1.textContent = data_name_3_1[counter];
        name_section_prodacts_3_2.textContent = data_name_3_2[counter];
        name_section_prodacts_3_3.textContent = data_name_3_3[counter];
        name_section_prodacts_3_4.textContent = data_name_3_4[counter];
        name_section_prodacts_3_5.textContent = data_name_3_5[counter];
        name_section_prodacts_3_6.textContent = data_name_3_6[counter];
        name_section_prodacts_3_7.textContent = data_name_3_7[counter];
        name_section_prodacts_3_8.textContent = data_name_3_8[counter];
        name_section_prodacts_3_9.textContent = data_name_3_9[counter];
        name_section_prodacts_3_10.textContent = data_name_3_10[counter];
        name_section_prodacts_3_11.textContent = data_name_3_11[counter];
        name_section_prodacts_3_12.textContent = data_name_3_12[counter];
        
        /*intro 3*/
        intro_section_prodacts_3_1.textContent = data_intro_3_1[counter];
        intro_section_prodacts_3_2.textContent = data_intro_3_2[counter];
        intro_section_prodacts_3_3.textContent = data_intro_3_3[counter];
        intro_section_prodacts_3_4.textContent = data_intro_3_4[counter];
        intro_section_prodacts_3_5.textContent = data_intro_3_5[counter];
        intro_section_prodacts_3_6.textContent = data_intro_3_6[counter];
        intro_section_prodacts_3_7.textContent = data_intro_3_7[counter];
        intro_section_prodacts_3_8.textContent = data_intro_3_8[counter];
        intro_section_prodacts_3_9.textContent = data_intro_3_9[counter];
        intro_section_prodacts_3_10.textContent = data_intro_3_10[counter];
        intro_section_prodacts_3_11.textContent = data_intro_3_11[counter];
        intro_section_prodacts_3_12.textContent = data_intro_3_12[counter];
        
        
        /*End img_section_prodacts_gallery_3*/
        
        /*Start img_section_prodacts_gallery_4*/
        
        
        icone_section_prodacts_4.src = name_img_4[counter];
        img_section_prodacts_gallery_4_1.src = name_img_section_prodacts_gallery_4_1[counter]
        img_section_prodacts_gallery_4_2.src = name_img_section_prodacts_gallery_4_2[counter]
        img_section_prodacts_gallery_4_3.src = name_img_section_prodacts_gallery_4_3[counter]
        img_section_prodacts_gallery_4_4.src = name_img_section_prodacts_gallery_4_4[counter]
        img_section_prodacts_gallery_4_5.src = name_img_section_prodacts_gallery_4_5[counter]
        img_section_prodacts_gallery_4_6.src = name_img_section_prodacts_gallery_4_6[counter]
        img_section_prodacts_gallery_4_7.src = name_img_section_prodacts_gallery_4_7[counter]
        img_section_prodacts_gallery_4_8.src = name_img_section_prodacts_gallery_4_8[counter]
        img_section_prodacts_gallery_4_9.src = name_img_section_prodacts_gallery_4_9[counter]
        img_section_prodacts_gallery_4_10.src = name_img_section_prodacts_gallery_4_10[counter]
        img_section_prodacts_gallery_4_11.src = name_img_section_prodacts_gallery_4_11[counter]
        img_section_prodacts_gallery_4_12.src = name_img_section_prodacts_gallery_4_12[counter]
        
        
        /*Name 4*/ 
        name_section_prodacts_4_1.textContent = data_name_4_1[counter];
        name_section_prodacts_4_2.textContent = data_name_4_2[counter];
        name_section_prodacts_4_3.textContent = data_name_4_3[counter];
        name_section_prodacts_4_4.textContent = data_name_4_4[counter];
        name_section_prodacts_4_5.textContent = data_name_4_5[counter];
        name_section_prodacts_4_6.textContent = data_name_4_6[counter];
        name_section_prodacts_4_7.textContent = data_name_4_7[counter];
        name_section_prodacts_4_8.textContent = data_name_4_8[counter];
        name_section_prodacts_4_9.textContent = data_name_4_9[counter];
        name_section_prodacts_4_10.textContent = data_name_4_10[counter];
        name_section_prodacts_4_11.textContent = data_name_4_11[counter];
        name_section_prodacts_4_12.textContent = data_name_4_12[counter];
        
        /*intro 4*/
        intro_section_prodacts_4_1.textContent = data_intro_4_1[counter];
        intro_section_prodacts_4_2.textContent = data_intro_4_2[counter];
        intro_section_prodacts_4_3.textContent = data_intro_4_3[counter];
        intro_section_prodacts_4_4.textContent = data_intro_4_4[counter];
        intro_section_prodacts_4_5.textContent = data_intro_4_5[counter];
        intro_section_prodacts_4_6.textContent = data_intro_4_6[counter];
        intro_section_prodacts_4_7.textContent = data_intro_4_7[counter];
        intro_section_prodacts_4_8.textContent = data_intro_4_8[counter];
        intro_section_prodacts_4_9.textContent = data_intro_4_9[counter];
        intro_section_prodacts_4_10.textContent = data_intro_4_10[counter];
        intro_section_prodacts_4_11.textContent = data_intro_4_11[counter];
        intro_section_prodacts_4_12.textContent = data_intro_4_12[counter];
        
        
        /*End img_section_prodacts_gallery_4*/
        
        
        /*Data Name prodacts 1 */
        name_prodacts_1_1.textContent = data_name_prodacts_1_1[counter]
        name_prodacts_1_2.textContent = data_name_prodacts_1_2[counter]
        name_prodacts_1_3.textContent = data_name_prodacts_1_3[counter]
        name_prodacts_1_4.textContent = data_name_prodacts_1_4[counter]
        name_prodacts_1_5.textContent = data_name_prodacts_1_5[counter]
        name_prodacts_1_6.textContent = data_name_prodacts_1_6[counter]
        name_prodacts_1_7.textContent = data_name_prodacts_1_7[counter]
        name_prodacts_1_8.textContent = data_name_prodacts_1_8[counter]
        name_prodacts_1_9.textContent = data_name_prodacts_1_9[counter]
        name_prodacts_1_10.textContent = data_name_prodacts_1_10[counter]
        name_prodacts_1_11.textContent = data_name_prodacts_1_11[counter]
        name_prodacts_1_12.textContent = data_name_prodacts_1_12[counter]
        name_prodacts_1_13.textContent = data_name_prodacts_1_13[counter]
        name_prodacts_1_14.textContent = data_name_prodacts_1_14[counter]
        name_prodacts_1_15.textContent = data_name_prodacts_1_15[counter]
        name_prodacts_1_16.textContent = data_name_prodacts_1_16[counter]
        name_prodacts_1_17.textContent = data_name_prodacts_1_17[counter]
        name_prodacts_1_18.textContent = data_name_prodacts_1_18[counter]
        name_prodacts_1_19.textContent = data_name_prodacts_1_19[counter]
        name_prodacts_1_20.textContent = data_name_prodacts_1_20[counter]
        name_prodacts_1_21.textContent = data_name_prodacts_1_21[counter]
        name_prodacts_1_22.textContent = data_name_prodacts_1_22[counter]
        name_prodacts_1_23.textContent = data_name_prodacts_1_23[counter]
        name_prodacts_1_24.textContent = data_name_prodacts_1_24[counter]
        name_prodacts_1_25.textContent = data_name_prodacts_1_25[counter]
        name_prodacts_1_26.textContent = data_name_prodacts_1_26[counter]
        name_prodacts_1_27.textContent = data_name_prodacts_1_27[counter]
        name_prodacts_1_28.textContent = data_name_prodacts_1_28[counter]
        name_prodacts_1_29.textContent = data_name_prodacts_1_29[counter]
        name_prodacts_1_30.textContent = data_name_prodacts_1_30[counter]
        name_prodacts_1_31.textContent = data_name_prodacts_1_31[counter]
        name_prodacts_1_32.textContent = data_name_prodacts_1_32[counter]
        name_prodacts_1_33.textContent = data_name_prodacts_1_33[counter]
        name_prodacts_1_34.textContent = data_name_prodacts_1_34[counter]
        name_prodacts_1_35.textContent = data_name_prodacts_1_35[counter]
        name_prodacts_1_36.textContent = data_name_prodacts_1_36[counter]
        name_prodacts_1_37.textContent = data_name_prodacts_1_37[counter]
        name_prodacts_1_38.textContent = data_name_prodacts_1_38[counter]
        name_prodacts_1_39.textContent = data_name_prodacts_1_39[counter]
        name_prodacts_1_40.textContent = data_name_prodacts_1_40[counter]
        name_prodacts_1_41.textContent = data_name_prodacts_1_41[counter]
        name_prodacts_1_42.textContent = data_name_prodacts_1_42[counter]
        name_prodacts_1_43.textContent = data_name_prodacts_1_43[counter]
        name_prodacts_1_44.textContent = data_name_prodacts_1_44[counter]
        name_prodacts_1_45.textContent = data_name_prodacts_1_45[counter]
        name_prodacts_1_46.textContent = data_name_prodacts_1_46[counter]
        name_prodacts_1_47.textContent = data_name_prodacts_1_47[counter]
        name_prodacts_1_48.textContent = data_name_prodacts_1_48[counter]
        name_prodacts_1_49.textContent = data_name_prodacts_1_49[counter]
        name_prodacts_1_50.textContent = data_name_prodacts_1_50[counter]
        name_prodacts_1_51.textContent = data_name_prodacts_1_51[counter]
        name_prodacts_1_52.textContent = data_name_prodacts_1_52[counter]
        name_prodacts_1_53.textContent = data_name_prodacts_1_53[counter]
        name_prodacts_1_54.textContent = data_name_prodacts_1_54[counter]
        name_prodacts_1_55.textContent = data_name_prodacts_1_55[counter]
        name_prodacts_1_56.textContent = data_name_prodacts_1_56[counter]
        name_prodacts_1_57.textContent = data_name_prodacts_1_57[counter]
        name_prodacts_1_58.textContent = data_name_prodacts_1_58[counter]
        name_prodacts_1_59.textContent = data_name_prodacts_1_59[counter]
        name_prodacts_1_60.textContent = data_name_prodacts_1_60[counter]
        name_prodacts_1_61.textContent = data_name_prodacts_1_61[counter]
        name_prodacts_1_62.textContent = data_name_prodacts_1_62[counter]
        name_prodacts_1_63.textContent = data_name_prodacts_1_63[counter]
        name_prodacts_1_64.textContent = data_name_prodacts_1_64[counter]
        name_prodacts_1_65.textContent = data_name_prodacts_1_65[counter]
        name_prodacts_1_66.textContent = data_name_prodacts_1_66[counter]
        name_prodacts_1_67.textContent = data_name_prodacts_1_67[counter]
        name_prodacts_1_68.textContent = data_name_prodacts_1_68[counter]
        name_prodacts_1_69.textContent = data_name_prodacts_1_69[counter]
        name_prodacts_1_70.textContent = data_name_prodacts_1_70[counter]
        name_prodacts_1_71.textContent = data_name_prodacts_1_71[counter]
        name_prodacts_1_72.textContent = data_name_prodacts_1_72[counter]
        name_prodacts_1_73.textContent = data_name_prodacts_1_73[counter]
        name_prodacts_1_74.textContent = data_name_prodacts_1_74[counter]
        name_prodacts_1_75.textContent = data_name_prodacts_1_75[counter]
        name_prodacts_1_76.textContent = data_name_prodacts_1_76[counter]
        name_prodacts_1_77.textContent = data_name_prodacts_1_77[counter]
        name_prodacts_1_78.textContent = data_name_prodacts_1_78[counter]
        name_prodacts_1_79.textContent = data_name_prodacts_1_79[counter]
        name_prodacts_1_80.textContent = data_name_prodacts_1_80[counter]
        name_prodacts_1_81.textContent = data_name_prodacts_1_81[counter]
        name_prodacts_1_82.textContent = data_name_prodacts_1_82[counter]
        name_prodacts_1_83.textContent = data_name_prodacts_1_83[counter]
        name_prodacts_1_84.textContent = data_name_prodacts_1_84[counter]
        name_prodacts_1_85.textContent = data_name_prodacts_1_85[counter]
        name_prodacts_1_86.textContent = data_name_prodacts_1_86[counter]
        name_prodacts_1_87.textContent = data_name_prodacts_1_87[counter]
        name_prodacts_1_88.textContent = data_name_prodacts_1_88[counter]
        name_prodacts_1_89.textContent = data_name_prodacts_1_89[counter]
        name_prodacts_1_90.textContent = data_name_prodacts_1_90[counter]
        name_prodacts_1_91.textContent = data_name_prodacts_1_91[counter]
        name_prodacts_1_92.textContent = data_name_prodacts_1_92[counter]
        name_prodacts_1_93.textContent = data_name_prodacts_1_93[counter]
        name_prodacts_1_94.textContent = data_name_prodacts_1_94[counter]
        name_prodacts_1_95.textContent = data_name_prodacts_1_95[counter]
        name_prodacts_1_96.textContent = data_name_prodacts_1_96[counter]
        name_prodacts_1_97.textContent = data_name_prodacts_1_97[counter]
        name_prodacts_1_98.textContent = data_name_prodacts_1_98[counter]
        name_prodacts_1_99.textContent = data_name_prodacts_1_99[counter]
        name_prodacts_1_100.textContent = data_name_prodacts_1_100[counter]
        name_prodacts_1_101.textContent = data_name_prodacts_1_101[counter]
        name_prodacts_1_102.textContent = data_name_prodacts_1_102[counter]
        name_prodacts_1_103.textContent = data_name_prodacts_1_103[counter]
        name_prodacts_1_104.textContent = data_name_prodacts_1_104[counter]
        name_prodacts_1_105.textContent = data_name_prodacts_1_105[counter]
        name_prodacts_1_106.textContent = data_name_prodacts_1_106[counter]
        name_prodacts_1_107.textContent = data_name_prodacts_1_107[counter]
        name_prodacts_1_108.textContent = data_name_prodacts_1_108[counter]
        name_prodacts_1_109.textContent = data_name_prodacts_1_109[counter]
        name_prodacts_1_110.textContent = data_name_prodacts_1_110[counter]
        name_prodacts_1_111.textContent = data_name_prodacts_1_111[counter]
        name_prodacts_1_112.textContent = data_name_prodacts_1_112[counter]
        name_prodacts_1_113.textContent = data_name_prodacts_1_113[counter]
        name_prodacts_1_114.textContent = data_name_prodacts_1_114[counter]
        name_prodacts_1_115.textContent = data_name_prodacts_1_115[counter]
        name_prodacts_1_116.textContent = data_name_prodacts_1_116[counter]
        name_prodacts_1_117.textContent = data_name_prodacts_1_117[counter]
        name_prodacts_1_118.textContent = data_name_prodacts_1_118[counter]
        name_prodacts_1_119.textContent = data_name_prodacts_1_119[counter]
        name_prodacts_1_120.textContent = data_name_prodacts_1_120[counter]
        /*Data Name prodacts 1 */
        
        
        
        /*Data Name prodacts 2 */
        
        
        name_prodacts_2_1.textContent = data_name_prodacts_2_1[counter]
        name_prodacts_2_2.textContent = data_name_prodacts_2_2[counter]
        name_prodacts_2_3.textContent = data_name_prodacts_2_3[counter]
        name_prodacts_2_4.textContent = data_name_prodacts_2_4[counter]
        name_prodacts_2_5.textContent = data_name_prodacts_2_5[counter]
        name_prodacts_2_6.textContent = data_name_prodacts_2_6[counter]
        name_prodacts_2_7.textContent = data_name_prodacts_2_7[counter]
        name_prodacts_2_8.textContent = data_name_prodacts_2_8[counter]
        name_prodacts_2_9.textContent = data_name_prodacts_2_9[counter]
        name_prodacts_2_10.textContent = data_name_prodacts_2_10[counter]
        name_prodacts_2_11.textContent = data_name_prodacts_2_11[counter]
        name_prodacts_2_12.textContent = data_name_prodacts_2_12[counter]
        name_prodacts_2_13.textContent = data_name_prodacts_2_13[counter]
        name_prodacts_2_14.textContent = data_name_prodacts_2_14[counter]
        name_prodacts_2_15.textContent = data_name_prodacts_2_15[counter]
        name_prodacts_2_16.textContent = data_name_prodacts_2_16[counter]
        name_prodacts_2_17.textContent = data_name_prodacts_2_17[counter]
        name_prodacts_2_18.textContent = data_name_prodacts_2_18[counter]
        name_prodacts_2_19.textContent = data_name_prodacts_2_19[counter]
        name_prodacts_2_20.textContent = data_name_prodacts_2_20[counter]
        name_prodacts_2_21.textContent = data_name_prodacts_2_21[counter]
        name_prodacts_2_22.textContent = data_name_prodacts_2_22[counter]
        name_prodacts_2_23.textContent = data_name_prodacts_2_23[counter]
        name_prodacts_2_24.textContent = data_name_prodacts_2_24[counter]
        name_prodacts_2_25.textContent = data_name_prodacts_2_25[counter]
        name_prodacts_2_26.textContent = data_name_prodacts_2_26[counter]
        name_prodacts_2_27.textContent = data_name_prodacts_2_27[counter]
        name_prodacts_2_28.textContent = data_name_prodacts_2_28[counter]
        name_prodacts_2_29.textContent = data_name_prodacts_2_29[counter]
        name_prodacts_2_30.textContent = data_name_prodacts_2_30[counter]
        name_prodacts_2_31.textContent = data_name_prodacts_2_31[counter]
        name_prodacts_2_32.textContent = data_name_prodacts_2_32[counter]
        name_prodacts_2_33.textContent = data_name_prodacts_2_33[counter]
        name_prodacts_2_34.textContent = data_name_prodacts_2_34[counter]
        name_prodacts_2_35.textContent = data_name_prodacts_2_35[counter]
        name_prodacts_2_36.textContent = data_name_prodacts_2_36[counter]
        name_prodacts_2_37.textContent = data_name_prodacts_2_37[counter]
        name_prodacts_2_38.textContent = data_name_prodacts_2_38[counter]
        name_prodacts_2_39.textContent = data_name_prodacts_2_39[counter]
        name_prodacts_2_40.textContent = data_name_prodacts_2_40[counter]
        name_prodacts_2_41.textContent = data_name_prodacts_2_41[counter]
        name_prodacts_2_42.textContent = data_name_prodacts_2_42[counter]
        name_prodacts_2_43.textContent = data_name_prodacts_2_43[counter]
        name_prodacts_2_44.textContent = data_name_prodacts_2_44[counter]
        name_prodacts_2_45.textContent = data_name_prodacts_2_45[counter]
        name_prodacts_2_46.textContent = data_name_prodacts_2_46[counter]
        name_prodacts_2_47.textContent = data_name_prodacts_2_47[counter]
        name_prodacts_2_48.textContent = data_name_prodacts_2_48[counter]
        name_prodacts_2_49.textContent = data_name_prodacts_2_49[counter]
        name_prodacts_2_50.textContent = data_name_prodacts_2_50[counter]
        name_prodacts_2_51.textContent = data_name_prodacts_2_51[counter]
        name_prodacts_2_52.textContent = data_name_prodacts_2_52[counter]
        name_prodacts_2_53.textContent = data_name_prodacts_2_53[counter]
        name_prodacts_2_54.textContent = data_name_prodacts_2_54[counter]
        name_prodacts_2_55.textContent = data_name_prodacts_2_55[counter]
        name_prodacts_2_56.textContent = data_name_prodacts_2_56[counter]
        name_prodacts_2_57.textContent = data_name_prodacts_2_57[counter]
        name_prodacts_2_58.textContent = data_name_prodacts_2_58[counter]
        name_prodacts_2_59.textContent = data_name_prodacts_2_59[counter]
        name_prodacts_2_60.textContent = data_name_prodacts_2_60[counter]
        name_prodacts_2_61.textContent = data_name_prodacts_2_61[counter]
        name_prodacts_2_62.textContent = data_name_prodacts_2_62[counter]
        name_prodacts_2_63.textContent = data_name_prodacts_2_63[counter]
        name_prodacts_2_64.textContent = data_name_prodacts_2_64[counter]
        name_prodacts_2_65.textContent = data_name_prodacts_2_65[counter]
        name_prodacts_2_66.textContent = data_name_prodacts_2_66[counter]
        name_prodacts_2_67.textContent = data_name_prodacts_2_67[counter]
        name_prodacts_2_68.textContent = data_name_prodacts_2_68[counter]
        name_prodacts_2_69.textContent = data_name_prodacts_2_69[counter]
        name_prodacts_2_70.textContent = data_name_prodacts_2_70[counter]
        name_prodacts_2_71.textContent = data_name_prodacts_2_71[counter]
        name_prodacts_2_72.textContent = data_name_prodacts_2_72[counter]
        name_prodacts_2_73.textContent = data_name_prodacts_2_73[counter]
        name_prodacts_2_74.textContent = data_name_prodacts_2_74[counter]
        name_prodacts_2_75.textContent = data_name_prodacts_2_75[counter]
        name_prodacts_2_76.textContent = data_name_prodacts_2_76[counter]
        name_prodacts_2_77.textContent = data_name_prodacts_2_77[counter]
        name_prodacts_2_78.textContent = data_name_prodacts_2_78[counter]
        name_prodacts_2_79.textContent = data_name_prodacts_2_79[counter]
        name_prodacts_2_80.textContent = data_name_prodacts_2_80[counter]
        name_prodacts_2_81.textContent = data_name_prodacts_2_81[counter]
        name_prodacts_2_82.textContent = data_name_prodacts_2_82[counter]
        name_prodacts_2_83.textContent = data_name_prodacts_2_83[counter]
        name_prodacts_2_84.textContent = data_name_prodacts_2_84[counter]
        name_prodacts_2_85.textContent = data_name_prodacts_2_85[counter]
        name_prodacts_2_86.textContent = data_name_prodacts_2_86[counter]
        name_prodacts_2_87.textContent = data_name_prodacts_2_87[counter]
        name_prodacts_2_88.textContent = data_name_prodacts_2_88[counter]
        name_prodacts_2_89.textContent = data_name_prodacts_2_89[counter]
        name_prodacts_2_90.textContent = data_name_prodacts_2_90[counter]
        name_prodacts_2_91.textContent = data_name_prodacts_2_91[counter]
        name_prodacts_2_92.textContent = data_name_prodacts_2_92[counter]
        name_prodacts_2_93.textContent = data_name_prodacts_2_93[counter]
        name_prodacts_2_94.textContent = data_name_prodacts_2_94[counter]
        name_prodacts_2_95.textContent = data_name_prodacts_2_95[counter]
        name_prodacts_2_96.textContent = data_name_prodacts_2_96[counter]
        name_prodacts_2_97.textContent = data_name_prodacts_2_97[counter]
        name_prodacts_2_98.textContent = data_name_prodacts_2_98[counter]
        name_prodacts_2_99.textContent = data_name_prodacts_2_99[counter]
        name_prodacts_2_100.textContent = data_name_prodacts_2_100[counter]
        name_prodacts_2_101.textContent = data_name_prodacts_2_101[counter]
        name_prodacts_2_102.textContent = data_name_prodacts_2_102[counter]
        name_prodacts_2_103.textContent = data_name_prodacts_2_103[counter]
        name_prodacts_2_104.textContent = data_name_prodacts_2_104[counter]
        name_prodacts_2_105.textContent = data_name_prodacts_2_105[counter]
        name_prodacts_2_106.textContent = data_name_prodacts_2_106[counter]
        name_prodacts_2_107.textContent = data_name_prodacts_2_107[counter]
        name_prodacts_2_108.textContent = data_name_prodacts_2_108[counter]
        name_prodacts_2_109.textContent = data_name_prodacts_2_109[counter]
        name_prodacts_2_110.textContent = data_name_prodacts_2_110[counter]
        name_prodacts_2_111.textContent = data_name_prodacts_2_111[counter]
        name_prodacts_2_112.textContent = data_name_prodacts_2_112[counter]
        name_prodacts_2_113.textContent = data_name_prodacts_2_113[counter]
        name_prodacts_2_114.textContent = data_name_prodacts_2_114[counter]
        name_prodacts_2_115.textContent = data_name_prodacts_2_115[counter]
        name_prodacts_2_116.textContent = data_name_prodacts_2_116[counter]
        name_prodacts_2_117.textContent = data_name_prodacts_2_117[counter]
        name_prodacts_2_118.textContent = data_name_prodacts_2_118[counter]
        name_prodacts_2_119.textContent = data_name_prodacts_2_119[counter]
        name_prodacts_2_120.textContent = data_name_prodacts_2_120[counter]
        
        /*Data Name prodacts 2 */
        
        
        /*Data Name prodacts 3 */
        
        name_prodacts_3_1.textContent = data_name_prodacts_3_1[counter]
        name_prodacts_3_2.textContent = data_name_prodacts_3_2[counter]
        name_prodacts_3_3.textContent = data_name_prodacts_3_3[counter]
        name_prodacts_3_4.textContent = data_name_prodacts_3_4[counter]
        name_prodacts_3_5.textContent = data_name_prodacts_3_5[counter]
        name_prodacts_3_6.textContent = data_name_prodacts_3_6[counter]
        name_prodacts_3_7.textContent = data_name_prodacts_3_7[counter]
        name_prodacts_3_8.textContent = data_name_prodacts_3_8[counter]
        name_prodacts_3_9.textContent = data_name_prodacts_3_9[counter]
        name_prodacts_3_10.textContent = data_name_prodacts_3_10[counter]
        name_prodacts_3_11.textContent = data_name_prodacts_3_11[counter]
        name_prodacts_3_12.textContent = data_name_prodacts_3_12[counter]
        name_prodacts_3_13.textContent = data_name_prodacts_3_13[counter]
        name_prodacts_3_14.textContent = data_name_prodacts_3_14[counter]
        name_prodacts_3_15.textContent = data_name_prodacts_3_15[counter]
        name_prodacts_3_16.textContent = data_name_prodacts_3_16[counter]
        name_prodacts_3_17.textContent = data_name_prodacts_3_17[counter]
        name_prodacts_3_18.textContent = data_name_prodacts_3_18[counter]
        name_prodacts_3_19.textContent = data_name_prodacts_3_19[counter]
        name_prodacts_3_20.textContent = data_name_prodacts_3_20[counter]
        name_prodacts_3_21.textContent = data_name_prodacts_3_21[counter]
        name_prodacts_3_22.textContent = data_name_prodacts_3_22[counter]
        name_prodacts_3_23.textContent = data_name_prodacts_3_23[counter]
        name_prodacts_3_24.textContent = data_name_prodacts_3_24[counter]
        name_prodacts_3_25.textContent = data_name_prodacts_3_25[counter]
        name_prodacts_3_26.textContent = data_name_prodacts_3_26[counter]
        name_prodacts_3_27.textContent = data_name_prodacts_3_27[counter]
        name_prodacts_3_28.textContent = data_name_prodacts_3_28[counter]
        name_prodacts_3_29.textContent = data_name_prodacts_3_29[counter]
        name_prodacts_3_30.textContent = data_name_prodacts_3_30[counter]
        name_prodacts_3_31.textContent = data_name_prodacts_3_31[counter]
        name_prodacts_3_32.textContent = data_name_prodacts_3_32[counter]
        name_prodacts_3_33.textContent = data_name_prodacts_3_33[counter]
        name_prodacts_3_34.textContent = data_name_prodacts_3_34[counter]
        name_prodacts_3_35.textContent = data_name_prodacts_3_35[counter]
        name_prodacts_3_36.textContent = data_name_prodacts_3_36[counter]
        name_prodacts_3_37.textContent = data_name_prodacts_3_37[counter]
        name_prodacts_3_38.textContent = data_name_prodacts_3_38[counter]
        name_prodacts_3_39.textContent = data_name_prodacts_3_39[counter]
        name_prodacts_3_40.textContent = data_name_prodacts_3_40[counter]
        name_prodacts_3_41.textContent = data_name_prodacts_3_41[counter]
        name_prodacts_3_42.textContent = data_name_prodacts_3_42[counter]
        name_prodacts_3_43.textContent = data_name_prodacts_3_43[counter]
        name_prodacts_3_44.textContent = data_name_prodacts_3_44[counter]
        name_prodacts_3_45.textContent = data_name_prodacts_3_45[counter]
        name_prodacts_3_46.textContent = data_name_prodacts_3_46[counter]
        name_prodacts_3_47.textContent = data_name_prodacts_3_47[counter]
        name_prodacts_3_48.textContent = data_name_prodacts_3_48[counter]
        name_prodacts_3_49.textContent = data_name_prodacts_3_49[counter]
        name_prodacts_3_50.textContent = data_name_prodacts_3_50[counter]
        name_prodacts_3_51.textContent = data_name_prodacts_3_51[counter]
        name_prodacts_3_52.textContent = data_name_prodacts_3_52[counter]
        name_prodacts_3_53.textContent = data_name_prodacts_3_53[counter]
        name_prodacts_3_54.textContent = data_name_prodacts_3_54[counter]
        name_prodacts_3_55.textContent = data_name_prodacts_3_55[counter]
        name_prodacts_3_56.textContent = data_name_prodacts_3_56[counter]
        name_prodacts_3_57.textContent = data_name_prodacts_3_57[counter]
        name_prodacts_3_58.textContent = data_name_prodacts_3_58[counter]
        name_prodacts_3_59.textContent = data_name_prodacts_3_59[counter]
        name_prodacts_3_60.textContent = data_name_prodacts_3_60[counter]
        name_prodacts_3_61.textContent = data_name_prodacts_3_61[counter]
        name_prodacts_3_62.textContent = data_name_prodacts_3_62[counter]
        name_prodacts_3_63.textContent = data_name_prodacts_3_63[counter]
        name_prodacts_3_64.textContent = data_name_prodacts_3_64[counter]
        name_prodacts_3_65.textContent = data_name_prodacts_3_65[counter]
        name_prodacts_3_66.textContent = data_name_prodacts_3_66[counter]
        name_prodacts_3_67.textContent = data_name_prodacts_3_67[counter]
        name_prodacts_3_68.textContent = data_name_prodacts_3_68[counter]
        name_prodacts_3_69.textContent = data_name_prodacts_3_69[counter]
        name_prodacts_3_70.textContent = data_name_prodacts_3_70[counter]
        name_prodacts_3_71.textContent = data_name_prodacts_3_71[counter]
        name_prodacts_3_72.textContent = data_name_prodacts_3_72[counter]
        name_prodacts_3_73.textContent = data_name_prodacts_3_73[counter]
        name_prodacts_3_74.textContent = data_name_prodacts_3_74[counter]
        name_prodacts_3_75.textContent = data_name_prodacts_3_75[counter]
        name_prodacts_3_76.textContent = data_name_prodacts_3_76[counter]
        name_prodacts_3_77.textContent = data_name_prodacts_3_77[counter]
        name_prodacts_3_78.textContent = data_name_prodacts_3_78[counter]
        name_prodacts_3_79.textContent = data_name_prodacts_3_79[counter]
        name_prodacts_3_80.textContent = data_name_prodacts_3_80[counter]
        name_prodacts_3_81.textContent = data_name_prodacts_3_81[counter]
        name_prodacts_3_82.textContent = data_name_prodacts_3_82[counter]
        name_prodacts_3_83.textContent = data_name_prodacts_3_83[counter]
        name_prodacts_3_84.textContent = data_name_prodacts_3_84[counter]
        name_prodacts_3_85.textContent = data_name_prodacts_3_85[counter]
        name_prodacts_3_86.textContent = data_name_prodacts_3_86[counter]
        name_prodacts_3_87.textContent = data_name_prodacts_3_87[counter]
        name_prodacts_3_88.textContent = data_name_prodacts_3_88[counter]
        name_prodacts_3_89.textContent = data_name_prodacts_3_89[counter]
        name_prodacts_3_90.textContent = data_name_prodacts_3_90[counter]
        name_prodacts_3_91.textContent = data_name_prodacts_3_91[counter]
        name_prodacts_3_92.textContent = data_name_prodacts_3_92[counter]
        name_prodacts_3_93.textContent = data_name_prodacts_3_93[counter]
        name_prodacts_3_94.textContent = data_name_prodacts_3_94[counter]
        name_prodacts_3_95.textContent = data_name_prodacts_3_95[counter]
        name_prodacts_3_96.textContent = data_name_prodacts_3_96[counter]
        name_prodacts_3_97.textContent = data_name_prodacts_3_97[counter]
        name_prodacts_3_98.textContent = data_name_prodacts_3_98[counter]
        name_prodacts_3_99.textContent = data_name_prodacts_3_99[counter]
        name_prodacts_3_100.textContent = data_name_prodacts_3_100[counter]
        name_prodacts_3_101.textContent = data_name_prodacts_3_101[counter]
        name_prodacts_3_102.textContent = data_name_prodacts_3_102[counter]
        name_prodacts_3_103.textContent = data_name_prodacts_3_103[counter]
        name_prodacts_3_104.textContent = data_name_prodacts_3_104[counter]
        name_prodacts_3_105.textContent = data_name_prodacts_3_105[counter]
        name_prodacts_3_106.textContent = data_name_prodacts_3_106[counter]
        name_prodacts_3_107.textContent = data_name_prodacts_3_107[counter]
        name_prodacts_3_108.textContent = data_name_prodacts_3_108[counter]
        name_prodacts_3_109.textContent = data_name_prodacts_3_109[counter]
        name_prodacts_3_110.textContent = data_name_prodacts_3_110[counter]
        name_prodacts_3_111.textContent = data_name_prodacts_3_111[counter]
        name_prodacts_3_112.textContent = data_name_prodacts_3_112[counter]
        name_prodacts_3_113.textContent = data_name_prodacts_3_113[counter]
        name_prodacts_3_114.textContent = data_name_prodacts_3_114[counter]
        name_prodacts_3_115.textContent = data_name_prodacts_3_115[counter]
        name_prodacts_3_116.textContent = data_name_prodacts_3_116[counter]
        name_prodacts_3_117.textContent = data_name_prodacts_3_117[counter]
        name_prodacts_3_118.textContent = data_name_prodacts_3_118[counter]
        name_prodacts_3_119.textContent = data_name_prodacts_3_119[counter]
        name_prodacts_3_120.textContent = data_name_prodacts_3_120[counter]
        
        /*Data Name prodacts 3 */
        
        
        
        /*Data Name prodacts 4 */
        
        name_prodacts_4_1.textContent = data_name_prodacts_4_1[counter]
        name_prodacts_4_2.textContent = data_name_prodacts_4_2[counter]
        name_prodacts_4_3.textContent = data_name_prodacts_4_3[counter]
        name_prodacts_4_4.textContent = data_name_prodacts_4_4[counter]
        name_prodacts_4_5.textContent = data_name_prodacts_4_5[counter]
        name_prodacts_4_6.textContent = data_name_prodacts_4_6[counter]
        name_prodacts_4_7.textContent = data_name_prodacts_4_7[counter]
        name_prodacts_4_8.textContent = data_name_prodacts_4_8[counter]
        name_prodacts_4_9.textContent = data_name_prodacts_4_9[counter]
        name_prodacts_4_10.textContent = data_name_prodacts_4_10[counter]
        name_prodacts_4_11.textContent = data_name_prodacts_4_11[counter]
        name_prodacts_4_12.textContent = data_name_prodacts_4_12[counter]
        name_prodacts_4_13.textContent = data_name_prodacts_4_13[counter]
        name_prodacts_4_14.textContent = data_name_prodacts_4_14[counter]
        name_prodacts_4_15.textContent = data_name_prodacts_4_15[counter]
        name_prodacts_4_16.textContent = data_name_prodacts_4_16[counter]
        name_prodacts_4_17.textContent = data_name_prodacts_4_17[counter]
        name_prodacts_4_18.textContent = data_name_prodacts_4_18[counter]
        name_prodacts_4_19.textContent = data_name_prodacts_4_19[counter]
        name_prodacts_4_20.textContent = data_name_prodacts_4_20[counter]
        name_prodacts_4_21.textContent = data_name_prodacts_4_21[counter]
        name_prodacts_4_22.textContent = data_name_prodacts_4_22[counter]
        name_prodacts_4_23.textContent = data_name_prodacts_4_23[counter]
        name_prodacts_4_24.textContent = data_name_prodacts_4_24[counter]
        name_prodacts_4_25.textContent = data_name_prodacts_4_25[counter]
        name_prodacts_4_26.textContent = data_name_prodacts_4_26[counter]
        name_prodacts_4_27.textContent = data_name_prodacts_4_27[counter]
        name_prodacts_4_28.textContent = data_name_prodacts_4_28[counter]
        name_prodacts_4_29.textContent = data_name_prodacts_4_29[counter]
        name_prodacts_4_30.textContent = data_name_prodacts_4_30[counter]
        name_prodacts_4_31.textContent = data_name_prodacts_4_31[counter]
        name_prodacts_4_32.textContent = data_name_prodacts_4_32[counter]
        name_prodacts_4_33.textContent = data_name_prodacts_4_33[counter]
        name_prodacts_4_34.textContent = data_name_prodacts_4_34[counter]
        name_prodacts_4_35.textContent = data_name_prodacts_4_35[counter]
        name_prodacts_4_36.textContent = data_name_prodacts_4_36[counter]
        name_prodacts_4_37.textContent = data_name_prodacts_4_37[counter]
        name_prodacts_4_38.textContent = data_name_prodacts_4_38[counter]
        name_prodacts_4_39.textContent = data_name_prodacts_4_39[counter]
        name_prodacts_4_40.textContent = data_name_prodacts_4_40[counter]
        name_prodacts_4_41.textContent = data_name_prodacts_4_41[counter]
        name_prodacts_4_42.textContent = data_name_prodacts_4_42[counter]
        name_prodacts_4_43.textContent = data_name_prodacts_4_43[counter]
        name_prodacts_4_44.textContent = data_name_prodacts_4_44[counter]
        name_prodacts_4_45.textContent = data_name_prodacts_4_45[counter]
        name_prodacts_4_46.textContent = data_name_prodacts_4_46[counter]
        name_prodacts_4_47.textContent = data_name_prodacts_4_47[counter]
        name_prodacts_4_48.textContent = data_name_prodacts_4_48[counter]
        name_prodacts_4_49.textContent = data_name_prodacts_4_49[counter]
        name_prodacts_4_50.textContent = data_name_prodacts_4_50[counter]
        name_prodacts_4_51.textContent = data_name_prodacts_4_51[counter]
        name_prodacts_4_52.textContent = data_name_prodacts_4_52[counter]
        name_prodacts_4_53.textContent = data_name_prodacts_4_53[counter]
        name_prodacts_4_54.textContent = data_name_prodacts_4_54[counter]
        name_prodacts_4_55.textContent = data_name_prodacts_4_55[counter]
        name_prodacts_4_56.textContent = data_name_prodacts_4_56[counter]
        name_prodacts_4_57.textContent = data_name_prodacts_4_57[counter]
        name_prodacts_4_58.textContent = data_name_prodacts_4_58[counter]
        name_prodacts_4_59.textContent = data_name_prodacts_4_59[counter]
        name_prodacts_4_60.textContent = data_name_prodacts_4_60[counter]
        name_prodacts_4_61.textContent = data_name_prodacts_4_61[counter]
        name_prodacts_4_62.textContent = data_name_prodacts_4_62[counter]
        name_prodacts_4_63.textContent = data_name_prodacts_4_63[counter]
        name_prodacts_4_64.textContent = data_name_prodacts_4_64[counter]
        name_prodacts_4_65.textContent = data_name_prodacts_4_65[counter]
        name_prodacts_4_66.textContent = data_name_prodacts_4_66[counter]
        name_prodacts_4_67.textContent = data_name_prodacts_4_67[counter]
        name_prodacts_4_68.textContent = data_name_prodacts_4_68[counter]
        name_prodacts_4_69.textContent = data_name_prodacts_4_69[counter]
        name_prodacts_4_70.textContent = data_name_prodacts_4_70[counter]
        name_prodacts_4_71.textContent = data_name_prodacts_4_71[counter]
        name_prodacts_4_72.textContent = data_name_prodacts_4_72[counter]
        name_prodacts_4_73.textContent = data_name_prodacts_4_73[counter]
        name_prodacts_4_74.textContent = data_name_prodacts_4_74[counter]
        name_prodacts_4_75.textContent = data_name_prodacts_4_75[counter]
        name_prodacts_4_76.textContent = data_name_prodacts_4_76[counter]
        name_prodacts_4_77.textContent = data_name_prodacts_4_77[counter]
        name_prodacts_4_78.textContent = data_name_prodacts_4_78[counter]
        name_prodacts_4_79.textContent = data_name_prodacts_4_79[counter]
        name_prodacts_4_80.textContent = data_name_prodacts_4_80[counter]
        name_prodacts_4_81.textContent = data_name_prodacts_4_81[counter]
        name_prodacts_4_82.textContent = data_name_prodacts_4_82[counter]
        name_prodacts_4_83.textContent = data_name_prodacts_4_83[counter]
        name_prodacts_4_84.textContent = data_name_prodacts_4_84[counter]
        name_prodacts_4_85.textContent = data_name_prodacts_4_85[counter]
        name_prodacts_4_86.textContent = data_name_prodacts_4_86[counter]
        name_prodacts_4_87.textContent = data_name_prodacts_4_87[counter]
        name_prodacts_4_88.textContent = data_name_prodacts_4_88[counter]
        name_prodacts_4_89.textContent = data_name_prodacts_4_89[counter]
        name_prodacts_4_90.textContent = data_name_prodacts_4_90[counter]
        name_prodacts_4_91.textContent = data_name_prodacts_4_91[counter]
        name_prodacts_4_92.textContent = data_name_prodacts_4_92[counter]
        name_prodacts_4_93.textContent = data_name_prodacts_4_93[counter]
        name_prodacts_4_94.textContent = data_name_prodacts_4_94[counter]
        name_prodacts_4_95.textContent = data_name_prodacts_4_95[counter]
        name_prodacts_4_96.textContent = data_name_prodacts_4_96[counter]
        name_prodacts_4_97.textContent = data_name_prodacts_4_97[counter]
        name_prodacts_4_98.textContent = data_name_prodacts_4_98[counter]
        name_prodacts_4_99.textContent = data_name_prodacts_4_99[counter]
        name_prodacts_4_100.textContent = data_name_prodacts_4_100[counter]
        name_prodacts_4_101.textContent = data_name_prodacts_4_101[counter]
        name_prodacts_4_102.textContent = data_name_prodacts_4_102[counter]
        name_prodacts_4_103.textContent = data_name_prodacts_4_103[counter]
        name_prodacts_4_104.textContent = data_name_prodacts_4_104[counter]
        name_prodacts_4_105.textContent = data_name_prodacts_4_105[counter]
        name_prodacts_4_106.textContent = data_name_prodacts_4_106[counter]
        name_prodacts_4_107.textContent = data_name_prodacts_4_107[counter]
        name_prodacts_4_108.textContent = data_name_prodacts_4_108[counter]
        name_prodacts_4_109.textContent = data_name_prodacts_4_109[counter]
        name_prodacts_4_110.textContent = data_name_prodacts_4_110[counter]
        name_prodacts_4_111.textContent = data_name_prodacts_4_111[counter]
        name_prodacts_4_112.textContent = data_name_prodacts_4_112[counter]
        name_prodacts_4_113.textContent = data_name_prodacts_4_113[counter]
        name_prodacts_4_114.textContent = data_name_prodacts_4_114[counter]
        name_prodacts_4_115.textContent = data_name_prodacts_4_115[counter]
        name_prodacts_4_116.textContent = data_name_prodacts_4_116[counter]
        name_prodacts_4_117.textContent = data_name_prodacts_4_117[counter]
        name_prodacts_4_118.textContent = data_name_prodacts_4_118[counter]
        name_prodacts_4_119.textContent = data_name_prodacts_4_119[counter]
        name_prodacts_4_120.textContent = data_name_prodacts_4_120[counter]
        
        /*Data Name prodacts 4 */
        
        
        box_counter.value =  input_number_1[counter];
    }, 1000);
    
    
    
    };

/*End arrwo_right_big*/


/*Start arrwo_left_big*/




arrwo_left_big.onclick = function () {
    
    all_element_img_ga.classList.add("toggle-all-element-img-ga");
    all_element_img_ga_2.classList.add("toggle-all-element-img-ga");
    all_element_img_ga_3.classList.add("toggle-all-element-img-ga");
    all_element_img_ga_4.classList.add("toggle-all-element-img-ga");
    
    setTimeout(function () {
        
        all_element_img_ga.classList.remove("toggle-all-element-img-ga");
        all_element_img_ga_2.classList.remove("toggle-all-element-img-ga");
        all_element_img_ga_3.classList.remove("toggle-all-element-img-ga");
        all_element_img_ga_4.classList.remove("toggle-all-element-img-ga");
        
    }, 1350);
    setTimeout(function () {
        
    if (counter == 0) {
        
		return;
        
	}
    
        counter -= 1;
        /*Start back Gallery 1*/
        img_ga_1.src = name_img_1[counter];
        text_ga_1.textContent =  text_1[counter];
        gallery_1.textContent =  name_gallery_1[counter];
        /*End back Gallery 1*/
        
        
        /*Start back Gallery 2*/
        img_ga_2.src = name_img_2[counter];
        text_ga_2.textContent =  text_2[counter];
        gallery_2.textContent =  name_gallery_2[counter];
        /*End back Gallery 2*/
        
        /*Start Gallery 3*/
        img_ga_3.src = name_img_3[counter];
        text_ga_3.textContent =  text_3[counter];
        gallery_3.textContent =  name_gallery_3[counter];
        /*End Gallery 3*/
        
        /*Start Gallery 4*/
        img_ga_4.src = name_img_4[counter];
        text_ga_4.textContent =  text_4[counter];
        gallery_4.textContent =  name_gallery_4[counter];
        /*End Gallery 4*/
        box_counter.value =  input_number_1[counter];
        
        
        /*Start img_section_prodacts_gallery_1*/
        
        icone_section_prodacts_1.src = name_img_1[counter];
        img_section_prodacts_gallery_1_1.src = name_img_section_prodacts_gallery_1_1[counter]
        img_section_prodacts_gallery_1_2.src = name_img_section_prodacts_gallery_1_2[counter]
        img_section_prodacts_gallery_1_3.src = name_img_section_prodacts_gallery_1_3[counter]
        img_section_prodacts_gallery_1_4.src = name_img_section_prodacts_gallery_1_4[counter]
        img_section_prodacts_gallery_1_5.src = name_img_section_prodacts_gallery_1_5[counter]
        img_section_prodacts_gallery_1_6.src = name_img_section_prodacts_gallery_1_6[counter]
        img_section_prodacts_gallery_1_7.src = name_img_section_prodacts_gallery_1_7[counter]
        img_section_prodacts_gallery_1_8.src = name_img_section_prodacts_gallery_1_8[counter]
        img_section_prodacts_gallery_1_9.src = name_img_section_prodacts_gallery_1_9[counter]
        img_section_prodacts_gallery_1_10.src = name_img_section_prodacts_gallery_1_10[counter]
        img_section_prodacts_gallery_1_11.src = name_img_section_prodacts_gallery_1_11[counter]
        img_section_prodacts_gallery_1_12.src = name_img_section_prodacts_gallery_1_12[counter]
        
        
        /*Name 1*/ 
        name_section_prodacts_1_1.textContent = data_name_1_1[counter];
        name_section_prodacts_1_2.textContent = data_name_1_2[counter];
        name_section_prodacts_1_3.textContent = data_name_1_3[counter];
        name_section_prodacts_1_4.textContent = data_name_1_4[counter];
        name_section_prodacts_1_5.textContent = data_name_1_5[counter];
        name_section_prodacts_1_6.textContent = data_name_1_6[counter];
        name_section_prodacts_1_7.textContent = data_name_1_7[counter];
        name_section_prodacts_1_8.textContent = data_name_1_8[counter];
        name_section_prodacts_1_9.textContent = data_name_1_9[counter];
        name_section_prodacts_1_10.textContent = data_name_1_10[counter];
        name_section_prodacts_1_11.textContent = data_name_1_11[counter];
        name_section_prodacts_1_12.textContent = data_name_1_12[counter];
        
        
        /*intro 1*/
        intro_section_prodacts_1_1.textContent = data_intro_1_1[counter];
        intro_section_prodacts_1_2.textContent = data_intro_1_2[counter];
        intro_section_prodacts_1_3.textContent = data_intro_1_3[counter];
        intro_section_prodacts_1_4.textContent = data_intro_1_4[counter];
        intro_section_prodacts_1_5.textContent = data_intro_1_5[counter];
        intro_section_prodacts_1_6.textContent = data_intro_1_6[counter];
        intro_section_prodacts_1_7.textContent = data_intro_1_7[counter];
        intro_section_prodacts_1_8.textContent = data_intro_1_8[counter];
        intro_section_prodacts_1_9.textContent = data_intro_1_9[counter];
        intro_section_prodacts_1_10.textContent = data_intro_1_10[counter];
        intro_section_prodacts_1_11.textContent = data_intro_1_11[counter];
        intro_section_prodacts_1_12.textContent = data_intro_1_12[counter];
        /*End img_section_prodacts_gallery_1*/
        
        
        /*Start img_section_prodacts_gallery_2*/
        
        icone_section_prodacts_2.src = name_img_2[counter];
        img_section_prodacts_gallery_1_1.src = name_img_section_prodacts_gallery_1_1[counter]
        img_section_prodacts_gallery_1_2.src = name_img_section_prodacts_gallery_1_2[counter]
        img_section_prodacts_gallery_1_3.src = name_img_section_prodacts_gallery_1_3[counter]
        img_section_prodacts_gallery_1_4.src = name_img_section_prodacts_gallery_1_4[counter]
        img_section_prodacts_gallery_1_5.src = name_img_section_prodacts_gallery_1_5[counter]
        img_section_prodacts_gallery_1_6.src = name_img_section_prodacts_gallery_1_6[counter]
        img_section_prodacts_gallery_1_7.src = name_img_section_prodacts_gallery_1_7[counter]
        img_section_prodacts_gallery_1_8.src = name_img_section_prodacts_gallery_1_8[counter]
        img_section_prodacts_gallery_1_9.src = name_img_section_prodacts_gallery_1_9[counter]
        img_section_prodacts_gallery_1_10.src = name_img_section_prodacts_gallery_1_10[counter]
        img_section_prodacts_gallery_1_11.src = name_img_section_prodacts_gallery_1_11[counter]
        img_section_prodacts_gallery_1_12.src = name_img_section_prodacts_gallery_1_12[counter]
        
        /*Name 2*/ 
        name_section_prodacts_2_1.textContent = data_name_2_1[counter];
        name_section_prodacts_2_2.textContent = data_name_2_2[counter];
        name_section_prodacts_2_3.textContent = data_name_2_3[counter];
        name_section_prodacts_2_4.textContent = data_name_2_4[counter];
        name_section_prodacts_2_5.textContent = data_name_2_5[counter];
        name_section_prodacts_2_6.textContent = data_name_2_6[counter];
        name_section_prodacts_2_7.textContent = data_name_2_7[counter];
        name_section_prodacts_2_8.textContent = data_name_2_8[counter];
        name_section_prodacts_2_9.textContent = data_name_2_9[counter];
        name_section_prodacts_2_10.textContent = data_name_2_10[counter];
        name_section_prodacts_2_11.textContent = data_name_2_11[counter];
        name_section_prodacts_2_12.textContent = data_name_2_12[counter];
        
        /*intro 2*/
        intro_section_prodacts_2_1.textContent = data_intro_2_1[counter];
        intro_section_prodacts_2_2.textContent = data_intro_2_2[counter];
        intro_section_prodacts_2_3.textContent = data_intro_2_3[counter];
        intro_section_prodacts_2_4.textContent = data_intro_2_4[counter];
        intro_section_prodacts_2_5.textContent = data_intro_2_5[counter];
        intro_section_prodacts_2_6.textContent = data_intro_2_6[counter];
        intro_section_prodacts_2_7.textContent = data_intro_2_7[counter];
        intro_section_prodacts_2_8.textContent = data_intro_2_8[counter];
        intro_section_prodacts_2_9.textContent = data_intro_2_9[counter];
        intro_section_prodacts_2_10.textContent = data_intro_2_10[counter];
        intro_section_prodacts_2_11.textContent = data_intro_2_11[counter];
        intro_section_prodacts_2_12.textContent = data_intro_2_12[counter];
        
        /*End img_section_prodacts_gallery_2*/
        
        
        /*Start img_section_prodacts_gallery_3*/
        
        
        icone_section_prodacts_3.src = name_img_3[counter];
        img_section_prodacts_gallery_3_1.src = name_img_section_prodacts_gallery_3_1[counter]
        img_section_prodacts_gallery_3_2.src = name_img_section_prodacts_gallery_3_2[counter]
        img_section_prodacts_gallery_3_3.src = name_img_section_prodacts_gallery_3_3[counter]
        img_section_prodacts_gallery_3_4.src = name_img_section_prodacts_gallery_3_4[counter]
        img_section_prodacts_gallery_3_5.src = name_img_section_prodacts_gallery_3_5[counter]
        img_section_prodacts_gallery_3_6.src = name_img_section_prodacts_gallery_3_6[counter]
        img_section_prodacts_gallery_3_7.src = name_img_section_prodacts_gallery_3_7[counter]
        img_section_prodacts_gallery_3_8.src = name_img_section_prodacts_gallery_3_8[counter]
        img_section_prodacts_gallery_3_9.src = name_img_section_prodacts_gallery_3_9[counter]
        img_section_prodacts_gallery_3_10.src = name_img_section_prodacts_gallery_3_10[counter]
        img_section_prodacts_gallery_3_11.src = name_img_section_prodacts_gallery_3_11[counter]
        img_section_prodacts_gallery_3_12.src = name_img_section_prodacts_gallery_3_12[counter]
        
        
        /*Name 3*/ 
        name_section_prodacts_3_1.textContent = data_name_3_1[counter];
        name_section_prodacts_3_2.textContent = data_name_3_2[counter];
        name_section_prodacts_3_3.textContent = data_name_3_3[counter];
        name_section_prodacts_3_4.textContent = data_name_3_4[counter];
        name_section_prodacts_3_5.textContent = data_name_3_5[counter];
        name_section_prodacts_3_6.textContent = data_name_3_6[counter];
        name_section_prodacts_3_7.textContent = data_name_3_7[counter];
        name_section_prodacts_3_8.textContent = data_name_3_8[counter];
        name_section_prodacts_3_9.textContent = data_name_3_9[counter];
        name_section_prodacts_3_10.textContent = data_name_3_10[counter];
        name_section_prodacts_3_11.textContent = data_name_3_11[counter];
        name_section_prodacts_3_12.textContent = data_name_3_12[counter];
        
        /*intro 3*/
        intro_section_prodacts_3_1.textContent = data_intro_3_1[counter];
        intro_section_prodacts_3_2.textContent = data_intro_3_2[counter];
        intro_section_prodacts_3_3.textContent = data_intro_3_3[counter];
        intro_section_prodacts_3_4.textContent = data_intro_3_4[counter];
        intro_section_prodacts_3_5.textContent = data_intro_3_5[counter];
        intro_section_prodacts_3_6.textContent = data_intro_3_6[counter];
        intro_section_prodacts_3_7.textContent = data_intro_3_7[counter];
        intro_section_prodacts_3_8.textContent = data_intro_3_8[counter];
        intro_section_prodacts_3_9.textContent = data_intro_3_9[counter];
        intro_section_prodacts_3_10.textContent = data_intro_3_10[counter];
        intro_section_prodacts_3_11.textContent = data_intro_3_11[counter];
        intro_section_prodacts_3_12.textContent = data_intro_3_12[counter];
        
        
        /*End img_section_prodacts_gallery_3*/
        
        /*Start img_section_prodacts_gallery_4*/
        
        
        icone_section_prodacts_4.src = name_img_4[counter];
        img_section_prodacts_gallery_4_1.src = name_img_section_prodacts_gallery_4_1[counter]
        img_section_prodacts_gallery_4_2.src = name_img_section_prodacts_gallery_4_2[counter]
        img_section_prodacts_gallery_4_3.src = name_img_section_prodacts_gallery_4_3[counter]
        img_section_prodacts_gallery_4_4.src = name_img_section_prodacts_gallery_4_4[counter]
        img_section_prodacts_gallery_4_5.src = name_img_section_prodacts_gallery_4_5[counter]
        img_section_prodacts_gallery_4_6.src = name_img_section_prodacts_gallery_4_6[counter]
        img_section_prodacts_gallery_4_7.src = name_img_section_prodacts_gallery_4_7[counter]
        img_section_prodacts_gallery_4_8.src = name_img_section_prodacts_gallery_4_8[counter]
        img_section_prodacts_gallery_4_9.src = name_img_section_prodacts_gallery_4_9[counter]
        img_section_prodacts_gallery_4_10.src = name_img_section_prodacts_gallery_4_10[counter]
        img_section_prodacts_gallery_4_11.src = name_img_section_prodacts_gallery_4_11[counter]
        img_section_prodacts_gallery_4_12.src = name_img_section_prodacts_gallery_4_12[counter]
        
        
        /*Name 4*/ 
        name_section_prodacts_4_1.textContent = data_name_4_1[counter];
        name_section_prodacts_4_2.textContent = data_name_4_2[counter];
        name_section_prodacts_4_3.textContent = data_name_4_3[counter];
        name_section_prodacts_4_4.textContent = data_name_4_4[counter];
        name_section_prodacts_4_5.textContent = data_name_4_5[counter];
        name_section_prodacts_4_6.textContent = data_name_4_6[counter];
        name_section_prodacts_4_7.textContent = data_name_4_7[counter];
        name_section_prodacts_4_8.textContent = data_name_4_8[counter];
        name_section_prodacts_4_9.textContent = data_name_4_9[counter];
        name_section_prodacts_4_10.textContent = data_name_4_10[counter];
        name_section_prodacts_4_11.textContent = data_name_4_11[counter];
        name_section_prodacts_4_12.textContent = data_name_4_12[counter];
        
        
        
        /*intro 4*/
        intro_section_prodacts_4_1.textContent = data_intro_4_1[counter];
        intro_section_prodacts_4_2.textContent = data_intro_4_2[counter];
        intro_section_prodacts_4_3.textContent = data_intro_4_3[counter];
        intro_section_prodacts_4_4.textContent = data_intro_4_4[counter];
        intro_section_prodacts_4_5.textContent = data_intro_4_5[counter];
        intro_section_prodacts_4_6.textContent = data_intro_4_6[counter];
        intro_section_prodacts_4_7.textContent = data_intro_4_7[counter];
        intro_section_prodacts_4_8.textContent = data_intro_4_8[counter];
        intro_section_prodacts_4_9.textContent = data_intro_4_9[counter];
        intro_section_prodacts_4_10.textContent = data_intro_4_10[counter];
        intro_section_prodacts_4_11.textContent = data_intro_4_11[counter];
        intro_section_prodacts_4_12.textContent = data_intro_4_12[counter];
        
        /*End img_section_prodacts_gallery_4*/
        
        
        /*Data Name prodacts 1 */
        name_prodacts_1_1.textContent = data_name_prodacts_1_1[counter]
        name_prodacts_1_2.textContent = data_name_prodacts_1_2[counter]
        name_prodacts_1_3.textContent = data_name_prodacts_1_3[counter]
        name_prodacts_1_4.textContent = data_name_prodacts_1_4[counter]
        name_prodacts_1_5.textContent = data_name_prodacts_1_5[counter]
        name_prodacts_1_6.textContent = data_name_prodacts_1_6[counter]
        name_prodacts_1_7.textContent = data_name_prodacts_1_7[counter]
        name_prodacts_1_8.textContent = data_name_prodacts_1_8[counter]
        name_prodacts_1_9.textContent = data_name_prodacts_1_9[counter]
        name_prodacts_1_10.textContent = data_name_prodacts_1_10[counter]
        name_prodacts_1_11.textContent = data_name_prodacts_1_11[counter]
        name_prodacts_1_12.textContent = data_name_prodacts_1_12[counter]
        name_prodacts_1_13.textContent = data_name_prodacts_1_13[counter]
        name_prodacts_1_14.textContent = data_name_prodacts_1_14[counter]
        name_prodacts_1_15.textContent = data_name_prodacts_1_15[counter]
        name_prodacts_1_16.textContent = data_name_prodacts_1_16[counter]
        name_prodacts_1_17.textContent = data_name_prodacts_1_17[counter]
        name_prodacts_1_18.textContent = data_name_prodacts_1_18[counter]
        name_prodacts_1_19.textContent = data_name_prodacts_1_19[counter]
        name_prodacts_1_20.textContent = data_name_prodacts_1_20[counter]
        name_prodacts_1_21.textContent = data_name_prodacts_1_21[counter]
        name_prodacts_1_22.textContent = data_name_prodacts_1_22[counter]
        name_prodacts_1_23.textContent = data_name_prodacts_1_23[counter]
        name_prodacts_1_24.textContent = data_name_prodacts_1_24[counter]
        name_prodacts_1_25.textContent = data_name_prodacts_1_25[counter]
        name_prodacts_1_26.textContent = data_name_prodacts_1_26[counter]
        name_prodacts_1_27.textContent = data_name_prodacts_1_27[counter]
        name_prodacts_1_28.textContent = data_name_prodacts_1_28[counter]
        name_prodacts_1_29.textContent = data_name_prodacts_1_29[counter]
        name_prodacts_1_30.textContent = data_name_prodacts_1_30[counter]
        name_prodacts_1_31.textContent = data_name_prodacts_1_31[counter]
        name_prodacts_1_32.textContent = data_name_prodacts_1_32[counter]
        name_prodacts_1_33.textContent = data_name_prodacts_1_33[counter]
        name_prodacts_1_34.textContent = data_name_prodacts_1_34[counter]
        name_prodacts_1_35.textContent = data_name_prodacts_1_35[counter]
        name_prodacts_1_36.textContent = data_name_prodacts_1_36[counter]
        name_prodacts_1_37.textContent = data_name_prodacts_1_37[counter]
        name_prodacts_1_38.textContent = data_name_prodacts_1_38[counter]
        name_prodacts_1_39.textContent = data_name_prodacts_1_39[counter]
        name_prodacts_1_40.textContent = data_name_prodacts_1_40[counter]
        name_prodacts_1_41.textContent = data_name_prodacts_1_41[counter]
        name_prodacts_1_42.textContent = data_name_prodacts_1_42[counter]
        name_prodacts_1_43.textContent = data_name_prodacts_1_43[counter]
        name_prodacts_1_44.textContent = data_name_prodacts_1_44[counter]
        name_prodacts_1_45.textContent = data_name_prodacts_1_45[counter]
        name_prodacts_1_46.textContent = data_name_prodacts_1_46[counter]
        name_prodacts_1_47.textContent = data_name_prodacts_1_47[counter]
        name_prodacts_1_48.textContent = data_name_prodacts_1_48[counter]
        name_prodacts_1_49.textContent = data_name_prodacts_1_49[counter]
        name_prodacts_1_50.textContent = data_name_prodacts_1_50[counter]
        name_prodacts_1_51.textContent = data_name_prodacts_1_51[counter]
        name_prodacts_1_52.textContent = data_name_prodacts_1_52[counter]
        name_prodacts_1_53.textContent = data_name_prodacts_1_53[counter]
        name_prodacts_1_54.textContent = data_name_prodacts_1_54[counter]
        name_prodacts_1_55.textContent = data_name_prodacts_1_55[counter]
        name_prodacts_1_56.textContent = data_name_prodacts_1_56[counter]
        name_prodacts_1_57.textContent = data_name_prodacts_1_57[counter]
        name_prodacts_1_58.textContent = data_name_prodacts_1_58[counter]
        name_prodacts_1_59.textContent = data_name_prodacts_1_59[counter]
        name_prodacts_1_60.textContent = data_name_prodacts_1_60[counter]
        name_prodacts_1_61.textContent = data_name_prodacts_1_61[counter]
        name_prodacts_1_62.textContent = data_name_prodacts_1_62[counter]
        name_prodacts_1_63.textContent = data_name_prodacts_1_63[counter]
        name_prodacts_1_64.textContent = data_name_prodacts_1_64[counter]
        name_prodacts_1_65.textContent = data_name_prodacts_1_65[counter]
        name_prodacts_1_66.textContent = data_name_prodacts_1_66[counter]
        name_prodacts_1_67.textContent = data_name_prodacts_1_67[counter]
        name_prodacts_1_68.textContent = data_name_prodacts_1_68[counter]
        name_prodacts_1_69.textContent = data_name_prodacts_1_69[counter]
        name_prodacts_1_70.textContent = data_name_prodacts_1_70[counter]
        name_prodacts_1_71.textContent = data_name_prodacts_1_71[counter]
        name_prodacts_1_72.textContent = data_name_prodacts_1_72[counter]
        name_prodacts_1_73.textContent = data_name_prodacts_1_73[counter]
        name_prodacts_1_74.textContent = data_name_prodacts_1_74[counter]
        name_prodacts_1_75.textContent = data_name_prodacts_1_75[counter]
        name_prodacts_1_76.textContent = data_name_prodacts_1_76[counter]
        name_prodacts_1_77.textContent = data_name_prodacts_1_77[counter]
        name_prodacts_1_78.textContent = data_name_prodacts_1_78[counter]
        name_prodacts_1_79.textContent = data_name_prodacts_1_79[counter]
        name_prodacts_1_80.textContent = data_name_prodacts_1_80[counter]
        name_prodacts_1_81.textContent = data_name_prodacts_1_81[counter]
        name_prodacts_1_82.textContent = data_name_prodacts_1_82[counter]
        name_prodacts_1_83.textContent = data_name_prodacts_1_83[counter]
        name_prodacts_1_84.textContent = data_name_prodacts_1_84[counter]
        name_prodacts_1_85.textContent = data_name_prodacts_1_85[counter]
        name_prodacts_1_86.textContent = data_name_prodacts_1_86[counter]
        name_prodacts_1_87.textContent = data_name_prodacts_1_87[counter]
        name_prodacts_1_88.textContent = data_name_prodacts_1_88[counter]
        name_prodacts_1_89.textContent = data_name_prodacts_1_89[counter]
        name_prodacts_1_90.textContent = data_name_prodacts_1_90[counter]
        name_prodacts_1_91.textContent = data_name_prodacts_1_91[counter]
        name_prodacts_1_92.textContent = data_name_prodacts_1_92[counter]
        name_prodacts_1_93.textContent = data_name_prodacts_1_93[counter]
        name_prodacts_1_94.textContent = data_name_prodacts_1_94[counter]
        name_prodacts_1_95.textContent = data_name_prodacts_1_95[counter]
        name_prodacts_1_96.textContent = data_name_prodacts_1_96[counter]
        name_prodacts_1_97.textContent = data_name_prodacts_1_97[counter]
        name_prodacts_1_98.textContent = data_name_prodacts_1_98[counter]
        name_prodacts_1_99.textContent = data_name_prodacts_1_99[counter]
        name_prodacts_1_100.textContent = data_name_prodacts_1_100[counter]
        name_prodacts_1_101.textContent = data_name_prodacts_1_101[counter]
        name_prodacts_1_102.textContent = data_name_prodacts_1_102[counter]
        name_prodacts_1_103.textContent = data_name_prodacts_1_103[counter]
        name_prodacts_1_104.textContent = data_name_prodacts_1_104[counter]
        name_prodacts_1_105.textContent = data_name_prodacts_1_105[counter]
        name_prodacts_1_106.textContent = data_name_prodacts_1_106[counter]
        name_prodacts_1_107.textContent = data_name_prodacts_1_107[counter]
        name_prodacts_1_108.textContent = data_name_prodacts_1_108[counter]
        name_prodacts_1_109.textContent = data_name_prodacts_1_109[counter]
        name_prodacts_1_110.textContent = data_name_prodacts_1_110[counter]
        name_prodacts_1_111.textContent = data_name_prodacts_1_111[counter]
        name_prodacts_1_112.textContent = data_name_prodacts_1_112[counter]
        name_prodacts_1_113.textContent = data_name_prodacts_1_113[counter]
        name_prodacts_1_114.textContent = data_name_prodacts_1_114[counter]
        name_prodacts_1_115.textContent = data_name_prodacts_1_115[counter]
        name_prodacts_1_116.textContent = data_name_prodacts_1_116[counter]
        name_prodacts_1_117.textContent = data_name_prodacts_1_117[counter]
        name_prodacts_1_118.textContent = data_name_prodacts_1_118[counter]
        name_prodacts_1_119.textContent = data_name_prodacts_1_119[counter]
        name_prodacts_1_120.textContent = data_name_prodacts_1_120[counter]
        /*Data Name prodacts 1 */
        
        
        
        /*Data Name prodacts 2 */
        
        
        name_prodacts_2_1.textContent = data_name_prodacts_2_1[counter]
        name_prodacts_2_2.textContent = data_name_prodacts_2_2[counter]
        name_prodacts_2_3.textContent = data_name_prodacts_2_3[counter]
        name_prodacts_2_4.textContent = data_name_prodacts_2_4[counter]
        name_prodacts_2_5.textContent = data_name_prodacts_2_5[counter]
        name_prodacts_2_6.textContent = data_name_prodacts_2_6[counter]
        name_prodacts_2_7.textContent = data_name_prodacts_2_7[counter]
        name_prodacts_2_8.textContent = data_name_prodacts_2_8[counter]
        name_prodacts_2_9.textContent = data_name_prodacts_2_9[counter]
        name_prodacts_2_10.textContent = data_name_prodacts_2_10[counter]
        name_prodacts_2_11.textContent = data_name_prodacts_2_11[counter]
        name_prodacts_2_12.textContent = data_name_prodacts_2_12[counter]
        name_prodacts_2_13.textContent = data_name_prodacts_2_13[counter]
        name_prodacts_2_14.textContent = data_name_prodacts_2_14[counter]
        name_prodacts_2_15.textContent = data_name_prodacts_2_15[counter]
        name_prodacts_2_16.textContent = data_name_prodacts_2_16[counter]
        name_prodacts_2_17.textContent = data_name_prodacts_2_17[counter]
        name_prodacts_2_18.textContent = data_name_prodacts_2_18[counter]
        name_prodacts_2_19.textContent = data_name_prodacts_2_19[counter]
        name_prodacts_2_20.textContent = data_name_prodacts_2_20[counter]
        name_prodacts_2_21.textContent = data_name_prodacts_2_21[counter]
        name_prodacts_2_22.textContent = data_name_prodacts_2_22[counter]
        name_prodacts_2_23.textContent = data_name_prodacts_2_23[counter]
        name_prodacts_2_24.textContent = data_name_prodacts_2_24[counter]
        name_prodacts_2_25.textContent = data_name_prodacts_2_25[counter]
        name_prodacts_2_26.textContent = data_name_prodacts_2_26[counter]
        name_prodacts_2_27.textContent = data_name_prodacts_2_27[counter]
        name_prodacts_2_28.textContent = data_name_prodacts_2_28[counter]
        name_prodacts_2_29.textContent = data_name_prodacts_2_29[counter]
        name_prodacts_2_30.textContent = data_name_prodacts_2_30[counter]
        name_prodacts_2_31.textContent = data_name_prodacts_2_31[counter]
        name_prodacts_2_32.textContent = data_name_prodacts_2_32[counter]
        name_prodacts_2_33.textContent = data_name_prodacts_2_33[counter]
        name_prodacts_2_34.textContent = data_name_prodacts_2_34[counter]
        name_prodacts_2_35.textContent = data_name_prodacts_2_35[counter]
        name_prodacts_2_36.textContent = data_name_prodacts_2_36[counter]
        name_prodacts_2_37.textContent = data_name_prodacts_2_37[counter]
        name_prodacts_2_38.textContent = data_name_prodacts_2_38[counter]
        name_prodacts_2_39.textContent = data_name_prodacts_2_39[counter]
        name_prodacts_2_40.textContent = data_name_prodacts_2_40[counter]
        name_prodacts_2_41.textContent = data_name_prodacts_2_41[counter]
        name_prodacts_2_42.textContent = data_name_prodacts_2_42[counter]
        name_prodacts_2_43.textContent = data_name_prodacts_2_43[counter]
        name_prodacts_2_44.textContent = data_name_prodacts_2_44[counter]
        name_prodacts_2_45.textContent = data_name_prodacts_2_45[counter]
        name_prodacts_2_46.textContent = data_name_prodacts_2_46[counter]
        name_prodacts_2_47.textContent = data_name_prodacts_2_47[counter]
        name_prodacts_2_48.textContent = data_name_prodacts_2_48[counter]
        name_prodacts_2_49.textContent = data_name_prodacts_2_49[counter]
        name_prodacts_2_50.textContent = data_name_prodacts_2_50[counter]
        name_prodacts_2_51.textContent = data_name_prodacts_2_51[counter]
        name_prodacts_2_52.textContent = data_name_prodacts_2_52[counter]
        name_prodacts_2_53.textContent = data_name_prodacts_2_53[counter]
        name_prodacts_2_54.textContent = data_name_prodacts_2_54[counter]
        name_prodacts_2_55.textContent = data_name_prodacts_2_55[counter]
        name_prodacts_2_56.textContent = data_name_prodacts_2_56[counter]
        name_prodacts_2_57.textContent = data_name_prodacts_2_57[counter]
        name_prodacts_2_58.textContent = data_name_prodacts_2_58[counter]
        name_prodacts_2_59.textContent = data_name_prodacts_2_59[counter]
        name_prodacts_2_60.textContent = data_name_prodacts_2_60[counter]
        name_prodacts_2_61.textContent = data_name_prodacts_2_61[counter]
        name_prodacts_2_62.textContent = data_name_prodacts_2_62[counter]
        name_prodacts_2_63.textContent = data_name_prodacts_2_63[counter]
        name_prodacts_2_64.textContent = data_name_prodacts_2_64[counter]
        name_prodacts_2_65.textContent = data_name_prodacts_2_65[counter]
        name_prodacts_2_66.textContent = data_name_prodacts_2_66[counter]
        name_prodacts_2_67.textContent = data_name_prodacts_2_67[counter]
        name_prodacts_2_68.textContent = data_name_prodacts_2_68[counter]
        name_prodacts_2_69.textContent = data_name_prodacts_2_69[counter]
        name_prodacts_2_70.textContent = data_name_prodacts_2_70[counter]
        name_prodacts_2_71.textContent = data_name_prodacts_2_71[counter]
        name_prodacts_2_72.textContent = data_name_prodacts_2_72[counter]
        name_prodacts_2_73.textContent = data_name_prodacts_2_73[counter]
        name_prodacts_2_74.textContent = data_name_prodacts_2_74[counter]
        name_prodacts_2_75.textContent = data_name_prodacts_2_75[counter]
        name_prodacts_2_76.textContent = data_name_prodacts_2_76[counter]
        name_prodacts_2_77.textContent = data_name_prodacts_2_77[counter]
        name_prodacts_2_78.textContent = data_name_prodacts_2_78[counter]
        name_prodacts_2_79.textContent = data_name_prodacts_2_79[counter]
        name_prodacts_2_80.textContent = data_name_prodacts_2_80[counter]
        name_prodacts_2_81.textContent = data_name_prodacts_2_81[counter]
        name_prodacts_2_82.textContent = data_name_prodacts_2_82[counter]
        name_prodacts_2_83.textContent = data_name_prodacts_2_83[counter]
        name_prodacts_2_84.textContent = data_name_prodacts_2_84[counter]
        name_prodacts_2_85.textContent = data_name_prodacts_2_85[counter]
        name_prodacts_2_86.textContent = data_name_prodacts_2_86[counter]
        name_prodacts_2_87.textContent = data_name_prodacts_2_87[counter]
        name_prodacts_2_88.textContent = data_name_prodacts_2_88[counter]
        name_prodacts_2_89.textContent = data_name_prodacts_2_89[counter]
        name_prodacts_2_90.textContent = data_name_prodacts_2_90[counter]
        name_prodacts_2_91.textContent = data_name_prodacts_2_91[counter]
        name_prodacts_2_92.textContent = data_name_prodacts_2_92[counter]
        name_prodacts_2_93.textContent = data_name_prodacts_2_93[counter]
        name_prodacts_2_94.textContent = data_name_prodacts_2_94[counter]
        name_prodacts_2_95.textContent = data_name_prodacts_2_95[counter]
        name_prodacts_2_96.textContent = data_name_prodacts_2_96[counter]
        name_prodacts_2_97.textContent = data_name_prodacts_2_97[counter]
        name_prodacts_2_98.textContent = data_name_prodacts_2_98[counter]
        name_prodacts_2_99.textContent = data_name_prodacts_2_99[counter]
        name_prodacts_2_100.textContent = data_name_prodacts_2_100[counter]
        name_prodacts_2_101.textContent = data_name_prodacts_2_101[counter]
        name_prodacts_2_102.textContent = data_name_prodacts_2_102[counter]
        name_prodacts_2_103.textContent = data_name_prodacts_2_103[counter]
        name_prodacts_2_104.textContent = data_name_prodacts_2_104[counter]
        name_prodacts_2_105.textContent = data_name_prodacts_2_105[counter]
        name_prodacts_2_106.textContent = data_name_prodacts_2_106[counter]
        name_prodacts_2_107.textContent = data_name_prodacts_2_107[counter]
        name_prodacts_2_108.textContent = data_name_prodacts_2_108[counter]
        name_prodacts_2_109.textContent = data_name_prodacts_2_109[counter]
        name_prodacts_2_110.textContent = data_name_prodacts_2_110[counter]
        name_prodacts_2_111.textContent = data_name_prodacts_2_111[counter]
        name_prodacts_2_112.textContent = data_name_prodacts_2_112[counter]
        name_prodacts_2_113.textContent = data_name_prodacts_2_113[counter]
        name_prodacts_2_114.textContent = data_name_prodacts_2_114[counter]
        name_prodacts_2_115.textContent = data_name_prodacts_2_115[counter]
        name_prodacts_2_116.textContent = data_name_prodacts_2_116[counter]
        name_prodacts_2_117.textContent = data_name_prodacts_2_117[counter]
        name_prodacts_2_118.textContent = data_name_prodacts_2_118[counter]
        name_prodacts_2_119.textContent = data_name_prodacts_2_119[counter]
        name_prodacts_2_120.textContent = data_name_prodacts_2_120[counter]
        
        /*Data Name prodacts 2 */
        
        
        
        
        
        
        
        
        
        /*Data Name prodacts 3 */
        
        name_prodacts_3_1.textContent = data_name_prodacts_3_1[counter]
        name_prodacts_3_2.textContent = data_name_prodacts_3_2[counter]
        name_prodacts_3_3.textContent = data_name_prodacts_3_3[counter]
        name_prodacts_3_4.textContent = data_name_prodacts_3_4[counter]
        name_prodacts_3_5.textContent = data_name_prodacts_3_5[counter]
        name_prodacts_3_6.textContent = data_name_prodacts_3_6[counter]
        name_prodacts_3_7.textContent = data_name_prodacts_3_7[counter]
        name_prodacts_3_8.textContent = data_name_prodacts_3_8[counter]
        name_prodacts_3_9.textContent = data_name_prodacts_3_9[counter]
        name_prodacts_3_10.textContent = data_name_prodacts_3_10[counter]
        name_prodacts_3_10.textContent = data_name_prodacts_3_10[counter]
        name_prodacts_3_11.textContent = data_name_prodacts_3_11[counter]
        name_prodacts_3_12.textContent = data_name_prodacts_3_12[counter]
        name_prodacts_3_13.textContent = data_name_prodacts_3_13[counter]
        name_prodacts_3_14.textContent = data_name_prodacts_3_14[counter]
        name_prodacts_3_15.textContent = data_name_prodacts_3_15[counter]
        name_prodacts_3_16.textContent = data_name_prodacts_3_16[counter]
        name_prodacts_3_17.textContent = data_name_prodacts_3_17[counter]
        name_prodacts_3_18.textContent = data_name_prodacts_3_18[counter]
        name_prodacts_3_19.textContent = data_name_prodacts_3_19[counter]
        name_prodacts_3_20.textContent = data_name_prodacts_3_20[counter]
        name_prodacts_3_21.textContent = data_name_prodacts_3_21[counter]
        name_prodacts_3_22.textContent = data_name_prodacts_3_22[counter]
        name_prodacts_3_23.textContent = data_name_prodacts_3_23[counter]
        name_prodacts_3_24.textContent = data_name_prodacts_3_24[counter]
        name_prodacts_3_25.textContent = data_name_prodacts_3_25[counter]
        name_prodacts_3_26.textContent = data_name_prodacts_3_26[counter]
        name_prodacts_3_27.textContent = data_name_prodacts_3_27[counter]
        name_prodacts_3_28.textContent = data_name_prodacts_3_28[counter]
        name_prodacts_3_29.textContent = data_name_prodacts_3_29[counter]
        name_prodacts_3_30.textContent = data_name_prodacts_3_30[counter]
        name_prodacts_3_31.textContent = data_name_prodacts_3_31[counter]
        name_prodacts_3_32.textContent = data_name_prodacts_3_32[counter]
        name_prodacts_3_33.textContent = data_name_prodacts_3_33[counter]
        name_prodacts_3_34.textContent = data_name_prodacts_3_34[counter]
        name_prodacts_3_35.textContent = data_name_prodacts_3_35[counter]
        name_prodacts_3_36.textContent = data_name_prodacts_3_36[counter]
        name_prodacts_3_37.textContent = data_name_prodacts_3_37[counter]
        name_prodacts_3_38.textContent = data_name_prodacts_3_38[counter]
        name_prodacts_3_39.textContent = data_name_prodacts_3_39[counter]
        name_prodacts_3_40.textContent = data_name_prodacts_3_40[counter]
        name_prodacts_3_41.textContent = data_name_prodacts_3_41[counter]
        name_prodacts_3_42.textContent = data_name_prodacts_3_42[counter]
        name_prodacts_3_43.textContent = data_name_prodacts_3_43[counter]
        name_prodacts_3_44.textContent = data_name_prodacts_3_44[counter]
        name_prodacts_3_45.textContent = data_name_prodacts_3_45[counter]
        name_prodacts_3_46.textContent = data_name_prodacts_3_46[counter]
        name_prodacts_3_47.textContent = data_name_prodacts_3_47[counter]
        name_prodacts_3_48.textContent = data_name_prodacts_3_48[counter]
        name_prodacts_3_49.textContent = data_name_prodacts_3_49[counter]
        name_prodacts_3_50.textContent = data_name_prodacts_3_50[counter]
        name_prodacts_3_51.textContent = data_name_prodacts_3_51[counter]
        name_prodacts_3_52.textContent = data_name_prodacts_3_52[counter]
        name_prodacts_3_53.textContent = data_name_prodacts_3_53[counter]
        name_prodacts_3_54.textContent = data_name_prodacts_3_54[counter]
        name_prodacts_3_55.textContent = data_name_prodacts_3_55[counter]
        name_prodacts_3_56.textContent = data_name_prodacts_3_56[counter]
        name_prodacts_3_57.textContent = data_name_prodacts_3_57[counter]
        name_prodacts_3_58.textContent = data_name_prodacts_3_58[counter]
        name_prodacts_3_59.textContent = data_name_prodacts_3_59[counter]
        name_prodacts_3_60.textContent = data_name_prodacts_3_60[counter]
        name_prodacts_3_61.textContent = data_name_prodacts_3_61[counter]
        name_prodacts_3_62.textContent = data_name_prodacts_3_62[counter]
        name_prodacts_3_63.textContent = data_name_prodacts_3_63[counter]
        name_prodacts_3_64.textContent = data_name_prodacts_3_64[counter]
        name_prodacts_3_65.textContent = data_name_prodacts_3_65[counter]
        name_prodacts_3_66.textContent = data_name_prodacts_3_66[counter]
        name_prodacts_3_67.textContent = data_name_prodacts_3_67[counter]
        name_prodacts_3_68.textContent = data_name_prodacts_3_68[counter]
        name_prodacts_3_69.textContent = data_name_prodacts_3_69[counter]
        name_prodacts_3_70.textContent = data_name_prodacts_3_70[counter]
        name_prodacts_3_71.textContent = data_name_prodacts_3_71[counter]
        name_prodacts_3_72.textContent = data_name_prodacts_3_72[counter]
        name_prodacts_3_73.textContent = data_name_prodacts_3_73[counter]
        name_prodacts_3_74.textContent = data_name_prodacts_3_74[counter]
        name_prodacts_3_75.textContent = data_name_prodacts_3_75[counter]
        name_prodacts_3_76.textContent = data_name_prodacts_3_76[counter]
        name_prodacts_3_77.textContent = data_name_prodacts_3_77[counter]
        name_prodacts_3_78.textContent = data_name_prodacts_3_78[counter]
        name_prodacts_3_79.textContent = data_name_prodacts_3_79[counter]
        name_prodacts_3_80.textContent = data_name_prodacts_3_80[counter]
        name_prodacts_3_81.textContent = data_name_prodacts_3_81[counter]
        name_prodacts_3_82.textContent = data_name_prodacts_3_82[counter]
        name_prodacts_3_83.textContent = data_name_prodacts_3_83[counter]
        name_prodacts_3_84.textContent = data_name_prodacts_3_84[counter]
        name_prodacts_3_85.textContent = data_name_prodacts_3_85[counter]
        name_prodacts_3_86.textContent = data_name_prodacts_3_86[counter]
        name_prodacts_3_87.textContent = data_name_prodacts_3_87[counter]
        name_prodacts_3_88.textContent = data_name_prodacts_3_88[counter]
        name_prodacts_3_89.textContent = data_name_prodacts_3_89[counter]
        name_prodacts_3_90.textContent = data_name_prodacts_3_90[counter]
        name_prodacts_3_91.textContent = data_name_prodacts_3_91[counter]
        name_prodacts_3_92.textContent = data_name_prodacts_3_92[counter]
        name_prodacts_3_93.textContent = data_name_prodacts_3_93[counter]
        name_prodacts_3_94.textContent = data_name_prodacts_3_94[counter]
        name_prodacts_3_95.textContent = data_name_prodacts_3_95[counter]
        name_prodacts_3_96.textContent = data_name_prodacts_3_96[counter]
        name_prodacts_3_97.textContent = data_name_prodacts_3_97[counter]
        name_prodacts_3_98.textContent = data_name_prodacts_3_98[counter]
        name_prodacts_3_99.textContent = data_name_prodacts_3_99[counter]
        name_prodacts_3_100.textContent = data_name_prodacts_3_100[counter]
        name_prodacts_3_101.textContent = data_name_prodacts_3_101[counter]
        name_prodacts_3_102.textContent = data_name_prodacts_3_102[counter]
        name_prodacts_3_103.textContent = data_name_prodacts_3_103[counter]
        name_prodacts_3_104.textContent = data_name_prodacts_3_104[counter]
        name_prodacts_3_105.textContent = data_name_prodacts_3_105[counter]
        name_prodacts_3_106.textContent = data_name_prodacts_3_106[counter]
        name_prodacts_3_107.textContent = data_name_prodacts_3_107[counter]
        name_prodacts_3_108.textContent = data_name_prodacts_3_108[counter]
        name_prodacts_3_109.textContent = data_name_prodacts_3_109[counter]
        name_prodacts_3_110.textContent = data_name_prodacts_3_110[counter]
        name_prodacts_3_111.textContent = data_name_prodacts_3_111[counter]
        name_prodacts_3_112.textContent = data_name_prodacts_3_112[counter]
        name_prodacts_3_113.textContent = data_name_prodacts_3_113[counter]
        name_prodacts_3_114.textContent = data_name_prodacts_3_114[counter]
        name_prodacts_3_115.textContent = data_name_prodacts_3_115[counter]
        name_prodacts_3_116.textContent = data_name_prodacts_3_116[counter]
        name_prodacts_3_117.textContent = data_name_prodacts_3_117[counter]
        name_prodacts_3_118.textContent = data_name_prodacts_3_118[counter]
        name_prodacts_3_119.textContent = data_name_prodacts_3_119[counter]
        name_prodacts_3_120.textContent = data_name_prodacts_3_120[counter]
        
        /*Data Name prodacts 3 */
        
        
        
        
        /*Data Name prodacts 4 */
        
        name_prodacts_4_1.textContent = data_name_prodacts_4_1[counter]
        name_prodacts_4_2.textContent = data_name_prodacts_4_2[counter]
        name_prodacts_4_3.textContent = data_name_prodacts_4_3[counter]
        name_prodacts_4_4.textContent = data_name_prodacts_4_4[counter]
        name_prodacts_4_5.textContent = data_name_prodacts_4_5[counter]
        name_prodacts_4_6.textContent = data_name_prodacts_4_6[counter]
        name_prodacts_4_7.textContent = data_name_prodacts_4_7[counter]
        name_prodacts_4_8.textContent = data_name_prodacts_4_8[counter]
        name_prodacts_4_9.textContent = data_name_prodacts_4_9[counter]
        name_prodacts_4_10.textContent = data_name_prodacts_4_10[counter]
        name_prodacts_4_11.textContent = data_name_prodacts_4_11[counter]
        name_prodacts_4_12.textContent = data_name_prodacts_4_12[counter]
        name_prodacts_4_13.textContent = data_name_prodacts_4_13[counter]
        name_prodacts_4_14.textContent = data_name_prodacts_4_14[counter]
        name_prodacts_4_15.textContent = data_name_prodacts_4_15[counter]
        name_prodacts_4_16.textContent = data_name_prodacts_4_16[counter]
        name_prodacts_4_17.textContent = data_name_prodacts_4_17[counter]
        name_prodacts_4_18.textContent = data_name_prodacts_4_18[counter]
        name_prodacts_4_19.textContent = data_name_prodacts_4_19[counter]
        name_prodacts_4_20.textContent = data_name_prodacts_4_20[counter]
        name_prodacts_4_21.textContent = data_name_prodacts_4_21[counter]
        name_prodacts_4_22.textContent = data_name_prodacts_4_22[counter]
        name_prodacts_4_23.textContent = data_name_prodacts_4_23[counter]
        name_prodacts_4_24.textContent = data_name_prodacts_4_24[counter]
        name_prodacts_4_25.textContent = data_name_prodacts_4_25[counter]
        name_prodacts_4_26.textContent = data_name_prodacts_4_26[counter]
        name_prodacts_4_27.textContent = data_name_prodacts_4_27[counter]
        name_prodacts_4_28.textContent = data_name_prodacts_4_28[counter]
        name_prodacts_4_29.textContent = data_name_prodacts_4_29[counter]
        name_prodacts_4_30.textContent = data_name_prodacts_4_30[counter]
        name_prodacts_4_31.textContent = data_name_prodacts_4_31[counter]
        name_prodacts_4_32.textContent = data_name_prodacts_4_32[counter]
        name_prodacts_4_33.textContent = data_name_prodacts_4_33[counter]
        name_prodacts_4_34.textContent = data_name_prodacts_4_34[counter]
        name_prodacts_4_35.textContent = data_name_prodacts_4_35[counter]
        name_prodacts_4_36.textContent = data_name_prodacts_4_36[counter]
        name_prodacts_4_37.textContent = data_name_prodacts_4_37[counter]
        name_prodacts_4_38.textContent = data_name_prodacts_4_38[counter]
        name_prodacts_4_39.textContent = data_name_prodacts_4_39[counter]
        name_prodacts_4_40.textContent = data_name_prodacts_4_40[counter]
        name_prodacts_4_41.textContent = data_name_prodacts_4_41[counter]
        name_prodacts_4_42.textContent = data_name_prodacts_4_42[counter]
        name_prodacts_4_43.textContent = data_name_prodacts_4_43[counter]
        name_prodacts_4_44.textContent = data_name_prodacts_4_44[counter]
        name_prodacts_4_45.textContent = data_name_prodacts_4_45[counter]
        name_prodacts_4_46.textContent = data_name_prodacts_4_46[counter]
        name_prodacts_4_47.textContent = data_name_prodacts_4_47[counter]
        name_prodacts_4_48.textContent = data_name_prodacts_4_48[counter]
        name_prodacts_4_49.textContent = data_name_prodacts_4_49[counter]
        name_prodacts_4_50.textContent = data_name_prodacts_4_50[counter]
        name_prodacts_4_51.textContent = data_name_prodacts_4_51[counter]
        name_prodacts_4_52.textContent = data_name_prodacts_4_52[counter]
        name_prodacts_4_53.textContent = data_name_prodacts_4_53[counter]
        name_prodacts_4_54.textContent = data_name_prodacts_4_54[counter]
        name_prodacts_4_55.textContent = data_name_prodacts_4_55[counter]
        name_prodacts_4_56.textContent = data_name_prodacts_4_56[counter]
        name_prodacts_4_57.textContent = data_name_prodacts_4_57[counter]
        name_prodacts_4_58.textContent = data_name_prodacts_4_58[counter]
        name_prodacts_4_59.textContent = data_name_prodacts_4_59[counter]
        name_prodacts_4_60.textContent = data_name_prodacts_4_60[counter]
        name_prodacts_4_61.textContent = data_name_prodacts_4_61[counter]
        name_prodacts_4_62.textContent = data_name_prodacts_4_62[counter]
        name_prodacts_4_63.textContent = data_name_prodacts_4_63[counter]
        name_prodacts_4_64.textContent = data_name_prodacts_4_64[counter]
        name_prodacts_4_65.textContent = data_name_prodacts_4_65[counter]
        name_prodacts_4_66.textContent = data_name_prodacts_4_66[counter]
        name_prodacts_4_67.textContent = data_name_prodacts_4_67[counter]
        name_prodacts_4_68.textContent = data_name_prodacts_4_68[counter]
        name_prodacts_4_69.textContent = data_name_prodacts_4_69[counter]
        name_prodacts_4_70.textContent = data_name_prodacts_4_70[counter]
        name_prodacts_4_71.textContent = data_name_prodacts_4_71[counter]
        name_prodacts_4_72.textContent = data_name_prodacts_4_72[counter]
        name_prodacts_4_73.textContent = data_name_prodacts_4_73[counter]
        name_prodacts_4_74.textContent = data_name_prodacts_4_74[counter]
        name_prodacts_4_75.textContent = data_name_prodacts_4_75[counter]
        name_prodacts_4_76.textContent = data_name_prodacts_4_76[counter]
        name_prodacts_4_77.textContent = data_name_prodacts_4_77[counter]
        name_prodacts_4_78.textContent = data_name_prodacts_4_78[counter]
        name_prodacts_4_79.textContent = data_name_prodacts_4_79[counter]
        name_prodacts_4_80.textContent = data_name_prodacts_4_80[counter]
        name_prodacts_4_81.textContent = data_name_prodacts_4_81[counter]
        name_prodacts_4_82.textContent = data_name_prodacts_4_82[counter]
        name_prodacts_4_83.textContent = data_name_prodacts_4_83[counter]
        name_prodacts_4_84.textContent = data_name_prodacts_4_84[counter]
        name_prodacts_4_85.textContent = data_name_prodacts_4_85[counter]
        name_prodacts_4_86.textContent = data_name_prodacts_4_86[counter]
        name_prodacts_4_87.textContent = data_name_prodacts_4_87[counter]
        name_prodacts_4_88.textContent = data_name_prodacts_4_88[counter]
        name_prodacts_4_89.textContent = data_name_prodacts_4_89[counter]
        name_prodacts_4_90.textContent = data_name_prodacts_4_90[counter]
        name_prodacts_4_91.textContent = data_name_prodacts_4_91[counter]
        name_prodacts_4_92.textContent = data_name_prodacts_4_92[counter]
        name_prodacts_4_93.textContent = data_name_prodacts_4_93[counter]
        name_prodacts_4_94.textContent = data_name_prodacts_4_94[counter]
        name_prodacts_4_95.textContent = data_name_prodacts_4_95[counter]
        name_prodacts_4_96.textContent = data_name_prodacts_4_96[counter]
        name_prodacts_4_97.textContent = data_name_prodacts_4_97[counter]
        name_prodacts_4_98.textContent = data_name_prodacts_4_98[counter]
        name_prodacts_4_99.textContent = data_name_prodacts_4_99[counter]
        name_prodacts_4_100.textContent = data_name_prodacts_4_100[counter]
        name_prodacts_4_101.textContent = data_name_prodacts_4_101[counter]
        name_prodacts_4_102.textContent = data_name_prodacts_4_102[counter]
        name_prodacts_4_103.textContent = data_name_prodacts_4_103[counter]
        name_prodacts_4_104.textContent = data_name_prodacts_4_104[counter]
        name_prodacts_4_105.textContent = data_name_prodacts_4_105[counter]
        name_prodacts_4_106.textContent = data_name_prodacts_4_106[counter]
        name_prodacts_4_107.textContent = data_name_prodacts_4_107[counter]
        name_prodacts_4_108.textContent = data_name_prodacts_4_108[counter]
        name_prodacts_4_109.textContent = data_name_prodacts_4_109[counter]
        name_prodacts_4_110.textContent = data_name_prodacts_4_110[counter]
        name_prodacts_4_110.textContent = data_name_prodacts_4_110[counter]
        name_prodacts_4_111.textContent = data_name_prodacts_4_111[counter]
        name_prodacts_4_112.textContent = data_name_prodacts_4_112[counter]
        name_prodacts_4_113.textContent = data_name_prodacts_4_113[counter]
        name_prodacts_4_114.textContent = data_name_prodacts_4_114[counter]
        name_prodacts_4_115.textContent = data_name_prodacts_4_115[counter]
        name_prodacts_4_116.textContent = data_name_prodacts_4_116[counter]
        name_prodacts_4_117.textContent = data_name_prodacts_4_117[counter]
        name_prodacts_4_118.textContent = data_name_prodacts_4_118[counter]
        name_prodacts_4_119.textContent = data_name_prodacts_4_119[counter]
        name_prodacts_4_120.textContent = data_name_prodacts_4_120[counter]
        
        /*Data Name prodacts 4 */
        
        
        
        
        
    }, 1000);
    
	
}

/*End arrwo_left_big*/



/*Start Show Page Prodacts-1*/

gallery_1.onclick = function () {
            
    page_pages_section_prodacts.style.animation = "fade-in-page-prodacts 1s ease forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts.style.animation = "";
        page_pages_section_prodacts.style.transform = "scale(1)";
        
    }, 1000)
}

close_page_prodacts.onclick = function () {
    
    page_pages_section_prodacts.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts.style.animation = "";
        page_pages_section_prodacts.style.transform = "scale(0)";
        
    }, 1000)
    
}


/*End Show Page Prodacts-1*/

/*Start Show Page Prodacts-2*/



gallery_2.onclick = function () {
            
    page_pages_section_prodacts_2.style.animation = "fade-in-page-prodacts 1s ease forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_2.style.animation = "";
        page_pages_section_prodacts_2.style.transform = "scale(1)";
        
    }, 1000)
}

close_page_prodacts_2.onclick = function () {
    
    page_pages_section_prodacts_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_2.style.animation = "";
        page_pages_section_prodacts_2.style.transform = "scale(0)";
        
    }, 1000)
    
}


/*End Show Page Prodacts-2*/


/*Start Show Page Prodacts-3*/



gallery_3.onclick = function () {
            
    page_pages_section_prodacts_3.style.animation = "fade-in-page-prodacts 1s ease forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_3.style.animation = "";
        page_pages_section_prodacts_3.style.transform = "scale(1)";
        
    }, 1000)
}

close_page_prodacts_3.onclick = function () {
    
    page_pages_section_prodacts_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_3.style.animation = "";
        page_pages_section_prodacts_3.style.transform = "scale(0)";
        
    }, 1000)
    
}


/*End Show Page Prodacts-3*/




/*Start Show Page Prodacts-4*/



gallery_4.onclick = function () {
            
    page_pages_section_prodacts_4.style.animation = "fade-in-page-prodacts 1s ease forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_4.style.animation = "";
        page_pages_section_prodacts_4.style.transform = "scale(1)";
        
    }, 1000)
}

close_page_prodacts_4.onclick = function () {
    
    page_pages_section_prodacts_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_4.style.animation = "";
        page_pages_section_prodacts_4.style.transform = "scale(0)";
        
    }, 1000)
    
}


/*End Show Page Prodacts-4*/




/*Start prodacts_pages_1*/
var prodacts_pages_1 = document.getElementById("prodacts-pages-1"),
    go_gallery_1 = document.getElementById("go-gallery-1"),
    go_type_gallery_1 = document.getElementById("go-type-gallery-1");

img_section_prodacts_gallery_1_1.onclick = function () {
    
    
    
        go_type_gallery_1.textContent = name_section_prodacts_1_1.textContent;
        prodacts_pages_1.style.display = "block"
    
        prodacts_pages_1.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_1.style.animation = "";
            prodacts_pages_1.style.transform = "scale(1)";

        }, 1000)
    
}
go_gallery_1.onclick = function () {
    
    
    
    prodacts_pages_1.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_1.style.animation = "";
            prodacts_pages_1.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts.style.animation = "";
        page_pages_section_prodacts.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_1.onclick = function () {
    
    prodacts_pages_1.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_1.style.animation = "";
            prodacts_pages_1.style.transform = "scale(0)";

        }, 1000)
    
    
};

/*End prodacts_pages_1*/




/*Start prodacts_pages_2*/
var prodacts_pages_2 = document.getElementById("prodacts-pages-2"),
    go_gallery_2 = document.getElementById("go-gallery-2"),
    go_type_gallery_2 = document.getElementById("go-type-gallery-2");

img_section_prodacts_gallery_1_2.onclick = function () {
    
    
        go_type_gallery_2.textContent = name_section_prodacts_1_2.textContent;
    
        prodacts_pages_2.style.display = "block"
    
        prodacts_pages_2.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_2.style.animation = "";
            prodacts_pages_2.style.transform = "scale(1)";

        }, 1000)
    
}
go_gallery_2.onclick = function () {
    
    
    
    prodacts_pages_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2.style.animation = "";
            prodacts_pages_2.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts.style.animation = "";
        page_pages_section_prodacts.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_2.onclick = function () {
    
    prodacts_pages_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2.style.animation = "";
            prodacts_pages_2.style.transform = "scale(0)";

        }, 1000)
    
    
};

/*End prodacts_pages_2*/


/*Start prodacts_pages_3*/
var prodacts_pages_3 = document.getElementById("prodacts-pages-3"),
    go_gallery_3 = document.getElementById("go-gallery-3"),
    go_type_gallery_3 = document.getElementById("go-type-gallery-3");

img_section_prodacts_gallery_1_3.onclick = function () {
    
    
        go_type_gallery_3.textContent = name_section_prodacts_1_3.textContent;
        prodacts_pages_3.style.display = "block"
    
        prodacts_pages_3.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_3.style.animation = "";
            prodacts_pages_3.style.transform = "scale(1)";

        }, 1000)
    
}
go_gallery_3.onclick = function () {
    
    
    
    prodacts_pages_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3.style.animation = "";
            prodacts_pages_3.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts.style.animation = "";
        page_pages_section_prodacts.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_3.onclick = function () {
    
    prodacts_pages_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3.style.animation = "";
            prodacts_pages_3.style.transform = "scale(0)";

        }, 1000)
    
    
};

/*End prodacts_pages_3*/







/*Start prodacts_pages_4*/
var prodacts_pages_4 = document.getElementById("prodacts-pages-4"),
    go_gallery_4 = document.getElementById("go-gallery-4"),
    go_type_gallery_4 = document.getElementById("go-type-gallery-4");

img_section_prodacts_gallery_1_4.onclick = function () {
    
    
    
        go_type_gallery_4.textContent = name_section_prodacts_1_4.textContent;
    
        prodacts_pages_4.style.display = "block"
    
        prodacts_pages_4.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_4.style.animation = "";
            prodacts_pages_4.style.transform = "scale(1)";

        }, 1000)
    
}
go_gallery_4.onclick = function () {
    
    
    
    prodacts_pages_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4.style.animation = "";
            prodacts_pages_4.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts.style.animation = "";
        page_pages_section_prodacts.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_4.onclick = function () {
    
    prodacts_pages_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4.style.animation = "";
            prodacts_pages_4.style.transform = "scale(0)";

        }, 1000)
    
    
};

/*End prodacts_pages_4*/




/*Start prodacts_pages_5*/
var prodacts_pages_5 = document.getElementById("prodacts-pages-5"),
    go_gallery_5 = document.getElementById("go-gallery-5"),
    go_type_gallery_5 = document.getElementById("go-type-gallery-5");

img_section_prodacts_gallery_1_5.onclick = function () {
    
        go_type_gallery_5.textContent = name_section_prodacts_1_5.textContent;
        prodacts_pages_5.style.display = "block"
    
        prodacts_pages_5.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_5.style.animation = "";
            prodacts_pages_5.style.transform = "scale(1)";

        }, 1000)
    
}
go_gallery_5.onclick = function () {
    
    
    
    prodacts_pages_5.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_5.style.animation = "";
            prodacts_pages_5.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts.style.animation = "";
        page_pages_section_prodacts.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_5.onclick = function () {
    
    prodacts_pages_5.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_5.style.animation = "";
            prodacts_pages_5.style.transform = "scale(0)";

        }, 1000)
    
    
};

/*End prodacts_pages_5*/


/*Start prodacts_pages_6*/
var prodacts_pages_6 = document.getElementById("prodacts-pages-6"),
    go_gallery_6 = document.getElementById("go-gallery-6"),
    go_type_gallery_6 = document.getElementById("go-type-gallery-6");

img_section_prodacts_gallery_1_6.onclick = function () {
    
    
    
        go_type_gallery_6.textContent = name_section_prodacts_1_6.textContent;
        prodacts_pages_6.style.display = "block"
    
        prodacts_pages_6.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_6.style.animation = "";
            prodacts_pages_6.style.transform = "scale(1)";

        }, 1000)
    
}
go_gallery_6.onclick = function () {
    
    
    
    prodacts_pages_6.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_6.style.animation = "";
            prodacts_pages_6.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts.style.animation = "";
        page_pages_section_prodacts.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_6.onclick = function () {
    
    prodacts_pages_6.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_6.style.animation = "";
            prodacts_pages_6.style.transform = "scale(0)";

        }, 1000)
    
    
};

/*End prodacts_pages_6*/



/*Start prodacts_pages_6*/
var prodacts_pages_7 = document.getElementById("prodacts-pages-7"),
    go_gallery_7 = document.getElementById("go-gallery-7"),
    go_type_gallery_7 = document.getElementById("go-type-gallery-7");

img_section_prodacts_gallery_1_7.onclick = function () {
    
    
        go_type_gallery_7.textContent = name_section_prodacts_1_7.textContent;
        prodacts_pages_7.style.display = "block"
    
        prodacts_pages_7.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_7.style.animation = "";
            prodacts_pages_7.style.transform = "scale(1)";

        }, 1000)
    
}
go_gallery_7.onclick = function () {
    
    
    
    prodacts_pages_7.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_7.style.animation = "";
            prodacts_pages_7.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts.style.animation = "";
        page_pages_section_prodacts.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_7.onclick = function () {
    
    prodacts_pages_7.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_6.style.animation = "";
            prodacts_pages_6.style.transform = "scale(0)";

        }, 1000)
    
    
};

/*End prodacts_pages_7*/




/*Start prodacts_pages_8*/
var prodacts_pages_8 = document.getElementById("prodacts-pages-8"),
    go_gallery_8 = document.getElementById("go-gallery-8"),
    go_type_gallery_8 = document.getElementById("go-type-gallery-8");

img_section_prodacts_gallery_1_8.onclick = function () {
    
    
        go_type_gallery_8.textContent = name_section_prodacts_1_8.textContent;
        
        prodacts_pages_8.style.display = "block"
    
        prodacts_pages_8.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_8.style.animation = "";
            prodacts_pages_8.style.transform = "scale(1)";

        }, 1000)
    
}
go_gallery_8.onclick = function () {
    
    
    
    prodacts_pages_8.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_8.style.animation = "";
            prodacts_pages_8.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts.style.animation = "";
        page_pages_section_prodacts.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_8.onclick = function () {
    
    prodacts_pages_8.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_8.style.animation = "";
            prodacts_pages_8.style.transform = "scale(0)";

        }, 1000)
    
    
};

/*End prodacts_pages_8*/



/*Start prodacts_pages_9*/
var prodacts_pages_9 = document.getElementById("prodacts-pages-9"),
    go_gallery_9 = document.getElementById("go-gallery-9"),
    go_type_gallery_9 = document.getElementById("go-type-gallery-9");

img_section_prodacts_gallery_1_9.onclick = function () {
    
    
    
        go_type_gallery_9.textContent = name_section_prodacts_1_9.textContent;
    
        prodacts_pages_9.style.display = "block"
    
        prodacts_pages_9.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_9.style.animation = "";
            prodacts_pages_9.style.transform = "scale(1)";

        }, 1000)
    
}
go_gallery_9.onclick = function () {
    
    
    
    prodacts_pages_9.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_9.style.animation = "";
            prodacts_pages_9.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts.style.animation = "";
        page_pages_section_prodacts.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_9.onclick = function () {
    
    prodacts_pages_9.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_9.style.animation = "";
            prodacts_pages_9.style.transform = "scale(0)";

        }, 1000)
    
    
};

/*End prodacts_pages_9*/





/*Start prodacts_pages_10*/
var prodacts_pages_10 = document.getElementById("prodacts-pages-10"),
    go_gallery_10 = document.getElementById("go-gallery-10"),
    go_type_gallery_10 = document.getElementById("go-type-gallery-10");

img_section_prodacts_gallery_1_10.onclick = function () {
    
    
    
        go_type_gallery_10.textContent = name_section_prodacts_1_10.textContent;
        prodacts_pages_10.style.display = "block"
    
        prodacts_pages_10.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_10.style.animation = "";
            prodacts_pages_10.style.transform = "scale(1)";

        }, 1000)
    
}
go_gallery_10.onclick = function () {
    
    
    
    prodacts_pages_10.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_10.style.animation = "";
            prodacts_pages_10.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts.style.animation = "";
        page_pages_section_prodacts.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_10.onclick = function () {
    
    prodacts_pages_10.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_10.style.animation = "";
            prodacts_pages_10.style.transform = "scale(0)";

        }, 1000)
    
    
};

/*End prodacts_pages_10*/






/*Start prodacts_pages_11*/
var prodacts_pages_11 = document.getElementById("prodacts-pages-11"),
    go_gallery_11 = document.getElementById("go-gallery-11"),
    go_type_gallery_11 = document.getElementById("go-type-gallery-11");

img_section_prodacts_gallery_1_11.onclick = function () {
    
    
        go_type_gallery_11.textContent = name_section_prodacts_1_11.textContent;
    
        prodacts_pages_11.style.display = "block"
    
        prodacts_pages_11.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_11.style.animation = "";
            prodacts_pages_11.style.transform = "scale(1)";

        }, 1000)
    
}
go_gallery_11.onclick = function () {
    
    
    
    prodacts_pages_11.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_11.style.animation = "";
            prodacts_pages_11.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts.style.animation = "";
        page_pages_section_prodacts.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_11.onclick = function () {
    
    prodacts_pages_11.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_11.style.animation = "";
            prodacts_pages_11.style.transform = "scale(0)";

        }, 1000)
    
    
};

/*End prodacts_pages_11*/






/*Start prodacts_pages_12*/
var prodacts_pages_12 = document.getElementById("prodacts-pages-12"),
    go_gallery_12 = document.getElementById("go-gallery-12"),
    go_type_gallery_12 = document.getElementById("go-type-gallery-12");

img_section_prodacts_gallery_1_12.onclick = function () {
    
    
        go_type_gallery_12.textContent = name_section_prodacts_1_12.textContent;
    
        prodacts_pages_12.style.display = "block"
    
        prodacts_pages_12.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_12.style.animation = "";
            prodacts_pages_12.style.transform = "scale(1)";

        }, 1000)
    
}
go_gallery_12.onclick = function () {
    
    
    
    prodacts_pages_12.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_12.style.animation = "";
            prodacts_pages_12.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts.style.animation = "";
        page_pages_section_prodacts.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_12.onclick = function () {
    
    prodacts_pages_12.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_12.style.animation = "";
            prodacts_pages_12.style.transform = "scale(0)";

        }, 1000)
    
    
};

/*End prodacts_pages_12*/





























var prodacts_pages_2_1 = document.getElementById("prodacts-pages-2-1"),
    go_gallery_2_1 = document.getElementById("go-gallery-2-1"),
    go_type_gallery_2_1 = document.getElementById("go-type-gallery-2-1");

img_section_prodacts_gallery_2_1.onclick = function () {
    
    
        go_type_gallery_2_1.textContent = name_section_prodacts_2_1.textContent;
    
        prodacts_pages_2_1.style.display = "block"
    
        prodacts_pages_2_1.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_2_1.style.animation = "";
            prodacts_pages_2_1.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_2_1.onclick = function () {
    
    
    
    prodacts_pages_2_1.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_1.style.animation = "";
            prodacts_pages_2_1.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_2.style.animation = "";
        page_pages_section_prodacts_2.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_2_1.onclick = function () {
    
    prodacts_pages_2_1.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_1.style.animation = "";
            prodacts_pages_2_1.style.transform = "scale(0)";

        }, 1000)
    
};






















var prodacts_pages_2_2 = document.getElementById("prodacts-pages-2-2"),
    go_gallery_2_2 = document.getElementById("go-gallery-2-2"),
    go_type_gallery_2_2 = document.getElementById("go-type-gallery-2-2");

img_section_prodacts_gallery_2_2.onclick = function () {
    
    
        go_type_gallery_2_2.textContent = name_section_prodacts_2_2.textContent;
    
        prodacts_pages_2_2.style.display = "block"
    
        prodacts_pages_2_2.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_2_2.style.animation = "";
            prodacts_pages_2_2.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_2_2.onclick = function () {
    
    
    
    prodacts_pages_2_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_2.style.animation = "";
            prodacts_pages_2_2.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_2.style.animation = "";
        page_pages_section_prodacts_2.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_2_2.onclick = function () {
    
    prodacts_pages_2_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_2.style.animation = "";
            prodacts_pages_2_2.style.transform = "scale(0)";

        }, 1000)
    
};


















var prodacts_pages_2_3 = document.getElementById("prodacts-pages-2-3"),
    go_gallery_2_3 = document.getElementById("go-gallery-2-3"),
    go_type_gallery_2_3 = document.getElementById("go-type-gallery-2-3");

img_section_prodacts_gallery_2_3.onclick = function () {
    
    
        go_type_gallery_2_3.textContent = name_section_prodacts_2_3.textContent;
    
        prodacts_pages_2_3.style.display = "block"
    
        prodacts_pages_2_3.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_2_3.style.animation = "";
            prodacts_pages_2_3.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_2_3.onclick = function () {
    
    
    
    prodacts_pages_2_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_3.style.animation = "";
            prodacts_pages_2_3.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_2.style.animation = "";
        page_pages_section_prodacts_2.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_2_3.onclick = function () {
    
    prodacts_pages_2_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_3.style.animation = "";
            prodacts_pages_2_3.style.transform = "scale(0)";

        }, 1000)
    
};
















 var prodacts_pages_2_4 = document.getElementById("prodacts-pages-2-4"),
    go_gallery_2_4 = document.getElementById("go-gallery-2-4"),
    go_type_gallery_2_4 = document.getElementById("go-type-gallery-2-4");

img_section_prodacts_gallery_2_4.onclick = function () {
    
    
        go_type_gallery_2_4.textContent = name_section_prodacts_2_4.textContent;
    
        prodacts_pages_2_4.style.display = "block"
    
        prodacts_pages_2_4.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_2_4.style.animation = "";
            prodacts_pages_2_4.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_2_4.onclick = function () {
    
    
    
    prodacts_pages_2_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_4.style.animation = "";
            prodacts_pages_2_4.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_2.style.animation = "";
        page_pages_section_prodacts_2.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_2_4.onclick = function () {
    
    prodacts_pages_2_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_4.style.animation = "";
            prodacts_pages_2_4.style.transform = "scale(0)";

        }, 1000)
    
};












 var prodacts_pages_2_5 = document.getElementById("prodacts-pages-2-5"),
    go_gallery_2_5 = document.getElementById("go-gallery-2-5"),
    go_type_gallery_2_5 = document.getElementById("go-type-gallery-2-5");

img_section_prodacts_gallery_2_5.onclick = function () {
    
    
        go_type_gallery_2_5.textContent = name_section_prodacts_2_5.textContent;
    
        prodacts_pages_2_5.style.display = "block"
    
        prodacts_pages_2_5.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_2_5.style.animation = "";
            prodacts_pages_2_5.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_2_5.onclick = function () {
    
    
    
    prodacts_pages_2_5.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_5.style.animation = "";
            prodacts_pages_2_5.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_2.style.animation = "";
        page_pages_section_prodacts_2.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_2_5.onclick = function () {
    
    prodacts_pages_2_5.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_5.style.animation = "";
            prodacts_pages_2_5.style.transform = "scale(0)";

        }, 1000)
    
};










 var prodacts_pages_2_6 = document.getElementById("prodacts-pages-2-6"),
    go_gallery_2_6 = document.getElementById("go-gallery-2-6"),
    go_type_gallery_2_6 = document.getElementById("go-type-gallery-2-6");

img_section_prodacts_gallery_2_6.onclick = function () {
    
    
        go_type_gallery_2_6.textContent = name_section_prodacts_2_6.textContent;
    
        prodacts_pages_2_6.style.display = "block"
    
        prodacts_pages_2_6.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_2_6.style.animation = "";
            prodacts_pages_2_6.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_2_6.onclick = function () {
    
    
    
    prodacts_pages_2_6.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_6.style.animation = "";
            prodacts_pages_2_6.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_2.style.animation = "";
        page_pages_section_prodacts_2.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_2_6.onclick = function () {
    
    prodacts_pages_2_6.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_6.style.animation = "";
            prodacts_pages_2_6.style.transform = "scale(0)";

        }, 1000)
    
};

















 var prodacts_pages_2_7 = document.getElementById("prodacts-pages-2-7"),
    go_gallery_2_7 = document.getElementById("go-gallery-2-7"),
    go_type_gallery_2_7 = document.getElementById("go-type-gallery-2-7");

img_section_prodacts_gallery_2_7.onclick = function () {
    
    
        go_type_gallery_2_7.textContent = name_section_prodacts_2_7.textContent;
    
        prodacts_pages_2_7.style.display = "block"
    
        prodacts_pages_2_7.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_2_7.style.animation = "";
            prodacts_pages_2_7.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_2_7.onclick = function () {
    
    
    
    prodacts_pages_2_7.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_7.style.animation = "";
            prodacts_pages_2_7.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_2.style.animation = "";
        page_pages_section_prodacts_2.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_2_7.onclick = function () {
    
    prodacts_pages_2_7.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_7.style.animation = "";
            prodacts_pages_2_7.style.transform = "scale(0)";

        }, 1000)
    
};













var prodacts_pages_2_8 = document.getElementById("prodacts-pages-2-8"),
    go_gallery_2_8 = document.getElementById("go-gallery-2-8"),
    go_type_gallery_2_8 = document.getElementById("go-type-gallery-2-8");

img_section_prodacts_gallery_2_8.onclick = function () {
    
    
        go_type_gallery_2_8.textContent = name_section_prodacts_2_8.textContent;
    
        prodacts_pages_2_8.style.display = "block"
    
        prodacts_pages_2_8.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_2_8.style.animation = "";
            prodacts_pages_2_8.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_2_8.onclick = function () {
    
    
    
    prodacts_pages_2_8.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_8.style.animation = "";
            prodacts_pages_2_8.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_2.style.animation = "";
        page_pages_section_prodacts_2.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_2_8.onclick = function () {
    
    prodacts_pages_2_8.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_8.style.animation = "";
            prodacts_pages_2_8.style.transform = "scale(0)";

        }, 1000)
    
};















var prodacts_pages_2_9 = document.getElementById("prodacts-pages-2-9"),
    go_gallery_2_9 = document.getElementById("go-gallery-2-9"),
    go_type_gallery_2_9 = document.getElementById("go-type-gallery-2-9");

img_section_prodacts_gallery_2_9.onclick = function () {
    
    
        go_type_gallery_2_9.textContent = name_section_prodacts_2_9.textContent;
    
        prodacts_pages_2_9.style.display = "block"
    
        prodacts_pages_2_9.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_2_9.style.animation = "";
            prodacts_pages_2_9.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_2_9.onclick = function () {
    
    
    
    prodacts_pages_2_9.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_9.style.animation = "";
            prodacts_pages_2_9.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_2.style.animation = "";
        page_pages_section_prodacts_2.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_2_9.onclick = function () {
    
    prodacts_pages_2_9.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_9.style.animation = "";
            prodacts_pages_2_9.style.transform = "scale(0)";

        }, 1000)
    
};
















var prodacts_pages_2_10 = document.getElementById("prodacts-pages-2-10"),
    go_gallery_2_10 = document.getElementById("go-gallery-2-10"),
    go_type_gallery_2_10 = document.getElementById("go-type-gallery-2-10");

img_section_prodacts_gallery_2_10.onclick = function () {
    
    
        go_type_gallery_2_10.textContent = name_section_prodacts_2_10.textContent;
    
        prodacts_pages_2_10.style.display = "block"
    
        prodacts_pages_2_10.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_2_10.style.animation = "";
            prodacts_pages_2_10.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_2_10.onclick = function () {
    
    
    
    prodacts_pages_2_10.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_10.style.animation = "";
            prodacts_pages_2_10.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_2.style.animation = "";
        page_pages_section_prodacts_2.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_2_10.onclick = function () {
    
    prodacts_pages_2_10.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_10.style.animation = "";
            prodacts_pages_2_10.style.transform = "scale(0)";

        }, 1000)
    
};











var prodacts_pages_2_11 = document.getElementById("prodacts-pages-2-11"),
    go_gallery_2_11 = document.getElementById("go-gallery-2-11"),
    go_type_gallery_2_11 = document.getElementById("go-type-gallery-2-11");

img_section_prodacts_gallery_2_11.onclick = function () {
    
    
        go_type_gallery_2_11.textContent = name_section_prodacts_2_11.textContent;
    
        prodacts_pages_2_11.style.display = "block"
    
        prodacts_pages_2_11.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_2_11.style.animation = "";
            prodacts_pages_2_11.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_2_11.onclick = function () {
    
    
    
    prodacts_pages_2_11.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_11.style.animation = "";
            prodacts_pages_2_11.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_2.style.animation = "";
        page_pages_section_prodacts_2.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_2_11.onclick = function () {
    
    prodacts_pages_2_11.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_11.style.animation = "";
            prodacts_pages_2_11.style.transform = "scale(0)";

        }, 1000)
    
};






var prodacts_pages_2_12 = document.getElementById("prodacts-pages-2-12"),
    go_gallery_2_12 = document.getElementById("go-gallery-2-12"),
    go_type_gallery_2_12 = document.getElementById("go-type-gallery-2-12");

img_section_prodacts_gallery_2_12.onclick = function () {
    
    
        go_type_gallery_2_12.textContent = name_section_prodacts_2_12.textContent;
    
        prodacts_pages_2_12.style.display = "block"
    
        prodacts_pages_2_12.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_2_12.style.animation = "";
            prodacts_pages_2_12.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_2_12.onclick = function () {
    
    
    
    prodacts_pages_2_12.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_12.style.animation = "";
            prodacts_pages_2_12.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_2.style.animation = "";
        page_pages_section_prodacts_2.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_2_12.onclick = function () {
    
    prodacts_pages_2_12.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_2_12.style.animation = "";
            prodacts_pages_2_12.style.transform = "scale(0)";

        }, 1000)
    
};

//End Galeery2----------------------------------------------------------------------------




var prodacts_pages_3_1 = document.getElementById("prodacts-pages-3-1"),
    go_gallery_3_1 = document.getElementById("go-gallery-3-1"),
    go_type_gallery_3_1 = document.getElementById("go-type-gallery-3-1");

img_section_prodacts_gallery_3_1.onclick = function () {
    
    
        go_type_gallery_3_1.textContent = name_section_prodacts_3_1.textContent;
    
        prodacts_pages_3_1.style.display = "block"
    
        prodacts_pages_3_1.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_3_1.style.animation = "";
            prodacts_pages_3_1.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_3_1.onclick = function () {
    
    
    
    prodacts_pages_3_1.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_1.style.animation = "";
            prodacts_pages_3_1.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_3.style.animation = "";
        page_pages_section_prodacts_3.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_3_1.onclick = function () {
    
    prodacts_pages_3_1.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_1.style.animation = "";
            prodacts_pages_3_1.style.transform = "scale(0)";

        }, 1000)
    
};





var prodacts_pages_3_2 = document.getElementById("prodacts-pages-3-2"),
    go_gallery_3_2 = document.getElementById("go-gallery-3-2"),
    go_type_gallery_3_2 = document.getElementById("go-type-gallery-3-2");

img_section_prodacts_gallery_3_2.onclick = function () {
    
    
        go_type_gallery_3_2.textContent = name_section_prodacts_3_2.textContent;
    
        prodacts_pages_3_2.style.display = "block"
    
        prodacts_pages_3_2.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_3_2.style.animation = "";
            prodacts_pages_3_2.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_3_2.onclick = function () {
    
    
    
    prodacts_pages_3_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_2.style.animation = "";
            prodacts_pages_3_2.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_3.style.animation = "";
        page_pages_section_prodacts_3.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_3_2.onclick = function () {
    
    prodacts_pages_3_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_2.style.animation = "";
            prodacts_pages_3_2.style.transform = "scale(0)";

        }, 1000)
    
};










var prodacts_pages_3_3 = document.getElementById("prodacts-pages-3-3"),
    go_gallery_3_3 = document.getElementById("go-gallery-3-3"),
    go_type_gallery_3_3 = document.getElementById("go-type-gallery-3-3");

img_section_prodacts_gallery_3_3.onclick = function () {
    
    
        go_type_gallery_3_3.textContent = name_section_prodacts_3_3.textContent;
    
        prodacts_pages_3_3.style.display = "block"
    
        prodacts_pages_3_3.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_3_3.style.animation = "";
            prodacts_pages_3_3.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_3_3.onclick = function () {
    
    
    
    prodacts_pages_3_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_3.style.animation = "";
            prodacts_pages_3_3.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_3.style.animation = "";
        page_pages_section_prodacts_3.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_3_3.onclick = function () {
    
    prodacts_pages_3_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_3.style.animation = "";
            prodacts_pages_3_3.style.transform = "scale(0)";

        }, 1000)
    
};




















var prodacts_pages_3_4 = document.getElementById("prodacts-pages-3-4"),
    go_gallery_3_4 = document.getElementById("go-gallery-3-4"),
    go_type_gallery_3_4 = document.getElementById("go-type-gallery-3-4");

img_section_prodacts_gallery_3_4.onclick = function () {
    
    
        go_type_gallery_3_4.textContent = name_section_prodacts_3_4.textContent;
    
        prodacts_pages_3_4.style.display = "block"
    
        prodacts_pages_3_4.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_3_4.style.animation = "";
            prodacts_pages_3_4.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_3_4.onclick = function () {
    
    
    
    prodacts_pages_3_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_4.style.animation = "";
            prodacts_pages_3_4.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_3.style.animation = "";
        page_pages_section_prodacts_3.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_3_4.onclick = function () {
    
    prodacts_pages_3_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_4.style.animation = "";
            prodacts_pages_3_4.style.transform = "scale(0)";

        }, 1000)
    
};





















var prodacts_pages_3_5 = document.getElementById("prodacts-pages-3-5"),
    go_gallery_3_5 = document.getElementById("go-gallery-3-5"),
    go_type_gallery_3_5 = document.getElementById("go-type-gallery-3-5");

img_section_prodacts_gallery_3_5.onclick = function () {
    
    
        go_type_gallery_3_5.textContent = name_section_prodacts_3_5.textContent;
    
        prodacts_pages_3_5.style.display = "block"
    
        prodacts_pages_3_5.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_3_5.style.animation = "";
            prodacts_pages_3_5.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_3_5.onclick = function () {
    
    
    
    prodacts_pages_3_5.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_5.style.animation = "";
            prodacts_pages_3_5.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_3.style.animation = "";
        page_pages_section_prodacts_3.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_3_5.onclick = function () {
    
    prodacts_pages_3_5.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_5.style.animation = "";
            prodacts_pages_3_5.style.transform = "scale(0)";

        }, 1000)
    
};


















var prodacts_pages_3_6 = document.getElementById("prodacts-pages-3-6"),
    go_gallery_3_6 = document.getElementById("go-gallery-3-6"),
    go_type_gallery_3_6 = document.getElementById("go-type-gallery-3-6");

img_section_prodacts_gallery_3_6.onclick = function () {
    
    
        go_type_gallery_3_6.textContent = name_section_prodacts_3_6.textContent;
    
        prodacts_pages_3_6.style.display = "block"
    
        prodacts_pages_3_6.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_3_6.style.animation = "";
            prodacts_pages_3_6.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_3_6.onclick = function () {
    
    
    
    prodacts_pages_3_6.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_6.style.animation = "";
            prodacts_pages_3_6.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_3.style.animation = "";
        page_pages_section_prodacts_3.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_3_6.onclick = function () {
    
    prodacts_pages_3_6.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_6.style.animation = "";
            prodacts_pages_3_6.style.transform = "scale(0)";

        }, 1000)
    
};












var prodacts_pages_3_7 = document.getElementById("prodacts-pages-3-7"),
    go_gallery_3_7 = document.getElementById("go-gallery-3-7"),
    go_type_gallery_3_7 = document.getElementById("go-type-gallery-3-7");

img_section_prodacts_gallery_3_7.onclick = function () {
    
    
        go_type_gallery_3_7.textContent = name_section_prodacts_3_7.textContent;
    
        prodacts_pages_3_7.style.display = "block"
    
        prodacts_pages_3_7.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_3_7.style.animation = "";
            prodacts_pages_3_7.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_3_7.onclick = function () {
    
    
    
    prodacts_pages_3_7.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_7.style.animation = "";
            prodacts_pages_3_7.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_3.style.animation = "";
        page_pages_section_prodacts_3.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_3_7.onclick = function () {
    
    prodacts_pages_3_7.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_7.style.animation = "";
            prodacts_pages_3_7.style.transform = "scale(0)";

        }, 1000)
    
};










var prodacts_pages_3_8 = document.getElementById("prodacts-pages-3-8"),
    go_gallery_3_8 = document.getElementById("go-gallery-3-8"),
    go_type_gallery_3_8 = document.getElementById("go-type-gallery-3-8");

img_section_prodacts_gallery_3_8.onclick = function () {
    
    
        go_type_gallery_3_8.textContent = name_section_prodacts_3_8.textContent;
    
        prodacts_pages_3_8.style.display = "block"
    
        prodacts_pages_3_8.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_3_8.style.animation = "";
            prodacts_pages_3_8.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_3_8.onclick = function () {
    
    
    
    prodacts_pages_3_8.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_8.style.animation = "";
            prodacts_pages_3_8.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_3.style.animation = "";
        page_pages_section_prodacts_3.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_3_8.onclick = function () {
    
    prodacts_pages_3_8.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_8.style.animation = "";
            prodacts_pages_3_8.style.transform = "scale(0)";

        }, 1000)
    
};














var prodacts_pages_3_9 = document.getElementById("prodacts-pages-3-9"),
    go_gallery_3_9 = document.getElementById("go-gallery-3-9"),
    go_type_gallery_3_9 = document.getElementById("go-type-gallery-3-9");

img_section_prodacts_gallery_3_9.onclick = function () {
    
    
        go_type_gallery_3_9.textContent = name_section_prodacts_3_9.textContent;
    
        prodacts_pages_3_9.style.display = "block"
    
        prodacts_pages_3_9.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_3_9.style.animation = "";
            prodacts_pages_3_9.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_3_9.onclick = function () {
    
    
    
    prodacts_pages_3_9.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_9.style.animation = "";
            prodacts_pages_3_9.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_3.style.animation = "";
        page_pages_section_prodacts_3.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_3_9.onclick = function () {
    
    prodacts_pages_3_9.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_9.style.animation = "";
            prodacts_pages_3_9.style.transform = "scale(0)";

        }, 1000)
    
};












var prodacts_pages_3_10 = document.getElementById("prodacts-pages-3-10"),
    go_gallery_3_10 = document.getElementById("go-gallery-3-10"),
    go_type_gallery_3_10 = document.getElementById("go-type-gallery-3-10");

img_section_prodacts_gallery_3_10.onclick = function () {
    
    
        go_type_gallery_3_10.textContent = name_section_prodacts_3_10.textContent;
    
        prodacts_pages_3_10.style.display = "block"
    
        prodacts_pages_3_10.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_3_10.style.animation = "";
            prodacts_pages_3_10.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_3_10.onclick = function () {
    
    
    
    prodacts_pages_3_10.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_10.style.animation = "";
            prodacts_pages_3_10.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_3.style.animation = "";
        page_pages_section_prodacts_3.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_3_10.onclick = function () {
    
    prodacts_pages_3_10.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_10.style.animation = "";
            prodacts_pages_3_10.style.transform = "scale(0)";

        }, 1000)
    
};








var prodacts_pages_3_11 = document.getElementById("prodacts-pages-3-11"),
    go_gallery_3_11 = document.getElementById("go-gallery-3-11"),
    go_type_gallery_3_11 = document.getElementById("go-type-gallery-3-11");

img_section_prodacts_gallery_3_11.onclick = function () {
    
    
        go_type_gallery_3_11.textContent = name_section_prodacts_3_11.textContent;
    
        prodacts_pages_3_11.style.display = "block"
    
        prodacts_pages_3_11.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_3_11.style.animation = "";
            prodacts_pages_3_11.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_3_11.onclick = function () {
    
    
    
    prodacts_pages_3_11.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_11.style.animation = "";
            prodacts_pages_3_11.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_3.style.animation = "";
        page_pages_section_prodacts_3.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_3_11.onclick = function () {
    
    prodacts_pages_3_11.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_11.style.animation = "";
            prodacts_pages_3_11.style.transform = "scale(0)";

        }, 1000)
    
};







var prodacts_pages_3_12 = document.getElementById("prodacts-pages-3-12"),
    go_gallery_3_12 = document.getElementById("go-gallery-3-12"),
    go_type_gallery_3_12 = document.getElementById("go-type-gallery-3-12");

img_section_prodacts_gallery_3_12.onclick = function () {
    
    
        go_type_gallery_3_12.textContent = name_section_prodacts_3_12.textContent;
    
        prodacts_pages_3_12.style.display = "block"
    
        prodacts_pages_3_12.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_3_12.style.animation = "";
            prodacts_pages_3_12.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_3_12.onclick = function () {
    
    
    
    prodacts_pages_3_12.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_12.style.animation = "";
            prodacts_pages_3_12.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_3.style.animation = "";
        page_pages_section_prodacts_3.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_3_12.onclick = function () {
    
    prodacts_pages_3_12.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_3_12.style.animation = "";
            prodacts_pages_3_12.style.transform = "scale(0)";

        }, 1000)
    
};

//End Galeery3----------------------------------------------------------------------------








var prodacts_pages_4_1 = document.getElementById("prodacts-pages-4-1"),
    go_gallery_4_1 = document.getElementById("go-gallery-4-1"),
    go_type_gallery_4_1 = document.getElementById("go-type-gallery-4-1");

img_section_prodacts_gallery_4_1.onclick = function () {
    
    
        go_type_gallery_4_1.textContent = name_section_prodacts_4_1.textContent;
    
        prodacts_pages_4_1.style.display = "block"
    
        prodacts_pages_4_1.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_4_1.style.animation = "";
            prodacts_pages_4_1.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_4_1.onclick = function () {
    
    
    
    prodacts_pages_4_1.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_1.style.animation = "";
            prodacts_pages_4_1.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_4.style.animation = "";
        page_pages_section_prodacts_4.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_4_1.onclick = function () {
    
    prodacts_pages_4_1.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_1.style.animation = "";
            prodacts_pages_4_1.style.transform = "scale(0)";

        }, 1000)
    
};








var prodacts_pages_4_2 = document.getElementById("prodacts-pages-4-2"),
    go_gallery_4_2 = document.getElementById("go-gallery-4-2"),
    go_type_gallery_4_2 = document.getElementById("go-type-gallery-4-2");

img_section_prodacts_gallery_4_2.onclick = function () {
    
    
        go_type_gallery_4_2.textContent = name_section_prodacts_4_2.textContent;
    
        prodacts_pages_4_2.style.display = "block"
    
        prodacts_pages_4_2.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_4_2.style.animation = "";
            prodacts_pages_4_2.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_4_2.onclick = function () {
    
    
    
    prodacts_pages_4_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_2.style.animation = "";
            prodacts_pages_4_2.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_4.style.animation = "";
        page_pages_section_prodacts_4.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_4_2.onclick = function () {
    
    prodacts_pages_4_2.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_2.style.animation = "";
            prodacts_pages_4_2.style.transform = "scale(0)";

        }, 1000)
    
};







var prodacts_pages_4_3 = document.getElementById("prodacts-pages-4-3"),
    go_gallery_4_3 = document.getElementById("go-gallery-4-3"),
    go_type_gallery_4_3 = document.getElementById("go-type-gallery-4-3");

img_section_prodacts_gallery_4_3.onclick = function () {
    
    
        go_type_gallery_4_3.textContent = name_section_prodacts_4_3.textContent;
    
        prodacts_pages_4_3.style.display = "block"
    
        prodacts_pages_4_3.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_4_3.style.animation = "";
            prodacts_pages_4_3.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_4_3.onclick = function () {
    
    
    
    prodacts_pages_4_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_3.style.animation = "";
            prodacts_pages_4_3.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_4.style.animation = "";
        page_pages_section_prodacts_4.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_4_3.onclick = function () {
    
    prodacts_pages_4_3.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_3.style.animation = "";
            prodacts_pages_4_3.style.transform = "scale(0)";

        }, 1000)
    
};










var prodacts_pages_4_4 = document.getElementById("prodacts-pages-4-4"),
    go_gallery_4_4 = document.getElementById("go-gallery-4-4"),
    go_type_gallery_4_4 = document.getElementById("go-type-gallery-4-4");

img_section_prodacts_gallery_4_4.onclick = function () {
    
    
        go_type_gallery_4_4.textContent = name_section_prodacts_4_4.textContent;
    
        prodacts_pages_4_4.style.display = "block"
    
        prodacts_pages_4_4.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_4_4.style.animation = "";
            prodacts_pages_4_4.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_4_4.onclick = function () {
    
    
    
    prodacts_pages_4_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_4.style.animation = "";
            prodacts_pages_4_4.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_4.style.animation = "";
        page_pages_section_prodacts_4.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_4_4.onclick = function () {
    
    prodacts_pages_4_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_4.style.animation = "";
            prodacts_pages_4_4.style.transform = "scale(0)";

        }, 1000)
    
};










var prodacts_pages_4_5 = document.getElementById("prodacts-pages-4-5"),
    go_gallery_4_5 = document.getElementById("go-gallery-4-5"),
    go_type_gallery_4_5 = document.getElementById("go-type-gallery-4-5");

img_section_prodacts_gallery_4_5.onclick = function () {
    
    
        go_type_gallery_4_5.textContent = name_section_prodacts_4_5.textContent;
    
        prodacts_pages_4_5.style.display = "block"
    
        prodacts_pages_4_5.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_4_5.style.animation = "";
            prodacts_pages_4_5.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_4_5.onclick = function () {
    
    
    
    prodacts_pages_4_5.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_5.style.animation = "";
            prodacts_pages_4_5.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_4.style.animation = "";
        page_pages_section_prodacts_4.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_4_5.onclick = function () {
    
    prodacts_pages_4_5.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_5.style.animation = "";
            prodacts_pages_4_5.style.transform = "scale(0)";

        }, 1000)
    
};













var prodacts_pages_4_6 = document.getElementById("prodacts-pages-4-6"),
    go_gallery_4_6 = document.getElementById("go-gallery-4-6"),
    go_type_gallery_4_6 = document.getElementById("go-type-gallery-4-6");

img_section_prodacts_gallery_4_6.onclick = function () {
    
    
        go_type_gallery_4_6.textContent = name_section_prodacts_4_6.textContent;
    
        prodacts_pages_4_6.style.display = "block"
    
        prodacts_pages_4_6.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_4_6.style.animation = "";
            prodacts_pages_4_6.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_4_6.onclick = function () {
    
    
    
    prodacts_pages_4_6.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_6.style.animation = "";
            prodacts_pages_4_6.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_4.style.animation = "";
        page_pages_section_prodacts_4.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_4_6.onclick = function () {
    
    prodacts_pages_4_6.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_6.style.animation = "";
            prodacts_pages_4_6.style.transform = "scale(0)";

        }, 1000)
    
};







var prodacts_pages_4_7 = document.getElementById("prodacts-pages-4-7"),
    go_gallery_4_7 = document.getElementById("go-gallery-4-7"),
    go_type_gallery_4_7 = document.getElementById("go-type-gallery-4-7");

img_section_prodacts_gallery_4_7.onclick = function () {
    
    
        go_type_gallery_4_7.textContent = name_section_prodacts_4_7.textContent;
    
        prodacts_pages_4_7.style.display = "block"
    
        prodacts_pages_4_7.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_4_7.style.animation = "";
            prodacts_pages_4_7.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_4_7.onclick = function () {
    
    
    
    prodacts_pages_4_7.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_7.style.animation = "";
            prodacts_pages_4_7.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_4.style.animation = "";
        page_pages_section_prodacts_4.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_4_7.onclick = function () {
    
    prodacts_pages_4_7.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_7.style.animation = "";
            prodacts_pages_4_7.style.transform = "scale(0)";

        }, 1000)
    
};






var prodacts_pages_4_8 = document.getElementById("prodacts-pages-4-8"),
    go_gallery_4_8 = document.getElementById("go-gallery-4-8"),
    go_type_gallery_4_8 = document.getElementById("go-type-gallery-4-8");

img_section_prodacts_gallery_4_8.onclick = function () {
    
    
        go_type_gallery_4_8.textContent = name_section_prodacts_4_8.textContent;
    
        prodacts_pages_4_8.style.display = "block"
    
        prodacts_pages_4_8.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_4_8.style.animation = "";
            prodacts_pages_4_8.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_4_8.onclick = function () {
    
    
    
    prodacts_pages_4_8.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_8.style.animation = "";
            prodacts_pages_4_8.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_4.style.animation = "";
        page_pages_section_prodacts_4.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_4_8.onclick = function () {
    
    prodacts_pages_4_8.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_8.style.animation = "";
            prodacts_pages_4_8.style.transform = "scale(0)";

        }, 1000)
    
};











var prodacts_pages_4_9 = document.getElementById("prodacts-pages-4-9"),
    go_gallery_4_9 = document.getElementById("go-gallery-4-9"),
    go_type_gallery_4_9 = document.getElementById("go-type-gallery-4-9");

img_section_prodacts_gallery_4_9.onclick = function () {
    
    
        go_type_gallery_4_9.textContent = name_section_prodacts_4_9.textContent;
    
        prodacts_pages_4_9.style.display = "block"
    
        prodacts_pages_4_9.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_4_9.style.animation = "";
            prodacts_pages_4_9.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_4_9.onclick = function () {
    
    
    
    prodacts_pages_4_9.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_9.style.animation = "";
            prodacts_pages_4_9.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_4.style.animation = "";
        page_pages_section_prodacts_4.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_4_9.onclick = function () {
    
    prodacts_pages_4_9.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_9.style.animation = "";
            prodacts_pages_4_9.style.transform = "scale(0)";

        }, 1000)
    
};





var prodacts_pages_4_10 = document.getElementById("prodacts-pages-4-10"),
    go_gallery_4_10 = document.getElementById("go-gallery-4-10"),
    go_type_gallery_4_10 = document.getElementById("go-type-gallery-4-10");

img_section_prodacts_gallery_4_10.onclick = function () {
    
    
        go_type_gallery_4_10.textContent = name_section_prodacts_4_10.textContent;
    
        prodacts_pages_4_10.style.display = "block"
    
        prodacts_pages_4_10.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_4_10.style.animation = "";
            prodacts_pages_4_10.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_4_10.onclick = function () {
    
    
    
    prodacts_pages_4_10.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_10.style.animation = "";
            prodacts_pages_4_10.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_4.style.animation = "";
        page_pages_section_prodacts_4.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_4_10.onclick = function () {
    
    prodacts_pages_4_10.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_10.style.animation = "";
            prodacts_pages_4_10.style.transform = "scale(0)";

        }, 1000)
    
};











var prodacts_pages_4_11 = document.getElementById("prodacts-pages-4-11"),
    go_gallery_4_11 = document.getElementById("go-gallery-4-11"),
    go_type_gallery_4_11 = document.getElementById("go-type-gallery-4-11");

img_section_prodacts_gallery_4_11.onclick = function () {
    
    
        go_type_gallery_4_11.textContent = name_section_prodacts_4_11.textContent;
    
        prodacts_pages_4_11.style.display = "block"
    
        prodacts_pages_4_11.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_4_11.style.animation = "";
            prodacts_pages_4_11.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_4_11.onclick = function () {
    
    
    
    prodacts_pages_4_11.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_11.style.animation = "";
            prodacts_pages_4_11.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_4.style.animation = "";
        page_pages_section_prodacts_4.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_4_11.onclick = function () {
    
    prodacts_pages_4_11.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_11.style.animation = "";
            prodacts_pages_4_11.style.transform = "scale(0)";

        }, 1000)
    
};












var prodacts_pages_4_12 = document.getElementById("prodacts-pages-4-12"),
    go_gallery_4_12 = document.getElementById("go-gallery-4-12"),
    go_type_gallery_4_12 = document.getElementById("go-type-gallery-4-12");

img_section_prodacts_gallery_4_12.onclick = function () {
    
    
        go_type_gallery_4_12.textContent = name_section_prodacts_4_12.textContent;
    
        prodacts_pages_4_12.style.display = "block"
    
        prodacts_pages_4_12.style.animation = "fade-in-page-prodacts 1s ease forwards";

        setTimeout(function () {

            prodacts_pages_4_12.style.animation = "";
            prodacts_pages_4_12.style.transform = "scale(1)";

        }, 1000)
    
}



go_gallery_4_12.onclick = function () {
    
    
    
    prodacts_pages_4_12.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_12.style.animation = "";
            prodacts_pages_4_12.style.transform = "scale(0)";

        }, 1000)
    

    page_pages_section_prodacts_4.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";
    
    setTimeout(function () {
        
        page_pages_section_prodacts_4.style.animation = "";
        page_pages_section_prodacts_4.style.transform = "scale(0)";
        
    }, 1000)
    
}
go_type_gallery_4_12.onclick = function () {
    
    prodacts_pages_4_12.style.animation = "fade-in-page-prodacts 1s ease reverse forwards";

        setTimeout(function () {

            prodacts_pages_4_12.style.animation = "";
            prodacts_pages_4_12.style.transform = "scale(0)";

        }, 1000)
    
};









